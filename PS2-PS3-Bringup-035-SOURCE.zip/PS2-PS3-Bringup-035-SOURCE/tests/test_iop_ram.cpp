#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;unsigned v;
 setup(c,{0x8cc603c0});c.reg[6]=0xbc000000;assert(c.step()&&c.reg[6]==0);
 assert(c.write32(0xbc0003c0,0x12345678));assert(c.read32(0x9c0003c0,v)&&v==0x12345678);assert(c.read32(0x1c0003c0,v)&&v==0x12345678);

 for(unsigned off:{0u,0x200000u,0x400000u,0x600000u}){assert(c.read32(0xbc0003c0+off,v)&&v==0x12345678);assert(c.write32(0x9c000100+off,off+42));assert(c.read32(0xbc000100,v)&&v==off+42);}
 assert(c.write32(0xbc1ffffc,0xabcdef12));assert(c.read32(0xbc7ffffc,v)&&v==0xabcdef12);assert(!c.read32(0xbc800000,v));assert(!c.write32(0xbc800000,1));assert(!c.read32(0xbbfffffc,v));assert(!c.write32(0xbc1fffff,1));
 // IOP RAM is separate from EE RAM, and resets on a new guest load.
 assert(c.read32(0x800003c0,v)&&v==0);setup(c,{0x8cc603c0});assert(c.read32(0xbc0003c0,v)&&v==0);
 // Mapped user page aliases IOP RAM, respecting valid/dirty permissions.
 assert(c.tlb.put(0,0,0x400000,0x700007,0x700043));assert(c.write32(0xbc000000,0x12345678));c.cp0[12]=0;assert(c.read32(0x400000,v)&&v==0x12345678);assert(c.write32(0x400000,42));assert(c.read32(0xbc000000,v)&&v==42);assert(!c.write32(0x401000,42));
 // Full 128-bit transfers and little-endian byte/halfword scalar accesses.
 setup(c,{0x78c20000,0x7c820000,0x80830000,0x94850002});c.reg[6]=0xbc1ffff0;c.reg[4]=0xbc600010;for(unsigned i=0;i<4;i++)assert(c.write32(0xbc1ffff0+i*4,0x83828180+i*0x04040404));assert(c.step()&&c.step()&&c.step()&&c.step());assert(c.reg[3]==0xffffffffffffff80ull&&c.reg[5]==0x8382);for(unsigned i=0;i<4;i++)assert(c.read32(0xbc000010+i*4,v)&&v==0x83828180+i*0x04040404);
 setup(c,{0x3c02bc00,0x344203c0,0x3c041234,0x34845678,0xac440000,0x8c450000,0x0000000d});for(unsigned i=0;i<6;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT&&c.reg[5]==0x12345678);
 puts("PASS: exact BIOS IOP RAM read and shared aliases");}
