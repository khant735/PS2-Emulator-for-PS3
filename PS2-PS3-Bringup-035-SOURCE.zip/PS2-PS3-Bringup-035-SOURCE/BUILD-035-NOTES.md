# Build 035 — experimental DVE compatibility

Based on uploaded Build 033 source; Build 034 ELF/SELF are binary references only, not source.

Build 034 trace: PC 80007CD0, SH 0x0081 to BA000000, after mode 0x42.

Change: accept mode 0x42 / command 0x81 even if no prior known selector; increment DVE_BUILD035_MODE42_UNSELECTED_COMPAT. This does NOT synthesize readback or implement actual DVE timing. All other unsupported commands retain existing behavior.

Test with `bash tests/run_all.sh` and `c++ -std=c++11 -Iinclude tests/test_dve_035.cpp source/emu_core.cpp -o /tmp/test_dve_035 && /tmp/test_dve_035`.

PS3 compilation requires PS3DEV/PSL1GHT toolchain; no PS3 ELF/SELF/PKG was generated in this environment.

On RPCS3 run TRACE SELECTED BIOS, export last-trace.txt, check the new compatibility counter and next stop PC.
