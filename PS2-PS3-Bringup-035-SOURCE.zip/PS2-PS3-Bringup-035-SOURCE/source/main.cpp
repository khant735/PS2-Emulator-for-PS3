#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <malloc.h>
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdarg.h>
#include <stddef.h>
#include <math.h>
#include "text_frame.h"
#include "ui_stats.h"
#include <ppu-lv2.h>

#include <ppu-types.h>
#include <sys/process.h>
#include <io/pad.h>
#include <rsx/rsx.h>
#include <rsx/gcm_sys.h>
#include "icn_hw_vpo.h"
#include "icn_hw_fpo.h"
#include <sysutil/sysutil.h>
#include <sysutil/video.h>

extern "C" {
#include "psu.h"
}

static VramUsage ui_vram;
static char ui_memory_pages[2][11][180];
static unsigned long long g_present_frames=0;
static void* tracked_rsx_memalign(u32 alignment,u32 size){void*p=rsxMemalign(alignment,size);if(p&&!ui_vram.add(p,size)){rsxFree(p);return NULL;}return p;}
static void tracked_rsx_free(void*p){ui_vram.remove(p);rsxFree(p);}
struct UiMemoryInfo {u32 total,available;};
static s32 ui_get_memory(UiMemoryInfo*info){lv2syscall1(352,(u64)info);return_to_user_prog(s32);}
static void ui_memory_text(char*out,size_t cap){
 UiMemoryInfo m={0,0};gcmConfiguration cfg;memset(&cfg,0,sizeof(cfg));
 bool ram_ok=ui_get_memory(&m)==0&&m.available<=m.total&&m.total;
 // Follow the supplied librsx allocator: consume the filled configuration.
 // Its import declaration cannot be used as a reliable status contract.
 gcmGetConfiguration(&cfg);
 bool vram_ok=cfg.localSize>=1024u*1024u&&cfg.localSize<=256u*1024u*1024u&&cfg.localSize>=ui_vram.bytes;
 char ram[100],vram[100];const double mb=1048576.0;
 struct mallinfo heap=mallinfo();bool heap_ok=heap.uordblks>=0&&heap.fordblks>=0&&heap.arena>0;
 char (*cpu)[180]=ui_memory_pages[0],(*gpu)[180]=ui_memory_pages[1];
 strcpy(cpu[0],"CPU RAM | CPU SPEED: NOT DETECTED");
 char core_clock[32],memory_clock[32];
 if(cfg.coreFreq)snprintf(core_clock,sizeof(core_clock),"%.2f MHz",cfg.coreFreq/1000000.0);else strcpy(core_clock,"N/A");
 if(cfg.memoryFreq)snprintf(memory_clock,sizeof(memory_clock),"%.2f MHz",cfg.memoryFreq/1000000.0);else strcpy(memory_clock,"N/A");
 snprintf(gpu[0],180,"GPU SPEED %s | VIDEO MEMORY %s (REPORTED)",core_clock,memory_clock);
 for(unsigned page=0;page<2;page++){
  char (*rows)[180]=ui_memory_pages[page];
  strcpy(rows[1],"TOTAL INSTALLED: NOT DETECTED");
  strcpy(rows[7],"OS MEMORY IN USE: NOT MEASURED");
  strcpy(rows[8],"SET ASIDE FOR OS: NOT MEASURED");
  strcpy(rows[9],"OS RESERVED SPACE USED/FREE: NOT MEASURED");
 }
 if(ram_ok){
  snprintf(cpu[2],180,"APP MEMORY LIMIT: %.2f MiB (100%%)",m.total/mb);
  snprintf(cpu[3],180,"FREE FOR NEW ALLOCATIONS: %.2f MiB (%.1f%%)",m.available/mb,100.0*m.available/m.total);
 }else{strcpy(cpu[2],"APP MEMORY LIMIT: READ FAILED");strcpy(cpu[3],"FREE FOR NEW ALLOCATIONS: READ FAILED");}
 if(heap_ok){
  snprintf(ram,sizeof(ram),"APP HEAP %.1f USED / %.1f FREE MiB",heap.uordblks/mb,heap.fordblks/mb);
  if(ram_ok){
   snprintf(cpu[4],180,"APP RAM USED (HEAP ONLY): %.2f MiB (%.1f%%)",heap.uordblks/mb,100.0*heap.uordblks/m.total);
   snprintf(cpu[5],180,"FREE INSIDE APP HEAP: %.2f MiB (%.1f%%)",heap.fordblks/mb,100.0*heap.fordblks/m.total);
  }else{snprintf(cpu[4],180,"APP RAM USED (HEAP ONLY): %.2f MiB (%% N/A)",heap.uordblks/mb);snprintf(cpu[5],180,"FREE INSIDE APP HEAP: %.2f MiB (%% N/A)",heap.fordblks/mb);}
 }else{strcpy(ram,"RAM HEAP N/A");strcpy(cpu[4],"APP RAM USED (HEAP ONLY): UNAVAILABLE");strcpy(cpu[5],"FREE INSIDE APP HEAP: UNAVAILABLE");}
 strcpy(cpu[6],"TOTAL APP RAM USE: NOT MEASURED");
 strcpy(cpu[10],"% OF APP LIMIT; APP USE EXCLUDES CODE/STACK");
 snprintf(gpu[4],180,"APP VIDEO MEMORY USED*: %.2f MiB (%% N/A)",ui_vram.bytes/mb);
 if(vram_ok){
  snprintf(vram,sizeof(vram),"VRAM %.1f/%.1f MiB",ui_vram.bytes/mb,cfg.localSize/mb);
  snprintf(gpu[2],180,"APP MEMORY LIMIT: %.2f MiB (100%%)",cfg.localSize/mb);
  snprintf(gpu[3],180,"REMAINING BEFORE EXTRA COSTS: %.2f MiB (%.1f%%)",(cfg.localSize-ui_vram.bytes)/mb,100.0*(cfg.localSize-ui_vram.bytes)/cfg.localSize);
  snprintf(gpu[4],180,"APP VIDEO MEMORY USED*: %.2f MiB (%.1f%%)",ui_vram.bytes/mb,100.0*ui_vram.bytes/cfg.localSize);
 }else{snprintf(vram,sizeof(vram),"VRAM %.1f MiB (TOTAL N/A)",ui_vram.bytes/mb);strcpy(gpu[2],"APP MEMORY LIMIT: UNAVAILABLE");strcpy(gpu[3],"REMAINING BEFORE EXTRA COSTS: UNAVAILABLE");}
 strcpy(gpu[5],"ACTUAL FREE SPACE: NOT MEASURED");
 strcpy(gpu[6],"ALLOCATION EXTRA COSTS: NOT MEASURED");
 strcpy(gpu[10],"% OF APP LIMIT; *EXCLUDES ALLOCATION EXTRA COSTS");
 snprintf(out,cap,"%s  %s",ram,vram);
}

SYS_PROCESS_PARAM(1001, 0x100000);

#define MAX_ITEMS 512
#define PATHSZ 1024
#define HOSTBUFFER_SIZE (2*1024*1024)
#define RSX_COMMAND_BUFFER_SIZE (64*1024)
#define HOST_ADDR_ALIGNMENT (1024*1024)

typedef struct { char name[256]; char path[PATHSZ]; int is_dir; unsigned long long size; } item_t;
static item_t items[MAX_ITEMS];
static int item_count=0, selected=0, top_index=0;
static char cwd[PATHSZ]="/dev_hdd0";
static char clipboard[PATHSZ]="";
static char status_line[256]="Ready";
static char success_line[320]="";
static int success_frames=0;
static int running=1, archive_mode=0;
static int export_target_active=0;
static char archive_path[PATHSZ]="";

static gcmContextData *g_ctx=NULL;
// Software blending stays in cached PPU RAM; RSX local memory is upload-only.
static u32 *g_fb[2]={NULL,NULL};
static u32 *g_scanout[2]={NULL,NULL};
static FrameDamage g_damage;
static u32 *g_bg_cache=NULL;
static int g_bg_cache_ready=0;
static u32 *g_model_cache=NULL;
static u32 *g_model_filter_cache=NULL;
static float *g_model_zbuf=NULL;
static int g_model_cache_w=0,g_model_cache_h=0;
static int g_model_filter_w=0,g_model_filter_h=0;
static int g_model_cache_valid=0;
static int g_model_cache_frame=-1000;
static u32 *g_model_base_cache=NULL;
static int g_model_base_valid=0;
static int g_model_base_x=0,g_model_base_y=0,g_model_base_w=0,g_model_base_h=0;
static int *g_model_sx=NULL,*g_model_sy=NULL;
static float *g_model_zinv=NULL,*g_model_nx=NULL,*g_model_ny=NULL;
static int g_model_vertex_cap=0;
static u32 g_fb_off[2]={0,0};
static u32 g_width=1280,g_height=720,g_pitch=0;
static int g_back=0;
static int g_flip_pending=0;

typedef struct { float x,y,z,w,u,v; } icn_hw_vertex_t;
static int g_icn_hw_ready=0;
static rsxVertexProgram *g_icn_hw_vpo=NULL;
static rsxFragmentProgram *g_icn_hw_fpo=NULL;
static void *g_icn_hw_vp_ucode=NULL;
static void *g_icn_hw_fp_ucode=NULL;
static u32 g_icn_hw_fp_offset=0;
/* Hand-authored ARB assembly shaders use the classic fixed RSX bindings:
   POSITION = vertex attrib 0, TEXCOORD0 = vertex attrib 8, sampler = unit 0,
   and MVP rows in vertex constants c[0]..c[3].  Avoid named-parameter parser
   metadata entirely so this stays compatible with legacy PSL1GHT librsx. */
static const u8 g_icn_hw_pos_index=GCM_VERTEX_ATTRIB_POS;
static const u8 g_icn_hw_uv_index=GCM_VERTEX_ATTRIB_TEX0;
static const u8 g_icn_hw_texunit_index=0;
static icn_hw_vertex_t *g_icn_hw_vertices=NULL;
static int g_icn_hw_vertex_capacity=0;
static u32 g_icn_hw_vertex_offset=0;
static u32 *g_icn_hw_texture=NULL;
static u32 g_icn_hw_texture_offset=0;
/* Render the RSX ICN preview into an off-screen color surface.  The CPU UI
   owns the display framebuffers; isolating the model here prevents RSX state
   or clears from disturbing the HUD. */
static u32 *g_icn_hw_color=NULL;
static u32 g_icn_hw_color_offset=0;
static u16 *g_icn_hw_depth=NULL;
static u32 g_icn_hw_depth_offset=0,g_icn_hw_depth_pitch=0;
static char g_icn_hw_archive[PATHSZ]="";
static char g_icn_hw_entry[256]="";
static int g_title_scale=2, g_body_scale=1, g_help_scale=1;
static int g_margin=24, g_title_x=24, g_title_y=20, g_path_x=24, g_path_y=52, g_list_x=28, g_list_y=78, g_row_h=18;

typedef struct {
 int valid;
 char archive[PATHSZ];
 char entry[256];
 char info[128];
 int vertex_count;
 int shape_count;
 int face_count;
 int polygon_count;
 int edge_count;
 int component_count;
 int animation_frame_count;
 float *positions;
 float *uvs;
 u32 *colors;
 u32 *texture;
 u32 *texture_mip64;
 int texture_valid;
 float center[3];
 float scale;
} icon_preview_t;
static icon_preview_t g_preview={0};
static int g_frame_counter=0;
static int g_ui_dirty=1;
static int g_list_dirty=0;
static u32 *g_list_base_cache=NULL;
static int g_list_cache_valid=0;
static int g_list_cache_x=0,g_list_cache_y=0,g_list_cache_w=0,g_list_cache_h=0;
static int g_list_cache_right=0,g_list_cache_rows_y=0,g_list_cache_visible=0;
static u32 *g_preview_base_cache=NULL;
static int g_preview_base_valid=0;
static int g_preview_cache_x=0,g_preview_cache_y=0,g_preview_cache_w=0,g_preview_cache_h=0;

static int scale125(int n){ return (n * 5 + 2) / 4; }

static int endswith(const char *s,const char *x);
static void line(int x0,int y0,int x1,int y1,u32 col);
static void draw_circle_outline(int cx,int cy,int r,u32 col,int thick);
static void draw_disc(int cx,int cy,int r,u32 col);
static int model_update_interval();
static int icn_hw_init();
static int icn_hw_draw_model();

static void configure_ui_metrics(){
 if(g_height >= 1080 || g_width >= 1600){ g_title_scale=3; g_body_scale=2; g_help_scale=2; }
 else if(g_height >= 720 || g_width >= 1200){ g_title_scale=2; g_body_scale=1; g_help_scale=1; }
 else { g_title_scale=1; g_body_scale=1; g_help_scale=1; }
 g_margin = (g_body_scale > 1) ? 40 : 28;
 g_title_x = g_margin;
 g_title_y = (g_body_scale > 1) ? 28 : 22;
 g_path_x = g_margin;
 g_path_y = g_title_y + scale125(8 * g_title_scale) + ((g_body_scale > 1) ? 20 : 18);
 g_list_x = g_margin + 4;
 g_list_y = g_path_y + scale125(8 * g_body_scale) + ((g_body_scale > 1) ? 24 : 20);
 g_row_h = scale125(8 * g_body_scale) + ((g_body_scale > 1) ? 10 : 12);
}

static const u8 *glyph(char c){
 static const u8 blank[7]={0,0,0,0,0,0,0};
 static const u8 unk[7]={31,17,2,4,4,0,4};
 static const u8 A[7]={14,17,17,31,17,17,17},B[7]={30,17,17,30,17,17,30},C[7]={14,17,16,16,16,17,14};
 static const u8 D[7]={30,17,17,17,17,17,30},E[7]={31,16,16,30,16,16,31},F[7]={31,16,16,30,16,16,16};
 static const u8 G[7]={14,17,16,23,17,17,15},H[7]={17,17,17,31,17,17,17},I[7]={14,4,4,4,4,4,14};
 static const u8 J[7]={7,2,2,2,18,18,12},K[7]={17,18,20,24,20,18,17},L[7]={16,16,16,16,16,16,31};
 static const u8 M[7]={17,27,21,21,17,17,17},N[7]={17,25,21,19,17,17,17},O[7]={14,17,17,17,17,17,14};
 static const u8 P[7]={30,17,17,30,16,16,16},Q[7]={14,17,17,17,21,18,13},R[7]={30,17,17,30,20,18,17};
 static const u8 S[7]={15,16,16,14,1,1,30},T[7]={31,4,4,4,4,4,4},U[7]={17,17,17,17,17,17,14};
 static const u8 V[7]={17,17,17,17,17,10,4},W[7]={17,17,17,21,21,21,10},X[7]={17,17,10,4,10,17,17};
 static const u8 Y[7]={17,17,10,4,4,4,4},Z[7]={31,1,2,4,8,16,31};
 static const u8 n0[7]={14,17,19,21,25,17,14},n1[7]={4,12,4,4,4,4,14},n2[7]={14,17,1,2,4,8,31};
 static const u8 n3[7]={30,1,1,14,1,1,30},n4[7]={2,6,10,18,31,2,2},n5[7]={31,16,16,30,1,1,30};
 static const u8 n6[7]={14,16,16,30,17,17,14},n7[7]={31,1,2,4,8,8,8},n8[7]={14,17,17,14,17,17,14},n9[7]={14,17,17,15,1,1,14};
 static const u8 dot[7]={0,0,0,0,0,12,12},comma[7]={0,0,0,0,0,12,8},colon[7]={0,12,12,0,12,12,0},slash[7]={1,2,2,4,8,8,16};
 static const u8 bslash[7]={16,8,8,4,2,2,1},dash[7]={0,0,0,31,0,0,0},under[7]={0,0,0,0,0,0,31};
 static const u8 lbr[7]={6,4,4,4,4,4,6},rbr[7]={12,4,4,4,4,4,12},lp[7]={2,4,8,8,8,4,2},rp[7]={8,4,2,2,2,4,8};
 static const u8 plus[7]={0,4,4,31,4,4,0},eq[7]={0,31,0,31,0,0,0},space[7]={0,0,0,0,0,0,0};
 c=(char)toupper((unsigned char)c);
 if(c>='A'&&c<='Z'){static const u8* t[]={A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z};return t[c-'A'];}
 if(c>='0'&&c<='9'){static const u8* t[]={n0,n1,n2,n3,n4,n5,n6,n7,n8,n9};return t[c-'0'];}
 static const u8 greater[7]={16,8,4,2,4,8,16};
 static const u8 percent[7]={25,25,2,4,8,19,19},asterisk[7]={0,21,14,31,14,21,0};
 switch(c){case '%':return percent;case '*':return asterisk;case '>':return greater;case ' ':return space;case '.':return dot;case ',':return comma;case ':':return colon;case '/':return slash;case '\\':return bslash;case '-':return dash;case '_':return under;case '[':return lbr;case ']':return rbr;case '(':return lp;case ')':return rp;case '+':return plus;case '=':return eq;default:return unk;}
}

static inline u32 blend_argb_over(u32 dst,u32 src){
 u32 a=(src>>24)&255u;
 if(a>=255u) return 0xFF000000u|(src&0x00FFFFFFu);
 if(a==0u) return dst;
 u32 dr=(dst>>16)&255u,dg=(dst>>8)&255u,db=dst&255u;
 u32 sr=(src>>16)&255u,sg=(src>>8)&255u,sb=src&255u;
 u32 inv=255u-a;
 u32 r=(sr*a + dr*inv)/255u;
 u32 g=(sg*a + dg*inv)/255u;
 u32 b=(sb*a + db*inv)/255u;
 return 0xFF000000u|(r<<16)|(g<<8)|b;
}
static inline void px(int x,int y,u32 col){
 if((unsigned)x<g_width&&(unsigned)y<g_height){
  u32 *dst=&g_fb[g_back][y*(g_pitch/4)+x];
  *dst=blend_argb_over(*dst,col);
 }
}
static void fill(u32 col){ for(u32 y=0;y<g_height;y++){u32 *p=g_fb[g_back]+y*(g_pitch/4);for(u32 x=0;x<g_width;x++)p[x]=col;} }
static void rect(int x,int y,int w,int h,u32 col){
 if(w<=0||h<=0)return;
 int x0=x<0?0:x, y0=y<0?0:y, x1=x+w>(int)g_width?(int)g_width:x+w, y1=y+h>(int)g_height?(int)g_height:y+h;
 if(x0>=x1||y0>=y1)return;
 u32 a=(col>>24)&255u;
 if(a>=255u){
  u32 c=0xFF000000u|(col&0x00FFFFFFu);
  for(int yy=y0;yy<y1;yy++){u32 *d=g_fb[g_back]+yy*(g_pitch/4)+x0;for(int xx=x0;xx<x1;xx++)*d++=c;}
 }else if(a){
  for(int yy=y0;yy<y1;yy++){u32 *d=g_fb[g_back]+yy*(g_pitch/4)+x0;for(int xx=x0;xx<x1;xx++,d++)*d=blend_argb_over(*d,col);}
 }
}
static int text_width(const char *s,int scale){ return s ? scale125((int)strlen(s) * 6 * scale) : 0; }
static void text_raw(int x,int y,const char *s,u32 col,int scale){
 int cell_w = 6 * scale;
 int cell_h = 7 * scale;
 for(;*s;s++,x+=scale125(cell_w)){
  const u8 *g=glyph(*s);
  for(int yy=0;yy<7;yy++)for(int xx=0;xx<5;xx++)if(g[yy]&(1<<(4-xx))){
   int sx0 = xx * scale, sx1 = (xx + 1) * scale;
   int sy0 = yy * scale, sy1 = (yy + 1) * scale;
   int dx0 = x + scale125(sx0);
   int dx1 = x + scale125(sx1);
   int dy0 = y + scale125(sy0);
   int dy1 = y + scale125(sy1);
   rect(dx0, dy0, dx1 - dx0, dy1 - dy0, col);
  }
 }
}
static void text(int x,int y,const char *s,u32 col,int scale){
 /* Modern UI treatment: subtle single-pixel shadow instead of the heavy
    arcade/terminal outline used by earlier builds. */
 int shadow=(scale>=3)?2:1;
 text_raw(x+shadow,y+shadow,s,0xFF101820u,scale);
 text_raw(x,y,s,col,scale);
}
static void textf(int x,int y,u32 col,int scale,const char *fmt,...){char b[512];va_list ap;va_start(ap,fmt);vsnprintf(b,sizeof(b),fmt,ap);va_end(ap);text(x,y,b,col,scale);}
static int wrap_text_lines(const char *src,int maxw,int scale,char lines[][256],int max_lines){
 int count=0;
 const char *p=src;
 while(*p && count<max_lines){
  while(*p==' ')p++;
  if(!*p)break;
  char line[256]={0};
  int line_len=0;
  int first_word=1;
  const char *scan=p;
  while(*scan){
   while(*scan==' ')scan++;
   if(!*scan)break;
   const char *word_start=scan;
   while(*scan && *scan!=' ')scan++;
   int word_len=(int)(scan-word_start);
   char candidate[256];
   if(first_word) snprintf(candidate,sizeof(candidate),"%.*s",word_len,word_start);
   else snprintf(candidate,sizeof(candidate),"%s %.*s",line,word_len,word_start);
   if(!first_word && text_width(candidate,scale)>maxw) break;
   snprintf(line,sizeof(line),"%s",candidate);
   line_len=(int)strlen(line);
   first_word=0;
  }
  if(first_word){
   int chars=maxw/text_width("A",scale);
   if(chars<1)chars=1;
   snprintf(line,sizeof(line),"%.*s",chars,p);
   p += strlen(line);
  }else{
   p += line_len;
  }
  while(*p==' ')p++;
  snprintf(lines[count],256,"%s",line);
  count++;
 }
 if(*p && count>0){
  size_t used=strlen(lines[count-1]);
  if(used<252){
   if(used>0 && lines[count-1][used-1]!='.') strcat(lines[count-1],"...");
  }
 }
 return count;
}


static u32 lerp_color(u32 a,u32 b,int t,int max_t){
 if(max_t<=0)return a;
 int aa=(a>>24)&255, ba=(b>>24)&255;
 int alpha=aa+(ba-aa)*t/max_t;
 int ar=(a>>16)&255, ag=(a>>8)&255, ab=a&255;
 int br=(b>>16)&255, bg=(b>>8)&255, bb=b&255;
 int r=ar + (br-ar)*t/max_t;
 int g=ag + (bg-ag)*t/max_t;
 int bl=ab + (bb-ab)*t/max_t;
 return ((u32)alpha<<24)|((u32)r<<16)|((u32)g<<8)|(u32)bl;
}
static void gradient_fill_v(u32 top,u32 bottom){
 for(u32 y=0;y<g_height;y++){
  u32 c=lerp_color(top,bottom,(int)y,(int)(g_height?g_height-1:1));
  u32 *p=g_fb[g_back]+y*(g_pitch/4);
  for(u32 x=0;x<g_width;x++)p[x]=c;
 }
}
static void panel_frame(int x,int y,int w,int h,u32 fillc,u32 border,u32 hi){
 rect(x,y,w,h,fillc);
 rect(x,y,w,2,hi); rect(x,y,2,h,hi);
 rect(x,y+h-2,w,2,border); rect(x+w-2,y,2,h,border);
}
static void round_rect(int x,int y,int w,int h,int r,u32 col){
 if(w<=0||h<=0)return;
 if(r<1){rect(x,y,w,h,col);return;}
 if(r*2>w)r=w/2; if(r*2>h)r=h/2;
 rect(x+r,y,w-2*r,h,col); rect(x,y+r,r,h-2*r,col); rect(x+w-r,y+r,r,h-2*r,col);
 for(int yy=0;yy<r;yy++)for(int xx=0;xx<r;xx++){
  int dx=r-1-xx,dy=r-1-yy; if(dx*dx+dy*dy<=r*r){
   px(x+xx,y+yy,col); px(x+w-1-xx,y+yy,col); px(x+xx,y+h-1-yy,col); px(x+w-1-xx,y+h-1-yy,col);
  }
 }
}
static void gradient_rect_v(int x,int y,int w,int h,u32 top,u32 bottom){
 if(h<=0||w<=0)return;
 for(int yy=0;yy<h;yy++)rect(x,y+yy,w,1,lerp_color(top,bottom,yy,h>1?h-1:1));
}
static void modern_card(int x,int y,int w,int h,u32 fillc,u32 border,int radius){
 round_rect(x+5,y+8,w,h,radius,0x3810181Cu);
 round_rect(x+2,y+3,w,h,radius,0x20000000u);
 round_rect(x,y,w,h,radius,fillc);
 /* glass-like sheen */
 gradient_rect_v(x+2,y+2,w-4,h/3,0x30FFFFFFu,0x00000000u);
 rect(x+radius,y,w-2*radius,1,border); rect(x+radius,y+h-1,w-2*radius,1,border);
 rect(x,y+radius,1,h-2*radius,border); rect(x+w-1,y+radius,1,h-2*radius,border);
}
static void draw_wire_cube(int cx,int cy,int size,float ang,u32 col){
 float ca=cosf(ang),sa=sinf(ang),cb=cosf(ang*0.67f),sb=sinf(ang*0.67f);
 int sx[8],sy[8];
 for(int i=0;i<8;i++){
  float x=(i&1)?1.0f:-1.0f, y=(i&2)?1.0f:-1.0f, z=(i&4)?1.0f:-1.0f;
  float xr=x*ca+z*sa, zr=-x*sa+z*ca;
  float yr=y*cb-zr*sb, zz=y*sb+zr*cb+4.2f;
  sx[i]=cx+(int)(xr*(float)size/zz); sy[i]=cy+(int)(yr*(float)size/zz);
 }
 static const u8 e[12][2]={{0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7}};
 for(int i=0;i<12;i++)line(sx[e[i][0]],sy[e[i][0]],sx[e[i][1]],sy[e[i][1]],col);
}
static void draw_memory_card_silhouette(int x,int y,int w,int h,u32 col,u32 hi){
 /* Oversized decorative PS2 memory-card silhouette for the background. */
 rect(x,y,w,h,col);
 int notch=w/5;
 rect(x+w-notch,y,notch,h/5,0xFF020814u);
 rect(x+5,y+5,w-10,2,hi);
 rect(x+5,y+h-7,w-10,2,hi);
 for(int i=0;i<5;i++) rect(x+8+i*(w-20)/5,y+h/5,3,h/3,hi);
 for(int i=0;i<3;i++) rect(x+10,y+h*3/4+i*4,w-20,1,hi);
}
static void draw_ps2_symbol_cloud(){
 int t=g_frame_counter;
 int cx1=70+((t/3)%140), cy1=(int)g_height/3;
 int cx2=(int)g_width-150-((t/4)%110), cy2=(int)g_height*2/3;
 int s=(g_body_scale>1)?34:22;
 /* triangle */
 line(cx1,cy1-s,cx1-s,cy1+s,0xFF60E2B8u); line(cx1,cy1-s,cx1+s,cy1+s,0xFF60E2B8u); line(cx1-s,cy1+s,cx1+s,cy1+s,0xFF60E2B8u);
 /* square */
 rect(cx2-s,cy2-s,s*2,2,0xFFE7A84Fu); rect(cx2-s,cy2+s-2,s*2,2,0xFFE7A84Fu); rect(cx2-s,cy2-s,2,s*2,0xFFE7A84Fu); rect(cx2+s-2,cy2-s,2,s*2,0xFFE7A84Fu);
 /* circle and cross */
 draw_circle_outline((int)g_width/4,(int)g_height*4/5,s,0xFFCF72DCu,2);
 int xx=(int)g_width*3/4, yy=(int)g_height/5;
 line(xx-s,yy-s,xx+s,yy+s,0xFFFF7188u); line(xx-s,yy+s,xx+s,yy-s,0xFFFF7188u);
}
static void draw_disc(int cx,int cy,int r,u32 col);
static void draw_ps2_logo_bars(int x,int y,int scale){
 int bw=scale125(3*scale)+1, gap=scale125(scale)+1;
 /* abstract PS2 wordmark-like strokes: blue/cyan, kept tiny and decorative */
 rect(x,y,bw,scale125(12*scale),0xFF3C7BFFu);
 rect(x+bw+gap,y+scale125(2*scale),bw,scale125(8*scale),0xFF6FD6FFu);
 rect(x+(bw+gap)*2,y+scale125(4*scale),bw,scale125(6*scale),0xFF8A7DFFu);
}
static void draw_ps2_front_details(int x,int y,int w,int h,u32 trim){
 int face_y=y+h*2/3;
 /* memory card slots */
 int sx=x+w/13, sw=w/7, sh=h/12;
 round_rect(sx,face_y+5,sw,sh,2,0xB5060A0Fu); rect(sx+4,face_y+7,sw-8,1,0x55FFFFFFu);
 round_rect(sx+sw+8,face_y+5,sw,sh,2,0xB5060A0Fu); rect(sx+sw+12,face_y+7,sw-8,1,0x55FFFFFFu);
 /* controller ports */
 int py=face_y+sh+12;
 for(int i=0;i<2;i++){int px0=sx+i*(sw+8);round_rect(px0,py,sw,sh+3,2,0xC204070Bu);rect(px0+5,py+3,sw-10,2,0x446FA8FFu);}
 /* optical drive tray */
 int dx=x+w*55/100, dw=w*32/100, dh=h/9;
 round_rect(dx,face_y+4,dw,dh,2,0xC206090Eu); rect(dx+5,face_y+7,dw-10,1,0x50FFFFFFu);
 /* power/eject */
 int br=h/20; if(br<3)br=3;
 draw_disc(x+w*91/100,face_y+dh/2+2,br,trim);
 draw_disc(x+w*91/100,face_y+dh+br+7,br,0xFF4FAE65u);
}
static void draw_fat_ps2(int x,int y,int w,int h,u32 shell,u32 rib,u32 trim,u32 glow){
 /* glow behind the machine */
 draw_disc(x+w/2,y+h/2,(w>h?w:h)*3/5,glow);
 /* shadow */
 round_rect(x+8,y+12,w,h,5,0x4A000000u);
 /* lower chassis */
 round_rect(x,y+h/6,w,h*5/6,5,shell);
 /* characteristic stacked/ribbed top slabs */
 int top_h=h*2/3;
 for(int i=0;i<12;i++){
  int yy=y+4+i*(top_h-10)/12;
  rect(x+6,yy,w-12,2,rib);
  if(i<11) rect(x+12,yy+3,w-24,1,0x18FFFFFFu);
 }
 /* raised center top panel */
 int cx=x+w/4, cw=w/2;
 round_rect(cx,y+8,cw,h/3,3,lerp_color(shell,0xFFFFFFFFu,18,100));
 rect(cx+6,y+12,cw-12,2,0x2FFFFFFFu);
 /* front face separation */
 rect(x+4,y+h*2/3,w-8,2,trim);
 rect(x+4,y+h*2/3+4,w-8,1,0x22FFFFFFu);
 draw_ps2_front_details(x,y,w,h,trim);
 draw_ps2_logo_bars(cx+cw/2-scale125(9),y+h/8,1);
}
static void draw_ps2_slim(int x,int y,int w,int h,u32 shell,u32 trim,u32 glow){
 draw_disc(x+w/2,y+h/2,(w>h?w:h)*3/5,glow);
 round_rect(x+7,y+10,w,h,7,0x42000000u);
 round_rect(x,y,w,h,7,shell);
 /* lid seam and slim ridges */
 rect(x+w/2,y+5,1,h-10,0x30FFFFFFu);
 for(int i=0;i<6;i++) rect(x+8,y+10+i*5,w/3,1,0x2AFFFFFFu);
 round_rect(x+w*58/100,y+h/5,w*32/100,h*3/5,5,0x36000000u);
 rect(x+w*58/100,y+h/2,w*32/100,2,trim);
 draw_ps2_logo_bars(x+10,y+9,1);
}
static void draw_bios_tower(int x,int base_y,int w,int h,u32 body,u32 edge){
 if(w<4||h<8)return;
 int top_y=base_y-h;
 /* subtle perspective: narrow at top */
 int inset=w/5;
 for(int yy=0;yy<h;yy++){
  int t=yy;
  int side=(inset*(h-t))/h;
  int rw=w-side*2;
  if(rw<2)rw=2;
  u32 c=lerp_color(body,0x10000000u,yy,h);
  rect(x+side,top_y+yy,rw,1,c);
 }
 line(x+inset,top_y,x,base_y,edge);
 line(x+w-inset-1,top_y,x+w-1,base_y,edge);
 rect(x+inset,top_y,w-inset*2,1,edge);
}
static void render_ps2_wallpaper_scene(){
 /* Blend of a fat-PS2 product close-up and the blue-black PS2 startup void. */
 gradient_fill_v(0xFF101827u,0xFF030507u);
 int W=(int)g_width,H=(int)g_height;
 int u=(g_body_scale>1)?2:1;
 /* BIOS-like blue mist / horizon */
 draw_disc(W/2,H*48/100,(g_body_scale>1)?310:180,0x183866C9u);
 draw_disc(W*72/100,H*34/100,(g_body_scale>1)?170:100,0x103D75FFu);
 draw_disc(W*27/100,H*38/100,(g_body_scale>1)?150:88,0x102D5AC4u);
 int horizon=H*66/100;
 rect(0,horizon,W,1,0x2A4D78B6u);
 for(int i=1;i<=5;i++)rect(0,horizon+i*i*7,W,1,0x0D5A8DD8u);
 /* Floating BIOS memory-tower field behind the console. */
 const u32 tower_cols[4]={0x382A5FB8u,0x303B76D1u,0x28234D9Cu,0x302B63B3u};
 for(int i=0;i<18;i++){
  int tx=(i*97+W/10)%W;
  int tw=(g_body_scale>1)?(18+(i%4)*7):(10+(i%4)*4);
  int th=(g_body_scale>1)?(55+(i%6)*28):(32+(i%6)*16);
  int by=horizon-8+(i%3)*9;
  draw_bios_tower(tx,by,tw,th,tower_cols[i%4],0x284F8DE8u);
 }
 /* Hero fat PS2: large close-up, lower center, like a product shot. */
 int hero_w=(g_body_scale>1)?760:455;
 int hero_h=(g_body_scale>1)?290:174;
 int hero_x=W/2-hero_w/2;
 int hero_y=H-hero_h-scale125(34*u);
 draw_fat_ps2(hero_x,hero_y,hero_w,hero_h,0xFA111317u,0xFF292E35u,0xFF316BFFu,0x20315BCEu);
 /* A silver and ocean-blue edge variant in the far background. */
 int small_w=(g_body_scale>1)?245:145, small_h=(g_body_scale>1)?105:63;
 draw_fat_ps2(scale125(26*u),scale125(70*u),small_w,small_h,0xD6C8CDD2u,0xFFADB3BAu,0xFF74899Fu,0x0CFFFFFFu);
 draw_ps2_slim(W-small_w-scale125(26*u),scale125(78*u),small_w,small_h,0xD82C6087u,0xFF9AE2FFu,0x102D7CE0u);
 /* Minimal PS2 motif, deliberately understated. */
 draw_ps2_logo_bars(W/2-scale125(13*u),scale125(32*u),2);
}

static void draw_background_art(){
 if(!g_bg_cache){
  size_t bytes=(size_t)g_pitch*(size_t)g_height;
  g_bg_cache=(u32*)memalign(64,bytes);
  if(g_bg_cache)memset(g_bg_cache,0,bytes);
 }
 if(g_bg_cache && !g_bg_cache_ready){
  u32 *save=g_fb[g_back];
  g_fb[g_back]=g_bg_cache;
  render_ps2_wallpaper_scene();
  g_fb[g_back]=save;
  g_bg_cache_ready=1;
 }
 if(g_bg_cache){ memcpy(g_fb[g_back],g_bg_cache,(size_t)g_pitch*(size_t)g_height); return; }
 render_ps2_wallpaper_scene();
}
static void draw_circle_outline(int cx,int cy,int r,u32 col,int thick){
 int rr=r*r, ir=(r-thick>0)?(r-thick)*(r-thick):0;
 for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++){int d=x*x+y*y; if(d<=rr && d>=ir) px(cx+x,cy+y,col);}
}
static void draw_disc(int cx,int cy,int r,u32 col){ for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++) if(x*x+y*y<=r*r) px(cx+x,cy+y,col); }
static int draw_face_button_token(const char *token,int x,int y,int scale){
 int s=scale125(16*scale)+8; int r=s/2; int cx=x+r, cy=y+r;
 draw_disc(cx,cy,r,0xFF2B3540u); draw_circle_outline(cx,cy,r-1,0xFF758493u,2);
 if(!strcmp(token,"X")){ line(cx-r/2,cy-r/2,cx+r/2,cy+r/2,0xFF61C7FFu); line(cx-r/2,cy+r/2,cx+r/2,cy-r/2,0xFF61C7FFu); line(cx-r/2+1,cy-r/2,cx+r/2+1,cy+r/2,0xFF61C7FFu); line(cx-r/2+1,cy+r/2,cx+r/2+1,cy-r/2,0xFF61C7FFu); }
 else if(!strcmp(token,"O")){ draw_circle_outline(cx,cy,r/2,0xFFFF616Eu,2); }
 else if(!strcmp(token,"SQUARE")){ int q=r/2; rect(cx-q,cy-q,q*2,q*2,0x00000000); draw_circle_outline(cx,cy,r,0xFF97AFC5u,2); rect(cx-q,cy-q,q*2,2,0xFFFF69E6u); rect(cx-q,cy+q-2,q*2,2,0xFFFF69E6u); rect(cx-q,cy-q,2,q*2,0xFFFF69E6u); rect(cx+q-2,cy-q,2,q*2,0xFFFF69E6u); }
 else if(!strcmp(token,"TRIANGLE")){ int h=r/2+1; line(cx,cy-h,cx-h,cy+h/2,0xFF61FF8Du); line(cx,cy-h,cx+h,cy+h/2,0xFF61FF8Du); line(cx-h,cy+h/2,cx+h,cy+h/2,0xFF61FF8Du); }
 return s;
}
static int draw_pill_token(const char *token,int x,int y,int scale){
 int tw=text_width(token,scale); int h=scale125(10*scale)+8; int w=tw+18;
 round_rect(x,y,w,h,5,0xFF303A46u);
 rect(x+5,y+2,w-10,1,0xFF596878u);
 text(x+9,y+4,token,0xFFF5F8FBu,scale);
 return w;
}
static int draw_lr_token(int x,int y,int scale){
 int h=scale125(10*scale)+8; int w=text_width("LEFT/RIGHT",scale)+24;
 round_rect(x,y,w,h,5,0xFF303A46u); rect(x+5,y+2,w-10,1,0xFF596878u);
 int cy=y+h/2;
 line(x+8,cy,x+14,cy-4,0xFFB9C7D5u); line(x+8,cy,x+14,cy+4,0xFFB9C7D5u);
 line(x+w-8,cy,x+w-14,cy-4,0xFFB9C7D5u); line(x+w-8,cy,x+w-14,cy+4,0xFFB9C7D5u);
 text(x+23,y+4,"LEFT/RIGHT",0xFFF5F8FBu,scale);
 return w;
}
static int token_width_for(const char *token,int scale){
 if(!strcmp(token,"X")||!strcmp(token,"O")||!strcmp(token,"SQUARE")||!strcmp(token,"TRIANGLE")) return scale125(16*scale)+8;
 if(!strcmp(token,"LEFT/RIGHT")) return text_width("LEFT/RIGHT",scale)+22;
 return text_width(token,scale)+16;
}
struct legend_entry_t{ const char *token; const char *action; };
static int measure_control_legend_lines(const legend_entry_t *entries,int count,int maxw,int scale){
 int x=0, lines=1;
 for(int i=0;i<count;i++){
  int ew=token_width_for(entries[i].token,scale)+8+text_width(entries[i].action,scale)+18;
  if(x>0 && x+ew>maxw){ lines++; x=0; }
  x += ew;
 }
 return lines;
}
static void draw_control_legend(const legend_entry_t *entries,int count,int x,int y,int maxw,int scale){
 int cx=x, cy=y; int line_h=scale125(10*scale)+12;
 for(int i=0;i<count;i++){
  int tw=token_width_for(entries[i].token,scale);
  int aw=text_width(entries[i].action,scale);
  int ew=tw+8+aw+18;
  if(cx>x && cx-x+ew>maxw){ cx=x; cy+=line_h; }
  if(!strcmp(entries[i].token,"LEFT/RIGHT")) draw_lr_token(cx,cy,scale);
  else if(!strcmp(entries[i].token,"X")||!strcmp(entries[i].token,"O")||!strcmp(entries[i].token,"SQUARE")||!strcmp(entries[i].token,"TRIANGLE")) draw_face_button_token(entries[i].token,cx,cy,scale);
  else draw_pill_token(entries[i].token,cx,cy,scale);
  text(cx+tw+8,cy+4,entries[i].action,0xFFF0E8D8u,scale);
  cx += ew;
 }
}
static void draw_folder_icon(int x,int y,int size,int selected){
 int w=size+9,h=size+4;
 /* modern Explorer-style folder with depth and front flap */
 u32 back=selected?0xFFFFD86Au:0xFFF2C65Bu;
 u32 front=selected?0xFFFFC542u:0xFFE9B83Eu;
 round_rect(x+3,y+3,w-3,h-2,4,0x38000000u);
 round_rect(x+2,y,w/2+3,h/3+3,3,0xFFFFE6A2u);
 round_rect(x,y+h/5,w,h*4/5,4,back);
 gradient_rect_v(x+2,y+h/3,w-4,h*2/3-3,0xFFFFDB77u,front);
 rect(x+3,y+h-3,w-6,2,0x80A66C11u);
 if(selected)rect(x+4,y+h/3,w-8,2,0x99FFFFFFu);
}
static void draw_memory_card_icon(int x,int y,int size,u32 shell,const char *tag,int selected){
 int w=size+5,h=size+7;
 round_rect(x+3,y+4,w,h,3,0x42000000u);
 round_rect(x,y,w,h,3,shell);
 rect(x+w-6,y,6,6,0xB0000000u);
 for(int i=0;i<4;i++)rect(x+4+i*4,y+5,2,h/3,0x45FFFFFFu);
 rect(x+3,y+h*2/3,w-6,1,0x75FFFFFFu);
 draw_ps2_logo_bars(x+4,y+h/2-3,1);
 text(x+4,y+h-scale125(7)-2,tag,selected?0xFFFFFFFFu:0xFFF2F6FAu,1);
}
static void draw_file_icon(int x,int y,int size,const char *name,int selected){
 if(endswith(name,".psu")){draw_memory_card_icon(x,y,size,selected?0xFF4979C9u:0xFF315E9Eu,"PSU",selected);return;}
 if(endswith(name,".vm1")||endswith(name,".vm2")){draw_memory_card_icon(x,y,size,selected?0xFF4F9B78u:0xFF356F58u,"VMC",selected);return;}
 int w=size+3,h=size+7;
 u32 accent=0xFF6F7B88u,paper=selected?0xFFFFFFFFu:0xFFF1F4F7u;const char *tag="FILE";
 if(endswith(name,".icn")){accent=0xFFA45BDBu;tag="ICN";}
 else if(endswith(name,".cfg")){accent=0xFF6F7B88u;tag="CFG";}
 else if(endswith(name,".elf")){accent=0xFFDD5B64u;tag="ELF";}
 round_rect(x+3,y+4,w,h,3,0x3C000000u);
 round_rect(x,y,w,h,3,paper);
 int fold=w/4+1;rect(x+w-fold,y,fold,fold,0xFFD8E0E7u);line(x+w-fold,y,x+w-1,y+fold-1,0xFF9CA8B3u);
 rect(x,y+4,3,h-8,accent);
 if(endswith(name,".icn")){
  round_rect(x+5,y+6,w-10,h/2,2,0xFF20252Du);
  draw_disc(x+w/2,y+6+h/4,h/7,0xFFC874F0u);
 }
 int strip=scale125(7*g_body_scale)+2;if(strip>h/2)strip=h/2;
 round_rect(x+4,y+h-strip-2,w-8,strip,2,accent);
 text(x+6,y+h-strip-3,tag,0xFFFFFFFFu,1);
}
static void format_file_size(unsigned long long bytes,int is_dir,char *out,size_t outsz){
 if(!out||!outsz)return;
 if(is_dir){ snprintf(out,outsz,"<DIR>"); return; }
 const unsigned long long KB=1024ULL, MB=1024ULL*1024ULL, GB=1024ULL*1024ULL*1024ULL;
 if(bytes<KB){ snprintf(out,outsz,"%llu B",bytes); return; }
 double v; const char *unit;
 if(bytes<MB){ v=(double)bytes/(double)KB; unit="KB"; }
 else if(bytes<GB){ v=(double)bytes/(double)MB; unit="MB"; }
 else { v=(double)bytes/(double)GB; unit="GB"; }
 if(v<10.0) snprintf(out,outsz,"%.1f %s",v,unit);
 else snprintf(out,outsz,"%.0f %s",v,unit);
}
static void draw_browser_emblem(int x,int y,int s){
 round_rect(x,y,s,s,4,0xA83A4652u);
 int q=(s-7)/2;
 rect(x+3,y+3,q,q,0xFF4CC2FFu); rect(x+5+q,y+3,q,q,0xFF36C5A5u);
 rect(x+3,y+5+q,q,q,0xFFF2B84Bu); rect(x+5+q,y+5+q,q,q,0xFFB86FD4u);
}
static u16 rd16le_local(const u8 *p){ return (u16)(p[0] | ((u16)p[1] << 8)); }
static u32 rd32le_local(const u8 *p){ return (u32)p[0] | ((u32)p[1]<<8) | ((u32)p[2]<<16) | ((u32)p[3]<<24); }
static s16 rs16le_local(const u8 *p){ return (s16)rd16le_local(p); }
static u32 make_rgb(u8 r,u8 g,u8 b){ return 0xFF000000u|((u32)r<<16)|((u32)g<<8)|(u32)b; }
static int clampi(int v,int lo,int hi){ return v<lo?lo:(v>hi?hi:v); }
static float max3f(float a,float b,float c){ float m=a>b?a:b; return m>c?m:c; }

static void free_preview(){
 free(g_preview.positions); g_preview.positions=NULL;
 free(g_preview.uvs); g_preview.uvs=NULL;
 free(g_preview.colors); g_preview.colors=NULL;
 free(g_preview.texture); g_preview.texture=NULL;
 free(g_preview.texture_mip64); g_preview.texture_mip64=NULL;
 g_preview.texture_valid=0;
 g_preview.valid=0; g_preview.vertex_count=0; g_preview.shape_count=0; g_preview.face_count=0; g_preview.polygon_count=0; g_preview.edge_count=0; g_preview.component_count=0; g_preview.animation_frame_count=0; g_preview.scale=1.0f;
 g_preview.center[0]=g_preview.center[1]=g_preview.center[2]=0.0f;
 g_preview.archive[0]=g_preview.entry[0]=0;
 g_model_cache_valid=0;g_model_base_valid=0;free(g_model_filter_cache);g_model_filter_cache=NULL;g_model_filter_w=g_model_filter_h=0;
}

static u32 icn_bgr555(u16 v){
 u8 r=(u8)((v & 0x1Fu)<<3);
 u8 g=(u8)(((v>>5) & 0x1Fu)<<3);
 u8 b=(u8)(((v>>10)& 0x1Fu)<<3);
 return make_rgb(r,g,b);
}

typedef struct { int a,b; } edge_pair_t;
static int cmp_edge_pair(const void *A,const void *B){
 const edge_pair_t *a=(const edge_pair_t*)A,*b=(const edge_pair_t*)B;
 if(a->a!=b->a)return a->a-b->a;return a->b-b->b;
}
static int uf_find(int *p,int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;}
static void uf_union(int *p,int a,int b){a=uf_find(p,a);b=uf_find(p,b);if(a!=b)p[b]=a;}
static void compute_mesh_stats(const float *positions,int vertex_count,int *edge_count,int *component_count){
 *edge_count=0;*component_count=0;
 if(!positions||vertex_count<3)return;
 int faces=vertex_count/3;
 int *uid=(int*)malloc((size_t)vertex_count*sizeof(int));
 int *uniq_src=(int*)malloc((size_t)vertex_count*sizeof(int));
 int *owner=(int*)malloc((size_t)vertex_count*sizeof(int));
 int *parent=(int*)malloc((size_t)faces*sizeof(int));
 edge_pair_t *edges=(edge_pair_t*)malloc((size_t)faces*3u*sizeof(edge_pair_t));
 if(!uid||!uniq_src||!owner||!parent||!edges){free(uid);free(uniq_src);free(owner);free(parent);free(edges);*edge_count=faces*3;*component_count=1;return;}
 int uniq=0;
 for(int i=0;i<vertex_count;i++){
  float x=positions[(size_t)i*3u],y=positions[(size_t)i*3u+1],z=positions[(size_t)i*3u+2];int found=-1;
  for(int u=0;u<uniq;u++){int j=uniq_src[u];if(positions[(size_t)j*3u]==x&&positions[(size_t)j*3u+1]==y&&positions[(size_t)j*3u+2]==z){found=u;break;}}
  if(found<0){found=uniq;uniq_src[uniq++]=i;}uid[i]=found;
 }
 for(int i=0;i<uniq;i++)owner[i]=-1;for(int f=0;f<faces;f++)parent[f]=f;
 int ei=0;
 for(int f=0;f<faces;f++){
  int a=uid[f*3],b=uid[f*3+1],c=uid[f*3+2];int v[3]={a,b,c};
  for(int k=0;k<3;k++){if(owner[v[k]]<0)owner[v[k]]=f;else uf_union(parent,f,owner[v[k]]);}
  int ea[3]={a,b,c},eb[3]={b,c,a};
  for(int k=0;k<3;k++){int x=ea[k],y=eb[k];if(x>y){int t=x;x=y;y=t;}edges[ei].a=x;edges[ei].b=y;ei++;}
 }
 qsort(edges,(size_t)ei,sizeof(edge_pair_t),cmp_edge_pair);int ec=0;
 for(int i=0;i<ei;i++)if(i==0||edges[i].a!=edges[i-1].a||edges[i].b!=edges[i-1].b)ec++;
 int cc=0;for(int f=0;f<faces;f++)if(uf_find(parent,f)==f)cc++;
 *edge_count=ec;*component_count=cc>0?cc:1;
 free(uid);free(uniq_src);free(owner);free(parent);free(edges);
}

static int parse_icn_preview(const void *data,size_t size,const char *archive,const char *entry){
 free_preview();
 snprintf(g_preview.archive,sizeof(g_preview.archive),"%s",archive?archive:"");
 snprintf(g_preview.entry,sizeof(g_preview.entry),"%s",entry?entry:"");
 snprintf(g_preview.info,sizeof(g_preview.info),"Preview unavailable");
 if(!data || size<20){ snprintf(g_preview.info,sizeof(g_preview.info),"ICN too small"); return 0; }
 const u8 *p=(const u8*)data, *endp=p+size;
 u32 magic=rd32le_local(p+0);
 u32 shapes=rd32le_local(p+4);
 u32 tex_type=rd32le_local(p+8);
 u32 vertex_count=rd32le_local(p+16);
 if(!((magic==0x00010000u)||(magic==0x00000100u)||(magic==0x01000000u))){ snprintf(g_preview.info,sizeof(g_preview.info),"Unsupported ICN header"); return 0; }
 if(shapes<1||shapes>64||vertex_count<3||vertex_count>4096||(vertex_count%3)!=0){ snprintf(g_preview.info,sizeof(g_preview.info),"ICN geometry unsupported"); return 0; }
 size_t per_vertex=(size_t)shapes*8u + 8u + 8u;
 size_t vertex_bytes=(size_t)vertex_count*per_vertex;
 if(size < 20u + vertex_bytes + 20u){ snprintf(g_preview.info,sizeof(g_preview.info),"ICN truncated"); return 0; }
 float *positions=(float*)malloc((size_t)shapes*(size_t)vertex_count*3u*sizeof(float));
 float *uvs=(float*)malloc((size_t)vertex_count*2u*sizeof(float));
 u32 *colors=(u32*)malloc((size_t)vertex_count*sizeof(u32));
 u32 *texture=(u32*)calloc(128u*128u,sizeof(u32));
 u32 *texture_mip64=(u32*)calloc(64u*64u,sizeof(u32));
 if(!positions||!uvs||!colors||!texture||!texture_mip64){ free(positions); free(uvs); free(colors); free(texture); free(texture_mip64); snprintf(g_preview.info,sizeof(g_preview.info),"Out of memory"); return 0; }
 const u8 *cur=p+20;
 u32 n_frames=0;
 int tex_ok=0;
 float minx=1e9f,miny=1e9f,minz=1e9f,maxx=-1e9f,maxy=-1e9f,maxz=-1e9f;
 for(u32 i=0;i<vertex_count;i++){
  for(u32 s=0;s<shapes;s++){
   if(cur+8>endp) goto truncated;
   float x=(float)rs16le_local(cur+0)/4096.0f;
   float y=(float)rs16le_local(cur+2)/4096.0f;
   float z=(float)rs16le_local(cur+4)/4096.0f;
   size_t idx=((size_t)s*(size_t)vertex_count+(size_t)i)*3u;
   positions[idx+0]=x; positions[idx+1]=y; positions[idx+2]=z;
   if(x<minx)minx=x; if(y<miny)miny=y; if(z<minz)minz=z;
   if(x>maxx)maxx=x; if(y>maxy)maxy=y; if(z>maxz)maxz=z;
   cur+=8;
  }
  if(cur+8>endp) goto truncated;
  cur+=8; /* normal */
  if(cur+8>endp) goto truncated;
  /* Texture_Data: s16 U, s16 V, RGBA */
  uvs[(size_t)i*2u+0]=(float)rs16le_local(cur+0)/4096.0f;
  uvs[(size_t)i*2u+1]=(float)rs16le_local(cur+2)/4096.0f;
  colors[i]=make_rgb(cur[4],cur[5],cur[6]);
  cur+=8;
 }
 if(cur+20>endp) goto truncated;
 /* Animation_Header is 20 bytes; n_frames is the final u32. */
 n_frames=rd32le_local(cur+16);
 if(n_frames>4096u) goto truncated;
 cur+=20;
 for(u32 i=0;i<n_frames;i++){
  if(cur+8>endp) goto truncated;
  u32 n_keys=rd32le_local(cur+4);
  cur+=8;
  if(n_keys>65536u || (size_t)(endp-cur)<(size_t)n_keys*8u) goto truncated;
  cur+=(size_t)n_keys*8u;
 }
 if(tex_type<=7u){
  if((size_t)(endp-cur)>=128u*128u*2u){
   for(int i=0;i<128*128;i++,cur+=2) texture[i]=icn_bgr555(rd16le_local(cur));
   tex_ok=1;
  }
 }else{
  if(cur+4<=endp){
   u32 packed_size=rd32le_local(cur); (void)packed_size; cur+=4;
   int out=0;
   while(out<128*128 && cur+2<=endp){
    u16 code=rd16le_local(cur); cur+=2;
    if((code & 0xFF00u)==0xFF00u){
     int count=(0x10000u-(u32)code)&0xFFFFu;
     if(count<=0 || count>128*128-out || (size_t)(endp-cur)<(size_t)count*2u) break;
     for(int k=0;k<count;k++,cur+=2) texture[out++]=icn_bgr555(rd16le_local(cur));
    }else{
     int count=(int)code;
     if(count<=0 || count>128*128-out || cur+2>endp) break;
     u32 pxcol=icn_bgr555(rd16le_local(cur)); cur+=2;
     for(int k=0;k<count;k++) texture[out++]=pxcol;
    }
   }
   tex_ok=(out==128*128);
  }
 }
 {
  float dx=maxx-minx,dy=maxy-miny,dz=maxz-minz;
  float extent=max3f(dx,dy,dz); if(extent<0.001f) extent=1.0f;
  if(tex_ok){
   for(int my=0;my<64;my++)for(int mx=0;mx<64;mx++){
    u32 c0=texture[(my*2)*128+mx*2],c1=texture[(my*2)*128+mx*2+1];
    u32 c2=texture[(my*2+1)*128+mx*2],c3=texture[(my*2+1)*128+mx*2+1];
    u32 r=(((c0>>16)&255)+((c1>>16)&255)+((c2>>16)&255)+((c3>>16)&255)+2)/4;
    u32 g=(((c0>>8)&255)+((c1>>8)&255)+((c2>>8)&255)+((c3>>8)&255)+2)/4;
    u32 b=((c0&255)+(c1&255)+(c2&255)+(c3&255)+2)/4;
    texture_mip64[my*64+mx]=0xFF000000u|(r<<16)|(g<<8)|b;
   }
  }
  g_preview.positions=positions; g_preview.uvs=uvs; g_preview.colors=colors; g_preview.texture=texture; g_preview.texture_mip64=texture_mip64;
  g_preview.vertex_count=(int)vertex_count; g_preview.shape_count=(int)shapes; g_preview.face_count=(int)(vertex_count/3u); g_preview.polygon_count=g_preview.face_count; g_preview.animation_frame_count=(int)n_frames;
  compute_mesh_stats(positions,(int)vertex_count,&g_preview.edge_count,&g_preview.component_count);
  g_preview.valid=1; g_preview.texture_valid=tex_ok;
  g_preview.center[0]=(minx+maxx)*0.5f; g_preview.center[1]=(miny+maxy)*0.5f; g_preview.center[2]=(minz+maxz)*0.5f;
  g_preview.scale=2.6f/extent;
  snprintf(g_preview.info,sizeof(g_preview.info),tex_ok?"128x128 textured ICN":"3D ICN model");
  return 1;
 }
truncated:
 free(positions); free(uvs); free(colors); free(texture); free(texture_mip64);
 snprintf(g_preview.info,sizeof(g_preview.info),"ICN data truncated/unsupported");
 return 0;
}

static void drain_hw_preview_transition(){
 /* UI/input transitions must never call into GCM/RSX.  The model command list
    only references RSX-local copies of its vertices/texture, so CPU preview
    metadata can be discarded immediately.  draw() owns all flip/FIFO
    synchronization after the input state transition has completed. */
}


static void ensure_preview_current(){
 if(!archive_mode||item_count<=0||selected<0||selected>=item_count||items[selected].is_dir||!endswith(items[selected].name,".icn")){
  if(g_preview.archive[0]||g_preview.entry[0]){free_preview();g_model_base_valid=0;}
  return;
 }
 if(g_preview.valid && !strcmp(g_preview.archive,archive_path) && !strcmp(g_preview.entry,items[selected].name)) return;
 if(!g_preview.valid && !strcmp(g_preview.archive,archive_path) && !strcmp(g_preview.entry,items[selected].name)) return;
  void *buf=NULL; size_t size=0;
 int rc=psu_read_file(archive_path,items[selected].name,&buf,&size);
 if(rc!=0){
  free_preview();
  snprintf(g_preview.archive,sizeof(g_preview.archive),"%s",archive_path);
  snprintf(g_preview.entry,sizeof(g_preview.entry),"%s",items[selected].name);
  snprintf(g_preview.info,sizeof(g_preview.info),"Preview load failed");
  return;
 }
 parse_icn_preview(buf,size,archive_path,items[selected].name);
 free(buf);
}

static void line(int x0,int y0,int x1,int y1,u32 col){
 int dx=abs(x1-x0), sx=x0<x1?1:-1;
 int dy=-abs(y1-y0), sy=y0<y1?1:-1;
 int err=dx+dy;
 for(;;){
  px(x0,y0,col);
  if(x0==x1 && y0==y1) break;
  int e2=err*2;
  if(e2>=dy){ err+=dy; x0+=sx; }
  if(e2<=dx){ err+=dx; y0+=sy; }
 }
}

static void draw_texture_scaled(int x,int y,int w,int h,const u32 *tex){
 if(!tex||w<=0||h<=0)return;
 for(int yy=0;yy<h;yy++){
  int sy=(yy*128)/h;
  for(int xx=0;xx<w;xx++){
   int sx=(xx*128)/w;
   px(x+xx,y+yy,tex[sy*128+sx]);
  }
 }
}

static inline float edgef(float ax,float ay,float bx,float by,float pxv,float pyv){
 return (pxv-ax)*(by-ay)-(pyv-ay)*(bx-ax);
}

static u32 modulate_rgb(u32 tex,u32 vc){
 int tr=(tex>>16)&255,tg=(tex>>8)&255,tb=tex&255;
 int vr=(vc>>16)&255,vg=(vc>>8)&255,vb=vc&255;
 /* ICN vertex colors are commonly white; modulate when games use tinting. */
 return make_rgb((u8)(tr*vr/255),(u8)(tg*vg/255),(u8)(tb*vb/255));
}

static int ensure_model_buffers(int w,int h){
 if(w<=0||h<=0)return 0;
 if(g_model_cache && g_model_zbuf && g_model_cache_w==w && g_model_cache_h==h)return 1;
 free(g_model_cache); free(g_model_zbuf);
 g_model_cache=NULL; g_model_zbuf=NULL; g_model_cache_w=g_model_cache_h=0;
 size_t n=(size_t)w*(size_t)h;
 g_model_cache=(u32*)malloc(n*sizeof(u32));
 g_model_zbuf=(float*)malloc(n*sizeof(float));
 if(!g_model_cache||!g_model_zbuf){free(g_model_cache);free(g_model_zbuf);g_model_cache=NULL;g_model_zbuf=NULL;return 0;}
 g_model_cache_w=w;g_model_cache_h=h;g_model_cache_valid=0;
 free(g_model_filter_cache);g_model_filter_cache=NULL;g_model_filter_w=g_model_filter_h=0;
 return 1;
}
static int ensure_model_filter_buffer(int sw,int sh){
 int fw=sw*2,fh=sh*2;
 if(g_model_filter_cache && g_model_filter_w==fw && g_model_filter_h==fh)return 1;
 free(g_model_filter_cache);g_model_filter_cache=NULL;g_model_filter_w=g_model_filter_h=0;
 g_model_filter_cache=(u32*)malloc((size_t)fw*(size_t)fh*sizeof(u32));
 if(!g_model_filter_cache)return 0;
 g_model_filter_w=fw;g_model_filter_h=fh;return 1;
}
static void build_model_filter_cache(){
 if(!g_model_cache||!g_model_cache_valid)return;
 int sw=g_model_cache_w,sh=g_model_cache_h;
 if(!ensure_model_filter_buffer(sw,sh))return;
 int fw=g_model_filter_w,fh=g_model_filter_h;
 /* Lightweight 2x premultiplied-alpha reconstruction.  The true geometry
    raster is now higher resolution, so this pass only smooths the remaining
    scale step instead of trying to invent silhouette detail. */
 for(int y=0;y<fh;y++){
  int gy=((y<<8)+128)/2-128;
  int y0=gy>>8, fy=gy&255;
  if(y0<0){y0=0;fy=0;} int y1=y0+1;if(y1>=sh)y1=sh-1;
  int iy=256-fy;
  u32 *dst=g_model_filter_cache+(size_t)y*(size_t)fw;
  for(int x=0;x<fw;x++){
   int gx=((x<<8)+128)/2-128;
   int x0=gx>>8, fx=gx&255;
   if(x0<0){x0=0;fx=0;} int x1=x0+1;if(x1>=sw)x1=sw-1;
   int ix=256-fx;
   u32 c00=g_model_cache[(size_t)y0*(size_t)sw+x0];
   u32 c10=g_model_cache[(size_t)y0*(size_t)sw+x1];
   u32 c01=g_model_cache[(size_t)y1*(size_t)sw+x0];
   u32 c11=g_model_cache[(size_t)y1*(size_t)sw+x1];
   int a00=c00?255:0,a10=c10?255:0,a01=c01?255:0,a11=c11?255:0;
   int w00=ix*iy,w10=fx*iy,w01=ix*fy,w11=fx*fy;
   int asum=a00*w00+a10*w10+a01*w01+a11*w11;
   int a=asum>>16;
   /* Preserve the true fractional silhouette coverage from reconstruction.
      The previous hard 28..227 remap reintroduced visible stair-steps.
      Only discard essentially invisible fragments; leave the remaining alpha
      untouched so diagonal edges blend smoothly against the preview panel. */
   if(a<4){dst[x]=0;continue;}
   unsigned long long wr=0,wg=0,wb=0,wa=0;
   if(c00){wr+=(unsigned long long)((c00>>16)&255)*w00;wg+=(unsigned long long)((c00>>8)&255)*w00;wb+=(unsigned long long)(c00&255)*w00;wa+=w00;}
   if(c10){wr+=(unsigned long long)((c10>>16)&255)*w10;wg+=(unsigned long long)((c10>>8)&255)*w10;wb+=(unsigned long long)(c10&255)*w10;wa+=w10;}
   if(c01){wr+=(unsigned long long)((c01>>16)&255)*w01;wg+=(unsigned long long)((c01>>8)&255)*w01;wb+=(unsigned long long)(c01&255)*w01;wa+=w01;}
   if(c11){wr+=(unsigned long long)((c11>>16)&255)*w11;wg+=(unsigned long long)((c11>>8)&255)*w11;wb+=(unsigned long long)(c11&255)*w11;wa+=w11;}
   if(!wa){dst[x]=0;continue;}
   u32 r=(u32)(wr/wa),g=(u32)(wg/wa),b=(u32)(wb/wa);
   dst[x]=((u32)a<<24)|(r<<16)|(g<<8)|b;
  }
 }
}
static void refine_model_filter_silhouette(const float *nx,const float *ny,int n,float cx,float cy,float scale_px){
 if(!g_model_filter_cache||!nx||!ny||n<3)return;
 int fw=g_model_filter_w,fh=g_model_filter_h;
 if(fw<=0||fh<=0)return;
 /* Keep RGB reconstructed from the shaded low-res raster, but replace alpha
    with a true high-resolution geometry coverage mask.  Project from the
    original floating-point coordinates rather than doubled integer pixels,
    avoiding the quantisation that caused the remaining staircase edges. */
 for(size_t i=0;i<(size_t)fw*(size_t)fh;i++)g_model_filter_cache[i]&=0x00FFFFFFu;
 float sxmul=2.0f, symul=2.0f;
 float pcx=cx*sxmul,pcy=cy*symul,psc=scale_px*2.0f;
 static const float ox[4]={0.25f,0.75f,0.25f,0.75f};
 static const float oy[4]={0.25f,0.25f,0.75f,0.75f};
 for(int i=0;i+2<n;i+=3){
  float x0=pcx+nx[i]*psc,y0=pcy+ny[i]*psc;
  float x1=pcx+nx[i+1]*psc,y1=pcy+ny[i+1]*psc;
  float x2=pcx+nx[i+2]*psc,y2=pcy+ny[i+2]*psc;
  float area=edgef(x0,y0,x1,y1,x2,y2);if(fabsf(area)<0.0001f)continue;
  float inv=1.0f/area;
  int minx=clampi((int)floorf(fminf(x0,fminf(x1,x2)))-1,0,fw-1);
  int maxx=clampi((int)ceilf(fmaxf(x0,fmaxf(x1,x2)))+1,0,fw-1);
  int miny=clampi((int)floorf(fminf(y0,fminf(y1,y2)))-1,0,fh-1);
  int maxy=clampi((int)ceilf(fmaxf(y0,fmaxf(y1,y2)))+1,0,fh-1);
  for(int py=miny;py<=maxy;py++)for(int pxv=minx;pxv<=maxx;pxv++){
   int covered=0;
   for(int q=0;q<4;q++){
    float fx=(float)pxv+ox[q],fy=(float)py+oy[q];
    float w0=edgef(x1,y1,x2,y2,fx,fy)*inv;
    float w1=edgef(x2,y2,x0,y0,fx,fy)*inv;
    float w2=1.0f-w0-w1;
    if(w0>=0.0f&&w1>=0.0f&&w2>=0.0f)covered++;
   }
   if(!covered)continue;
   size_t di=(size_t)py*(size_t)fw+(size_t)pxv;
   int olda=(int)(g_model_filter_cache[di]>>24);
   int a=covered*64;if(a>255)a=255;if(a<olda)a=olda;
   g_model_filter_cache[di]=(g_model_filter_cache[di]&0x00FFFFFFu)|((u32)a<<24);
  }
 }
 /* New partial pixels can lie just outside the low-res shaded silhouette and
    therefore have no reconstructed RGB.  Pull colour from the nearest opaque
    neighbour so antialiased edges use model colour rather than black. */
 for(int y=0;y<fh;y++)for(int x=0;x<fw;x++){
  size_t di=(size_t)y*(size_t)fw+(size_t)x;u32 c=g_model_filter_cache[di];
  if(!(c>>24)||(c&0x00FFFFFFu))continue;
  u32 rgb=0;
  for(int r=1;r<=2&&!rgb;r++)for(int yy=-r;yy<=r&&!rgb;yy++)for(int xx=-r;xx<=r;xx++){
   int sx=x+xx,sy=y+yy;if((unsigned)sx>=(unsigned)fw||(unsigned)sy>=(unsigned)fh)continue;
   u32 nc=g_model_filter_cache[(size_t)sy*(size_t)fw+(size_t)sx];if((nc>>24)&&(nc&0x00FFFFFFu)){rgb=nc&0x00FFFFFFu;break;}
  }
  if(rgb)g_model_filter_cache[di]=(c&0xFF000000u)|rgb;
 }
}

static int ensure_model_vertex_buffers(int n){
 if(n<=g_model_vertex_cap && g_model_sx&&g_model_sy&&g_model_zinv&&g_model_nx&&g_model_ny)return 1;
 int cap=n<256?256:n;
 int *sx=(int*)realloc(g_model_sx,(size_t)cap*sizeof(int));
 int *sy=(int*)realloc(g_model_sy,(size_t)cap*sizeof(int));
 float *zi=(float*)realloc(g_model_zinv,(size_t)cap*sizeof(float));
 float *nx=(float*)realloc(g_model_nx,(size_t)cap*sizeof(float));
 float *ny=(float*)realloc(g_model_ny,(size_t)cap*sizeof(float));
 if(!sx||!sy||!zi||!nx||!ny){
  if(sx)g_model_sx=sx;if(sy)g_model_sy=sy;if(zi)g_model_zinv=zi;if(nx)g_model_nx=nx;if(ny)g_model_ny=ny;
  return 0;
 }
 g_model_sx=sx;g_model_sy=sy;g_model_zinv=zi;g_model_nx=nx;g_model_ny=ny;g_model_vertex_cap=cap;return 1;
}
static void blit_model_cache(int box_x,int box_y,int box_w,int box_h){
 if(!g_model_cache||!g_model_cache_valid||box_w<=0||box_h<=0)return;
 const u32 *cache=g_model_filter_cache?g_model_filter_cache:g_model_cache;
 int sw=g_model_filter_cache?g_model_filter_w:g_model_cache_w;
 int sh=g_model_filter_cache?g_model_filter_h:g_model_cache_h;
 /* Edge-aware final upscale.  Interior pixels remain point sampled to keep
    texture detail sharp.  Only cells that cross the model silhouette use a
    bilinear premultiplied-alpha sample, preventing nearest-neighbour stair
    steps from being reintroduced after the 2x reconstruction. */
 u32 xstep=(u32)(((u64)sw<<16)/(u32)box_w);
 u32 ystep=(u32)(((u64)sh<<16)/(u32)box_h);
 u32 yacc=0;
 for(int yy=0;yy<box_h;yy++,yacc+=ystep){
  int sy=(int)(yacc>>16);if(sy>=sh)sy=sh-1;
  int sy1=sy+1;if(sy1>=sh)sy1=sh-1;
  int fy=(int)((yacc>>8)&255u),iy=256-fy;
  u32 *dst=g_fb[g_back]+(size_t)(box_y+yy)*(g_pitch/4)+(size_t)box_x;
  u32 xacc=0;
  for(int xx=0;xx<box_w;xx++,xacc+=xstep){
   int sx=(int)(xacc>>16);if(sx>=sw)sx=sw-1;
   int sx1=sx+1;if(sx1>=sw)sx1=sw-1;
   int fx=(int)((xacc>>8)&255u),ix=256-fx;
   u32 c00=cache[(size_t)sy*(size_t)sw+(size_t)sx];
   u32 c10=cache[(size_t)sy*(size_t)sw+(size_t)sx1];
   u32 c01=cache[(size_t)sy1*(size_t)sw+(size_t)sx];
   u32 c11=cache[(size_t)sy1*(size_t)sw+(size_t)sx1];
   int a00=c00?(int)((c00>>24)&255u):0;
   int a10=c10?(int)((c10>>24)&255u):0;
   int a01=c01?(int)((c01>>24)&255u):0;
   int a11=c11?(int)((c11>>24)&255u):0;
   if(a00==0&&a10==0&&a01==0&&a11==0)continue;
   if(a00==255&&a10==255&&a01==255&&a11==255){dst[xx]=c00;continue;}
   int w00=ix*iy,w10=fx*iy,w01=ix*fy,w11=fx*fy;
   unsigned long long asum=(unsigned long long)a00*w00+(unsigned long long)a10*w10+(unsigned long long)a01*w01+(unsigned long long)a11*w11;
   int a=(int)(asum>>16);if(a<=1)continue;
   unsigned long long pr=0,pg=0,pb=0;
   if(a00){pr+=(unsigned long long)((c00>>16)&255u)*a00*w00;pg+=(unsigned long long)((c00>>8)&255u)*a00*w00;pb+=(unsigned long long)(c00&255u)*a00*w00;}
   if(a10){pr+=(unsigned long long)((c10>>16)&255u)*a10*w10;pg+=(unsigned long long)((c10>>8)&255u)*a10*w10;pb+=(unsigned long long)(c10&255u)*a10*w10;}
   if(a01){pr+=(unsigned long long)((c01>>16)&255u)*a01*w01;pg+=(unsigned long long)((c01>>8)&255u)*a01*w01;pb+=(unsigned long long)(c01&255u)*a01*w01;}
   if(a11){pr+=(unsigned long long)((c11>>16)&255u)*a11*w11;pg+=(unsigned long long)((c11>>8)&255u)*a11*w11;pb+=(unsigned long long)(c11&255u)*a11*w11;}
   unsigned long long denom=asum;if(!denom)continue;
   u32 r=(u32)(pr/denom),g=(u32)(pg/denom),b=(u32)(pb/denom);
   u32 c=((u32)a<<24)|(r<<16)|(g<<8)|b;
   if(a>=254)dst[xx]=0xFF000000u|(c&0x00FFFFFFu);else dst[xx]=blend_argb_over(dst[xx],c);
  }
 }
}
static int capture_model_base(int x,int y,int w,int h){
 if(w<=0||h<=0)return 0;
 size_t n=(size_t)w*(size_t)h;
 if(!g_model_base_cache || g_model_base_w!=w || g_model_base_h!=h){
  free(g_model_base_cache);g_model_base_cache=(u32*)malloc(n*sizeof(u32));
  if(!g_model_base_cache){g_model_base_valid=0;return 0;}
 }
 g_model_base_x=x;g_model_base_y=y;g_model_base_w=w;g_model_base_h=h;
 for(int yy=0;yy<h;yy++)memcpy(g_model_base_cache+(size_t)yy*(size_t)w,
  g_fb[g_back]+(size_t)(y+yy)*(g_pitch/4)+(size_t)x,(size_t)w*sizeof(u32));
 g_model_base_valid=1;return 1;
}
static void restore_model_base_to_buffer(u32 *dst){
 if(!g_model_base_valid||!g_model_base_cache||!dst)return;
 for(int yy=0;yy<g_model_base_h;yy++)memcpy(dst+(size_t)(g_model_base_y+yy)*(g_pitch/4)+(size_t)g_model_base_x,
  g_model_base_cache+(size_t)yy*(size_t)g_model_base_w,(size_t)g_model_base_w*sizeof(u32));
}
static int capture_preview_base(int x,int y,int w,int h){
 if(w<=0||h<=0)return 0;
 size_t n=(size_t)w*(size_t)h;
 if(!g_preview_base_cache || g_preview_cache_w!=w || g_preview_cache_h!=h){
  free(g_preview_base_cache); g_preview_base_cache=(u32*)malloc(n*sizeof(u32));
  if(!g_preview_base_cache){g_preview_base_valid=0;return 0;}
 }
 g_preview_cache_x=x;g_preview_cache_y=y;g_preview_cache_w=w;g_preview_cache_h=h;
 for(int yy=0;yy<h;yy++){
  memcpy(g_preview_base_cache+(size_t)yy*(size_t)w,
         g_fb[g_back]+(size_t)(y+yy)*(g_pitch/4)+(size_t)x,
         (size_t)w*sizeof(u32));
 }
 g_preview_base_valid=1;return 1;
}
static void restore_preview_base_to_buffer(u32 *dst){
 if(!g_preview_base_valid||!g_preview_base_cache||!dst)return;
 for(int yy=0;yy<g_preview_cache_h;yy++){
  memcpy(dst+(size_t)(g_preview_cache_y+yy)*(g_pitch/4)+(size_t)g_preview_cache_x,
         g_preview_base_cache+(size_t)yy*(size_t)g_preview_cache_w,
         (size_t)g_preview_cache_w*sizeof(u32));
 }
}
static inline u32 bilinear_sample_wrap(const u32 *tex,int size,float u,float v){
 int mask=size-1;
 float fs=(float)(size*256);
 int uf=(int)(u*fs+268435456.0f), vf=(int)(v*fs+268435456.0f);
 int x0=(uf>>8)&mask,y0=(vf>>8)&mask,x1=(x0+1)&mask,y1=(y0+1)&mask;
 int fx=uf&255,fy=vf&255,ix=256-fx,iy=256-fy;
 u32 c00=tex[y0*size+x0],c10=tex[y0*size+x1],c01=tex[y1*size+x0],c11=tex[y1*size+x1];
 int w00=ix*iy,w10=fx*iy,w01=ix*fy,w11=fx*fy;
 u32 r=((((c00>>16)&255)*w00+((c10>>16)&255)*w10+((c01>>16)&255)*w01+((c11>>16)&255)*w11)>>16);
 u32 g=((((c00>>8)&255)*w00+((c10>>8)&255)*w10+((c01>>8)&255)*w01+((c11>>8)&255)*w11)>>16);
 u32 b=(((c00&255)*w00+(c10&255)*w10+(c01&255)*w01+(c11&255)*w11)>>16);
 return 0xFF000000u|(r<<16)|(g<<8)|b;
}
static inline u32 blend_rgb_lod(u32 a,u32 b,int t){
 int it=256-t;
 u32 r=((((a>>16)&255)*it+((b>>16)&255)*t)>>8);
 u32 g=((((a>>8)&255)*it+((b>>8)&255)*t)>>8);
 u32 bl=(((a&255)*it+(b&255)*t)>>8);
 return 0xFF000000u|(r<<16)|(g<<8)|bl;
}
static void hw_mat_identity(float m[16]){
 memset(m,0,16*sizeof(float));m[0]=m[5]=m[10]=m[15]=1.0f;
}
static void hw_mat_mul(const float a[16],const float b[16],float out[16]){
 float r[16];
 for(int row=0;row<4;row++)for(int col=0;col<4;col++){
  float v=0.0f;for(int k=0;k<4;k++)v+=a[row*4+k]*b[k*4+col];r[row*4+col]=v;
 }
 memcpy(out,r,sizeof(r));
}
static void hw_mat_perspective(float fov,float aspect,float zn,float zf,float m[16]){
 /* Left-handed +Z projection matches the original ICN software renderer,
    whose perspective divisor is camera_z + rotated_z. */
 float f=1.0f/tanf(fov*0.5f);memset(m,0,16*sizeof(float));
 m[0]=f/aspect;m[5]=f;m[10]=(zf+zn)/(zf-zn);m[11]=(-2.0f*zf*zn)/(zf-zn);m[14]=1.0f;
}
static void hw_mat_translate(float x,float y,float z,float m[16]){
 hw_mat_identity(m);m[3]=x;m[7]=y;m[11]=z;
}
static void hw_mat_rot_x(float a,float m[16]){
 hw_mat_identity(m);float c=cosf(a),sn=sinf(a);m[5]=c;m[6]=-sn;m[9]=sn;m[10]=c;
}
static void hw_mat_rot_y(float a,float m[16]){
 hw_mat_identity(m);float c=cosf(a),sn=sinf(a);m[0]=c;m[2]=sn;m[8]=-sn;m[10]=c;
}
static int icn_hw_preview_active(){
 return g_icn_hw_ready&&archive_mode&&g_model_base_valid&&g_preview.valid&&g_preview.texture_valid&&
        item_count>0&&selected<item_count&&!items[selected].is_dir&&endswith(items[selected].name,".icn");
}
static int icn_hw_init(){
 /* librsx expects the classic PSL1GHT rsxVertexProgram/rsxFragmentProgram
    container.  Reject foreign/newer CgBinary containers before calling any
    librsx parser helper: treating one as rsxFragmentProgram can make its
    ucode offset point at arbitrary memory and crash during boot. */
 if(psgl_ffp_minimal_vpo_len<sizeof(rsxVertexProgram)||
    psgl_ffp_minimal_fpo_len<sizeof(rsxFragmentProgram))return 0;
 const rsxVertexProgram *vpchk=(const rsxVertexProgram*)psgl_ffp_minimal_vpo;
 const rsxFragmentProgram *fpchk=(const rsxFragmentProgram*)psgl_ffp_minimal_fpo;
 if(vpchk->magic==0||fpchk->magic==0)return 0;
 if(vpchk->ucode_off>=psgl_ffp_minimal_vpo_len||fpchk->ucode_off>=psgl_ffp_minimal_fpo_len)return 0;
 if(vpchk->num_insn==0||fpchk->num_insn==0)return 0;
 g_icn_hw_vpo=(rsxVertexProgram*)psgl_ffp_minimal_vpo;
 g_icn_hw_fpo=(rsxFragmentProgram*)psgl_ffp_minimal_fpo;
 u32 vpsz=0,fpsz=0;void *src=NULL;
 rsxVertexProgramGetUCode(g_icn_hw_vpo,&g_icn_hw_vp_ucode,&vpsz);
 rsxFragmentProgramGetUCode(g_icn_hw_fpo,&src,&fpsz);
 if(!g_icn_hw_vp_ucode||!vpsz||!src||!fpsz)return 0;
 g_icn_hw_fp_ucode=tracked_rsx_memalign(64,fpsz);
 if(!g_icn_hw_fp_ucode)return 0;
 memcpy(g_icn_hw_fp_ucode,src,fpsz);
 if(rsxAddressToOffset(g_icn_hw_fp_ucode,&g_icn_hw_fp_offset)!=0)return 0;
 g_icn_hw_vertex_capacity=4096;
 g_icn_hw_vertices=(icn_hw_vertex_t*)tracked_rsx_memalign(128,(size_t)g_icn_hw_vertex_capacity*sizeof(icn_hw_vertex_t));
 if(!g_icn_hw_vertices)return 0;
 if(rsxAddressToOffset(g_icn_hw_vertices,&g_icn_hw_vertex_offset)!=0)return 0;
 g_icn_hw_texture=(u32*)tracked_rsx_memalign(128,128u*128u*sizeof(u32));
 if(!g_icn_hw_texture)return 0;
 if(rsxAddressToOffset(g_icn_hw_texture,&g_icn_hw_texture_offset)!=0)return 0;
 g_icn_hw_color=(u32*)tracked_rsx_memalign(64,(size_t)g_pitch*(size_t)g_height);
 if(!g_icn_hw_color)return 0;
 memset(g_icn_hw_color,0,(size_t)g_pitch*(size_t)g_height);
 if(rsxAddressToOffset(g_icn_hw_color,&g_icn_hw_color_offset)!=0)return 0;
 g_icn_hw_depth_pitch=(g_width*2u+63u)&~63u;
 g_icn_hw_depth=(u16*)tracked_rsx_memalign(64,(size_t)g_icn_hw_depth_pitch*(size_t)g_height);
 if(!g_icn_hw_depth)return 0;
 memset(g_icn_hw_depth,0xff,(size_t)g_icn_hw_depth_pitch*(size_t)g_height);
 if(rsxAddressToOffset(g_icn_hw_depth,&g_icn_hw_depth_offset)!=0)return 0;
 g_icn_hw_archive[0]=g_icn_hw_entry[0]=0;
 g_icn_hw_ready=1;
 return 1;
}
static void icn_hw_upload_texture_if_needed(){
 if(!g_icn_hw_ready||!g_preview.texture_valid||!g_preview.texture)return;
 if(!strcmp(g_icn_hw_archive,g_preview.archive)&&!strcmp(g_icn_hw_entry,g_preview.entry))return;
 for(int i=0;i<128*128;i++)g_icn_hw_texture[i]=0xFF000000u|(g_preview.texture[i]&0x00FFFFFFu);
 snprintf(g_icn_hw_archive,sizeof(g_icn_hw_archive),"%s",g_preview.archive);
 snprintf(g_icn_hw_entry,sizeof(g_icn_hw_entry),"%s",g_preview.entry);
}
static void icn_hw_set_surface(){
 gcmSurface sf;memset(&sf,0,sizeof(sf));
 sf.colorFormat=GCM_SURFACE_X8R8G8B8;sf.colorTarget=GCM_SURFACE_TARGET_0;
 sf.colorLocation[0]=GCM_LOCATION_RSX;sf.colorOffset[0]=g_icn_hw_color_offset;sf.colorPitch[0]=g_pitch;
 for(int i=1;i<4;i++){sf.colorLocation[i]=GCM_LOCATION_RSX;sf.colorOffset[i]=0;sf.colorPitch[i]=64;}
 sf.depthFormat=GCM_SURFACE_ZETA_Z16;sf.depthLocation=GCM_LOCATION_RSX;sf.depthOffset=g_icn_hw_depth_offset;sf.depthPitch=g_icn_hw_depth_pitch;
 sf.type=GCM_SURFACE_TYPE_LINEAR;sf.antiAlias=GCM_SURFACE_CENTER_1;sf.width=(u16)g_width;sf.height=(u16)g_height;sf.x=0;sf.y=0;
 rsxSetSurface(g_ctx,&sf);
}
static void icn_hw_bind_texture(){
 gcmTexture t;memset(&t,0,sizeof(t));
 t.format=GCM_TEXTURE_FORMAT_A8R8G8B8|GCM_TEXTURE_FORMAT_LIN;t.mipmap=1;t.dimension=GCM_TEXTURE_DIMS_2D;t.cubemap=GCM_FALSE;
 t.remap=(GCM_TEXTURE_REMAP_TYPE_REMAP<<GCM_TEXTURE_REMAP_TYPE_B_SHIFT)|(GCM_TEXTURE_REMAP_TYPE_REMAP<<GCM_TEXTURE_REMAP_TYPE_G_SHIFT)|
         (GCM_TEXTURE_REMAP_TYPE_REMAP<<GCM_TEXTURE_REMAP_TYPE_R_SHIFT)|(GCM_TEXTURE_REMAP_TYPE_REMAP<<GCM_TEXTURE_REMAP_TYPE_A_SHIFT)|
         (GCM_TEXTURE_REMAP_COLOR_B<<GCM_TEXTURE_REMAP_COLOR_B_SHIFT)|(GCM_TEXTURE_REMAP_COLOR_G<<GCM_TEXTURE_REMAP_COLOR_G_SHIFT)|
         (GCM_TEXTURE_REMAP_COLOR_R<<GCM_TEXTURE_REMAP_COLOR_R_SHIFT)|(GCM_TEXTURE_REMAP_COLOR_A<<GCM_TEXTURE_REMAP_COLOR_A_SHIFT);
 t.width=128;t.height=128;t.depth=1;t.location=GCM_LOCATION_RSX;t.pitch=128*4;t.offset=g_icn_hw_texture_offset;
 rsxInvalidateTextureCache(g_ctx,GCM_INVALIDATE_TEXTURE);
 rsxLoadTexture(g_ctx,g_icn_hw_texunit_index,&t);
 rsxTextureControl(g_ctx,g_icn_hw_texunit_index,GCM_TRUE,0<<8,12<<8,GCM_TEXTURE_MAX_ANISO_1);
 rsxTextureFilter(g_ctx,g_icn_hw_texunit_index,0,GCM_TEXTURE_LINEAR,GCM_TEXTURE_LINEAR,GCM_TEXTURE_CONVOLUTION_QUINCUNX);
 rsxTextureWrapMode(g_ctx,g_icn_hw_texunit_index,GCM_TEXTURE_REPEAT,GCM_TEXTURE_REPEAT,GCM_TEXTURE_REPEAT,0,GCM_TEXTURE_ZFUNC_LESS,0);
}
static int icn_hw_draw_model(){
 if(!icn_hw_preview_active())return 0;
 int n=g_preview.vertex_count;if(n<=0||n>g_icn_hw_vertex_capacity)return 0;
 icn_hw_upload_texture_if_needed();
 int x=g_model_base_x,y=g_model_base_y,w=g_model_base_w,h=g_model_base_h;
 if(w<2||h<2)return 0;
 /* The off-screen target is seeded by an RSX local-to-local transfer in
    present().  Do not CPU-read/write freshly rendered RSX local memory here. */
 if(!g_icn_hw_color||!g_model_base_cache)return 0;
 float base_rx=-0.28f;
 float base_ry=(float)g_frame_counter*0.018f;
 float crx=cosf(base_rx),srx=sinf(base_rx),cry=cosf(base_ry),sry=sinf(base_ry);
 int s0=(g_preview.shape_count>0)?((g_frame_counter/12)%g_preview.shape_count):0;
 int s1=(g_preview.shape_count>1)?((s0+1)%g_preview.shape_count):s0;
 float morph=(float)(g_frame_counter%12)/12.0f;
 float min_nx=1e30f,max_nx=-1e30f,min_ny=1e30f,max_ny=-1e30f;
 /* First reproduce the proven software renderer camera transform.  Keep the
    projected coordinates in the RSX vertex buffer temporarily so the second
    pass can fit the complete animated shape into the preview rectangle. */
 for(int i=0;i<n;i++){
  size_t i0=((size_t)s0*(size_t)n+(size_t)i)*3u,i1=((size_t)s1*(size_t)n+(size_t)i)*3u;
  float px=(g_preview.positions[i0]+(g_preview.positions[i1]-g_preview.positions[i0])*morph-g_preview.center[0])*g_preview.scale;
  float py=(g_preview.positions[i0+1]+(g_preview.positions[i1+1]-g_preview.positions[i0+1])*morph-g_preview.center[1])*g_preview.scale;
  float pz=(g_preview.positions[i0+2]+(g_preview.positions[i1+2]-g_preview.positions[i0+2])*morph-g_preview.center[2])*g_preview.scale;
  float xr=px*cry+pz*sry,zr=-px*sry+pz*cry;
  float yr=py*crx-zr*srx,camz=py*srx+zr*crx+3.2f;
  if(camz<0.2f)camz=0.2f;
  float nx=xr/camz,ny=yr/camz;
  g_icn_hw_vertices[i].x=nx;g_icn_hw_vertices[i].y=ny;
  g_icn_hw_vertices[i].z=camz;g_icn_hw_vertices[i].w=camz;
  g_icn_hw_vertices[i].u=g_preview.uvs[(size_t)i*2u];
  g_icn_hw_vertices[i].v=g_preview.uvs[(size_t)i*2u+1];
  if(nx<min_nx)min_nx=nx;if(nx>max_nx)max_nx=nx;
  if(ny<min_ny)min_ny=ny;if(ny>max_ny)max_ny=ny;
 }
 float span_x=max_nx-min_nx,span_y=max_ny-min_ny;
 if(span_x<0.001f)span_x=0.001f;if(span_y<0.001f)span_y=0.001f;
 float margin=6.0f;
 float fit_x=((float)w-margin*2.0f)/span_x,fit_y=((float)h-margin*2.0f)/span_y;
 float fit=(fit_x<fit_y?fit_x:fit_y)*0.97f;
 float center_nx=(min_nx+max_nx)*0.5f,center_ny=(min_ny+max_ny)*0.5f;
 float cx=(float)w*0.5f-center_nx*fit,cy=(float)h*0.5f-center_ny*fit;
 /* Convert the fitted preview-pixel position back to clip coordinates.
    Keeping clip W equal to camera Z preserves perspective-correct UV
    interpolation in RSX while making the on-screen footprint identical to
    the software renderer's known-good fit. */
 for(int i=0;i<n;i++){
  float camz=g_icn_hw_vertices[i].w;
  float px=cx+g_icn_hw_vertices[i].x*fit;
  float py=cy+g_icn_hw_vertices[i].y*fit;
  float ndcx=(px/(float)w)*2.0f-1.0f;
  float ndcy=(py/(float)h)*2.0f-1.0f;
  float ndcz=(camz-0.1f)/(20.0f-0.1f);
  if(ndcz<0.0f)ndcz=0.0f;if(ndcz>1.0f)ndcz=1.0f;
  /* Geometry is already projected and fitted in preview pixels.  Feed the
     rasterizer direct NDC with W=1 so RSX cannot apply a second, subtly
     different perspective divide.  This makes the triangle footprint match
     the proven software renderer exactly; perspective-correct UV can be
     restored separately once geometry is verified. */
  g_icn_hw_vertices[i].x=ndcx;
  g_icn_hw_vertices[i].y=ndcy;
  g_icn_hw_vertices[i].z=ndcz;
  g_icn_hw_vertices[i].w=1.0f;
 }
 __sync_synchronize();
 icn_hw_set_surface();
 float vmin=0.0f,vmax=1.0f;
 float vscale[4]={(float)w*0.5f,(float)h*0.5f,(vmax-vmin)*0.5f,0.0f};
 float voffset[4]={(float)x+(float)w*0.5f,(float)y+(float)h*0.5f,(vmax+vmin)*0.5f,0.0f};
 rsxSetColorMask(g_ctx,GCM_COLOR_MASK_B|GCM_COLOR_MASK_G|GCM_COLOR_MASK_R|GCM_COLOR_MASK_A);
 rsxSetViewport(g_ctx,(u16)x,(u16)y,(u16)w,(u16)h,vmin,vmax,vscale,voffset);
 rsxSetScissor(g_ctx,(u16)x,(u16)y,(u16)w,(u16)h);
 for(int i=0;i<8;i++)rsxSetViewportClip(g_ctx,i,g_width,g_height);
 rsxSetDepthTestEnable(g_ctx,GCM_TRUE);rsxSetDepthFunc(g_ctx,GCM_LESS);rsxSetDepthWriteEnable(g_ctx,GCM_TRUE);
 rsxSetCullFaceEnable(g_ctx,GCM_FALSE);rsxSetBlendEnable(g_ctx,GCM_FALSE);rsxSetShadeModel(g_ctx,GCM_SHADE_MODEL_SMOOTH);
 rsxSetClearColor(g_ctx,0xFF000000u);rsxSetClearDepthStencil(g_ctx,0xffffff00u);rsxClearSurface(g_ctx,GCM_CLEAR_R|GCM_CLEAR_G|GCM_CLEAR_B|GCM_CLEAR_A|GCM_CLEAR_Z);
 rsxLoadVertexProgram(g_ctx,g_icn_hw_vpo,g_icn_hw_vp_ucode);
 rsxBindVertexArrayAttrib(g_ctx,g_icn_hw_pos_index,0,g_icn_hw_vertex_offset,sizeof(icn_hw_vertex_t),4,GCM_VERTEX_DATA_TYPE_F32,GCM_LOCATION_RSX);
 rsxBindVertexArrayAttrib(g_ctx,g_icn_hw_uv_index,0,g_icn_hw_vertex_offset+offsetof(icn_hw_vertex_t,u),sizeof(icn_hw_vertex_t),2,GCM_VERTEX_DATA_TYPE_F32,GCM_LOCATION_RSX);
 rsxLoadFragmentProgramLocation(g_ctx,g_icn_hw_fpo,g_icn_hw_fp_offset,GCM_LOCATION_RSX);
 icn_hw_bind_texture();
 rsxDrawVertexArray(g_ctx,GCM_TYPE_TRIANGLES,0,(u32)n);
 return 1;
}

static void draw_textured_model(int box_x,int box_y,int box_w,int box_h){
 if(!g_preview.valid||!g_preview.positions||!g_preview.uvs||!g_preview.texture_valid||!g_preview.texture||box_w<40||box_h<40)return;
 /* Adaptive true raster resolution.  Simple and moderate ICNs get substantially
    more real geometry pixels; only heavy meshes fall back to the compact path. */
 int max_w;
 if(g_height>=1000){
  if(g_preview.face_count<=400)max_w=224;
  else if(g_preview.face_count<=700)max_w=208;
  else if(g_preview.face_count<=1100)max_w=178;
  else if(g_preview.face_count<=1800)max_w=148;
  else max_w=120;
 }else{
  if(g_preview.face_count<=400)max_w=184;
  else if(g_preview.face_count<=700)max_w=170;
  else if(g_preview.face_count<=1100)max_w=148;
  else if(g_preview.face_count<=1800)max_w=124;
  else max_w=100;
 }
 int rw=box_w<max_w?box_w:max_w;
 int rh=(int)((long long)box_h*(long long)rw/(long long)box_w);
 if(rh<60){rh=60;if(rh>box_h)rh=box_h;}
 int max_h;
 if(g_height>=1000){
  if(g_preview.face_count<=400)max_h=202;
  else if(g_preview.face_count<=700)max_h=188;
  else if(g_preview.face_count<=1100)max_h=160;
  else if(g_preview.face_count<=1800)max_h=134;
  else max_h=108;
 }else{
  if(g_preview.face_count<=400)max_h=166;
  else if(g_preview.face_count<=700)max_h=154;
  else if(g_preview.face_count<=1100)max_h=134;
  else if(g_preview.face_count<=1800)max_h=112;
  else max_h=90;
 }
 if(rh>max_h)rh=max_h;
 if(!ensure_model_buffers(rw,rh))return;
 int rerender=!g_model_cache_valid || (g_frame_counter-g_model_cache_frame)>=model_update_interval();
 if(!rerender){blit_model_cache(box_x,box_y,box_w,box_h);return;}
 size_t pixels=(size_t)rw*(size_t)rh;
 memset(g_model_cache,0,pixels*sizeof(u32));
 for(size_t i=0;i<pixels;i++)g_model_zbuf[i]=-1e30f;
 float base_rx=-0.28f;
 float base_ry=(float)g_frame_counter*0.018f;
 int s0=(g_preview.shape_count>0)?((g_frame_counter/12)%g_preview.shape_count):0;
 int s1=(g_preview.shape_count>1)?((s0+1)%g_preview.shape_count):s0;
 float morph=(float)(g_frame_counter%12)/12.0f;
 float crx=cosf(base_rx),srx=sinf(base_rx),cry=cosf(base_ry),sry=sinf(base_ry);
 int n=g_preview.vertex_count;
 if(!ensure_model_vertex_buffers(n)){blit_model_cache(box_x,box_y,box_w,box_h);return;}
 int *sx=g_model_sx,*sy=g_model_sy;float *zinv=g_model_zinv,*nx=g_model_nx,*ny=g_model_ny;
 float min_nx=1e30f,max_nx=-1e30f,min_ny=1e30f,max_ny=-1e30f;
 for(int i=0;i<n;i++){
  size_t i0=((size_t)s0*(size_t)n+(size_t)i)*3u,i1=((size_t)s1*(size_t)n+(size_t)i)*3u;
  float x=(g_preview.positions[i0]+(g_preview.positions[i1]-g_preview.positions[i0])*morph-g_preview.center[0])*g_preview.scale;
  float yv=(g_preview.positions[i0+1]+(g_preview.positions[i1+1]-g_preview.positions[i0+1])*morph-g_preview.center[1])*g_preview.scale;
  float z=(g_preview.positions[i0+2]+(g_preview.positions[i1+2]-g_preview.positions[i0+2])*morph-g_preview.center[2])*g_preview.scale;
  float xr=x*cry+z*sry,zr=-x*sry+z*cry;
  float yr=yv*crx-zr*srx,zr2=yv*srx+zr*crx+3.2f;if(zr2<0.2f)zr2=0.2f;
  nx[i]=xr/zr2;ny[i]=yr/zr2;zinv[i]=1.0f/zr2;
  if(nx[i]<min_nx)min_nx=nx[i];if(nx[i]>max_nx)max_nx=nx[i];
  if(ny[i]<min_ny)min_ny=ny[i];if(ny[i]>max_ny)max_ny=ny[i];
 }
 float span_x=max_nx-min_nx,span_y=max_ny-min_ny;if(span_x<0.001f)span_x=0.001f;if(span_y<0.001f)span_y=0.001f;
 float margin=4.0f;
 float scale_x=((float)rw-margin*2.0f)/span_x,scale_y=((float)rh-margin*2.0f)/span_y;
 float scale_px=(scale_x<scale_y?scale_x:scale_y)*0.97f;
 float center_nx=(min_nx+max_nx)*0.5f,center_ny=(min_ny+max_ny)*0.5f;
 float cx=(float)rw*0.5f-center_nx*scale_px,cy=(float)rh*0.5f-center_ny*scale_px;
 for(int i=0;i<n;i++){sx[i]=(int)(cx+nx[i]*scale_px);sy[i]=(int)(cy+ny[i]*scale_px);}
 for(int i=0;i+2<n;i+=3){
  int x0=sx[i],y0=sy[i],x1=sx[i+1],y1=sy[i+1],x2=sx[i+2],y2=sy[i+2];
  float area=edgef((float)x0,(float)y0,(float)x1,(float)y1,(float)x2,(float)y2);if(fabsf(area)<0.001f)continue;
  int minx=clampi(x0<x1?(x0<x2?x0:x2):(x1<x2?x1:x2),0,rw-1),maxx=clampi(x0>x1?(x0>x2?x0:x2):(x1>x2?x1:x2),0,rw-1);
  int miny=clampi(y0<y1?(y0<y2?y0:y2):(y1<y2?y1:y2),0,rh-1),maxy=clampi(y0>y1?(y0>y2?y0:y2):(y1>y2?y1:y2),0,rh-1);
  float inv_area=1.0f/area;
  float u0=g_preview.uvs[(size_t)i*2u],v0=g_preview.uvs[(size_t)i*2u+1],u1=g_preview.uvs[(size_t)(i+1)*2u],v1=g_preview.uvs[(size_t)(i+1)*2u+1],u2=g_preview.uvs[(size_t)(i+2)*2u],v2=g_preview.uvs[(size_t)(i+2)*2u+1];
  /* Perspective-correct texture coordinates.  Affine UV interpolation is
     cheaper, but visibly bends textures as a face turns away from camera.
     Pre-multiply U/V by reciprocal Z once per vertex, then do only one
     reciprocal per covered pixel and reuse it for both coordinates. */
  float u0z=u0*zinv[i],v0z=v0*zinv[i];
  float u1z=u1*zinv[i+1],v1z=v1*zinv[i+1];
  float u2z=u2*zinv[i+2],v2z=v2*zinv[i+2];
  float du=fabsf(u1-u0);if(fabsf(u2-u0)>du)du=fabsf(u2-u0);if(fabsf(u2-u1)>du)du=fabsf(u2-u1);
  float dv=fabsf(v1-v0);if(fabsf(v2-v0)>dv)dv=fabsf(v2-v0);if(fabsf(v2-v1)>dv)dv=fabsf(v2-v1);
  int pix_span=(maxx-minx)>(maxy-miny)?(maxx-minx):(maxy-miny);if(pix_span<1)pix_span=1;
  float tex_span=(du>dv?du:dv)*128.0f,footprint=tex_span/(float)pix_span;
  int lod_blend=0;if(footprint>1.0f){lod_blend=(int)((footprint-1.0f)*192.0f);if(lod_blend>256)lod_blend=256;}
  u32 vc0=g_preview.colors[i],vc1=g_preview.colors[i+1],vc2=g_preview.colors[i+2];
  u32 tri_tint=make_rgb((u8)((((vc0>>16)&255)+((vc1>>16)&255)+((vc2>>16)&255))/3),(u8)((((vc0>>8)&255)+((vc1>>8)&255)+((vc2>>8)&255))/3),(u8)(((vc0&255)+(vc1&255)+(vc2&255))/3));
  float startx=(float)minx+0.5f,starty=(float)miny+0.5f;
  float e0_row=edgef((float)x1,(float)y1,(float)x2,(float)y2,startx,starty),e1_row=edgef((float)x2,(float)y2,(float)x0,(float)y0,startx,starty);
  float de0dx=(float)(y2-y1),de0dy=(float)-(x2-x1),de1dx=(float)(y0-y2),de1dy=(float)-(x0-x2);
  for(int pyv=miny;pyv<=maxy;pyv++){
   float e0=e0_row,e1=e1_row;int zi=pyv*rw+minx;
   for(int pxv=minx;pxv<=maxx;pxv++,zi++,e0+=de0dx,e1+=de1dx){
    float w0=e0*inv_area,w1=e1*inv_area,w2=1.0f-w0-w1;if(w0<0.0f||w1<0.0f||w2<0.0f)continue;
    float invz=w0*zinv[i]+w1*zinv[i+1]+w2*zinv[i+2];if(invz<=g_model_zbuf[zi])continue;g_model_zbuf[zi]=invz;
    float rz=1.0f/invz;
    float u=(w0*u0z+w1*u1z+w2*u2z)*rz;
    float v=(w0*v0z+w1*v1z+w2*v2z)*rz;
    u32 texel=bilinear_sample_wrap(g_preview.texture,128,u,v);
    if(lod_blend>0&&g_preview.texture_mip64){u32 mip=bilinear_sample_wrap(g_preview.texture_mip64,64,u,v);texel=blend_rgb_lod(texel,mip,lod_blend);}
    g_model_cache[zi]=modulate_rgb(texel,tri_tint);
   }
   e0_row+=de0dy;e1_row+=de1dy;
  }
 }
 /* Do not run the previous full 2x geometry SSAA pass here.  It re-rasterized
    every triangle with four sub-samples and was the source of the ~15 FPS
    regression.  The higher true raster resolution above plus the inexpensive
    2x fractional-alpha reconstruction gives a much better quality/performance
    balance while keeping perspective-correct texture mapping intact. */
 g_model_cache_valid=1;g_model_cache_frame=g_frame_counter;build_model_filter_cache();blit_model_cache(box_x,box_y,box_w,box_h);
}

static void draw_preview_panel(int x,int y,int w,int h){
 if(w<180||h<160)return;
 rect(x,y,w,h,0xA61D2631u);
 rect(x,y,w,2,0xFF536373u);rect(x,y+h-2,w,2,0xFF536373u);rect(x,y,2,h,0xFF536373u);rect(x+w-2,y,2,h,0xFF536373u);
 text(x+10,y+8,"ICN PREVIEW",0xFF4CC2FFu,g_help_scale);
 const char *name=(g_preview.entry[0]?g_preview.entry:(archive_mode&&item_count>0&&!items[selected].is_dir?items[selected].name:""));
 int line_step=scale125(8*g_help_scale)+4;
 int title_y=y+8+scale125(10*g_help_scale);
 const char *renderer=g_icn_hw_ready?"ICN RENDERER: RSX":"ICN RENDERER: SOFTWARE";
 text(x+10,title_y,renderer,g_icn_hw_ready?0xFF73E6A5u:0xFFFFA85Cu,g_help_scale);
 int name_y=title_y+line_step;
 int name_lines=0;
 if(name&&*name){
  char lines[2][256]={{0}};
  name_lines=wrap_text_lines(name,w-20,g_help_scale,lines,2);
  for(int i=0;i<name_lines;i++)text(x+10,name_y+i*line_step,lines[i],0xFFE8EEF4u,g_help_scale);
 }
 if(name_lines<1) name_lines=1;
 int content_y=name_y+line_step*name_lines+10;

 /* Reserve a real boxed statistics area inside the panel.  Its height is
    calculated from the actual stats font so none of the four rows can fall
    below the panel border. */
 int stat_scale=g_help_scale;
 /* Keep stats at the normal readable UI scale.  Each row is rendered as two
    independent columns, so long combined strings never force the font down. */
 int stats_step=scale125(7*stat_scale)+4;
 int stats_h=g_preview.valid?(stats_step*4+18):(scale125(8*g_help_scale)+30);
 int stats_y=y+h-stats_h-10;
 if(stats_y<content_y+90)stats_y=content_y+90;
 int content_h=stats_y-content_y-10;
 if(content_h<70)content_h=70;

 rect(x+10,content_y,w-20,content_h,0x8C101720u);
 rect(x+10,content_y,w-20,1,0xFF3A4A59u);rect(x+10,content_y+content_h-1,w-20,1,0xFF3A4A59u);
 rect(x+10,content_y,1,content_h,0xFF3A4A59u);rect(x+w-11,content_y,1,content_h,0xFF3A4A59u);

 if(g_preview.valid && g_preview.texture_valid){
  /* Balance the two previews: retain a large 2D texture while restoring a
     comfortably sized 3D viewport.  Stats have their own reserved box below. */
  int tex_side=content_h/2;
  if(tex_side>w-54)tex_side=w-54;
  if(tex_side>220)tex_side=220;
  if(tex_side<64)tex_side=64;
  int tx=x+(w-tex_side)/2;
  int ty=content_y+8;
  draw_texture_scaled(tx,ty,tex_side,tex_side,g_preview.texture);
  rect(tx-1,ty-1,tex_side+2,1,0xFFDDE8F0u);rect(tx-1,ty+tex_side,tex_side+2,1,0xFFDDE8F0u);rect(tx-1,ty-1,1,tex_side+2,0xFFDDE8F0u);rect(tx+tex_side,ty-1,1,tex_side+2,0xFFDDE8F0u);
  int model_y=ty+tex_side+10;
  int model_avail=content_y+content_h-model_y-8;
  if(model_avail>=72){
   rect(x+14,model_y-4,w-28,model_avail+8,0x28101820u);
   rect(x+14,model_y-4,w-28,1,0x40556779u); rect(x+14,model_y+model_avail+3,w-28,1,0x40556779u);
   rect(x+14,model_y-4,1,model_avail+8,0x40556779u); rect(x+w-15,model_y-4,1,model_avail+8,0x40556779u);
   capture_model_base(x+18,model_y,w-36,model_avail);
   if(!g_icn_hw_ready)draw_textured_model(x+18,model_y,w-36,model_avail);
  }
 }else if(g_preview.valid){
  int model_h=content_h-24;
  if(model_h>260)model_h=260;
  int model_y=content_y+(content_h-model_h)/2;
  capture_model_base(x+16,model_y,w-32,model_h);
  if(!g_icn_hw_ready)draw_textured_model(x+16,model_y,w-32,model_h);
 }else{
  const char *msg=(archive_mode&&item_count>0&&selected<item_count&&!items[selected].is_dir&&endswith(items[selected].name,".icn"))?g_preview.info:"Highlight a .ICN file";
  text(x+18,content_y+content_h/2,msg,0xFFF3F7FBu,g_help_scale);
 }

 /* Statistics subsection: fully enclosed and padded inside the preview box. */
 int box_y=stats_y;
 int box_h=y+h-10-box_y;
 rect(x+10,box_y,w-20,box_h,0x981F2934u);
 rect(x+10,box_y,w-20,2,0xFF526274u);rect(x+10,box_y+box_h-2,w-20,2,0xFF526274u);
 rect(x+10,box_y,2,box_h,0xFF526274u);rect(x+w-12,box_y,2,box_h,0xFF526274u);
 if(g_preview.valid){
  int sy=box_y+8; char l[128],r[128];
  int lx=x+20;
  int right_edge=x+w-20;
  /* Right-align the second column against the inside edge of the stats box.
     This guarantees long values such as TEXTURE 128X128 stay inside the border. */
  snprintf(l,sizeof(l),"VERTICES: %d",g_preview.vertex_count); snprintf(r,sizeof(r),"EDGES: %d",g_preview.edge_count); int rx=right_edge-text_width(r,stat_scale); text(lx,sy,l,0xFFF2F6FAu,stat_scale); text(rx,sy,r,0xFFF2F6FAu,stat_scale);
  snprintf(l,sizeof(l),"FACES: %d",g_preview.face_count); snprintf(r,sizeof(r),"POLYGONS: %d",g_preview.polygon_count); rx=right_edge-text_width(r,stat_scale); text(lx,sy+stats_step,l,0xFFF2F6FAu,stat_scale); text(rx,sy+stats_step,r,0xFFF2F6FAu,stat_scale);
  snprintf(l,sizeof(l),"MODELS: %d",g_preview.component_count); snprintf(r,sizeof(r),"SHAPES: %d",g_preview.shape_count); rx=right_edge-text_width(r,stat_scale); text(lx,sy+stats_step*2,l,0xFFF2F6FAu,stat_scale); text(rx,sy+stats_step*2,r,0xFFF2F6FAu,stat_scale);
  snprintf(l,sizeof(l),"FRAMES: %d",g_preview.animation_frame_count); snprintf(r,sizeof(r),g_preview.texture_valid?"TEXTURE: 128X128":"TEXTURE: NONE"); rx=right_edge-text_width(r,stat_scale); text(lx,sy+stats_step*3,l,0xFFF2F6FAu,stat_scale); text(rx,sy+stats_step*3,r,0xFFF2F6FAu,stat_scale);
 }else{
  text(x+20,box_y+10,"PS2 ICN texture decode",0xFFF2F6FAu,g_help_scale);
 }
}

static void wait_rsx_idle_init(){
 /* Match PSL1GHT rsxtest initialization: force the initial/state command list
    to complete before issuing any flip/display-buffer commands.  gcmSetFlip()
    emits an RSX CALL; issuing it while rsxInit's setup list is still active can
    be observed by RPCS3 as a nested CALL and desynchronise the FIFO. */
 const u8 label=254;
 static u32 value=1;
 volatile u32 *addr=(volatile u32*)gcmGetLabelAddress(label);
 if(!addr)return;
 rsxSetWriteBackendLabel(g_ctx,label,value);
 rsxSetWaitLabel(g_ctx,label,value);
 ++value;
 rsxSetWriteBackendLabel(g_ctx,label,value);
 rsxFlushBuffer(g_ctx);
 while(*addr!=value)usleep(30);
 ++value;
}
static int video_init(){
 void *host=memalign(HOST_ADDR_ALIGNMENT,HOSTBUFFER_SIZE); if(!host)return -1;
 if(rsxInit(&g_ctx,RSX_COMMAND_BUFFER_SIZE,HOSTBUFFER_SIZE,host)!=0)return -2;
 videoState state; videoConfiguration cfg; videoResolution res; memset(&state,0,sizeof(state));
 if(videoGetState(0,0,&state)!=0)return -3; if(videoGetResolution(state.displayMode.resolution,&res)!=0)return -4;
 g_width=res.width;g_height=res.height;g_pitch=(g_width*4+63)&~63U;
 memset(&cfg,0,sizeof(cfg));cfg.resolution=state.displayMode.resolution;cfg.format=VIDEO_BUFFER_FORMAT_XRGB;cfg.aspect=state.displayMode.aspect;cfg.pitch=g_pitch;
 if(videoConfigure(0,&cfg,NULL,0)!=0)return -5;
 gcmSetFlipMode(GCM_FLIP_VSYNC);
 for(int i=0;i<2;i++){
  g_fb[i]=(u32*)memalign(64,(size_t)g_pitch*g_height);
  g_scanout[i]=(u32*)tracked_rsx_memalign(64,(size_t)g_pitch*g_height);
  if(!g_fb[i]||!g_scanout[i])return -6;
  memset(g_fb[i],0,(size_t)g_pitch*g_height);memset(g_scanout[i],0,(size_t)g_pitch*g_height);
  rsxAddressToOffset(g_scanout[i],&g_fb_off[i]);
  gcmSetDisplayBuffer(i,g_fb_off[i],g_pitch,g_width,g_height);
 }
 gcmResetFlipStatus();g_flip_pending=0;g_back=0;configure_ui_metrics();wait_rsx_idle_init();return 0;
}
static bool wait_for_previous_flip(){
 if(!g_flip_pending)return true;
 /* Never let a stuck/late RSX preview frame wedge the PPU input loop.
    Normal VSYNC completion is ~16.7 ms; 100 ms is ample headroom while still
    guaranteeing Circle/navigation can recover if an emulator/RSX flip stalls. */
 int spins=0;
 while(gcmGetFlipStatus()!=0 && spins<500){usleep(200);spins++;}
 if(gcmGetFlipStatus()!=0){rsxFlushBuffer(g_ctx);return false;}
 gcmResetFlipStatus();
 g_flip_pending=0;
 return true;
}
static void upload_cpu_frame(){
 // Copy only dirty scanlines; adjacent dirty rows form one sequential write.
 for(unsigned y=0;y<g_height;){
  if(!g_damage.changed(y)){y++;continue;}
  unsigned first=y++;while(y<g_height&&g_damage.changed(y))y++;
  memcpy((unsigned char*)g_scanout[g_back]+(size_t)first*g_pitch,
   (unsigned char*)g_fb[g_back]+(size_t)first*g_pitch,(size_t)(y-first)*g_pitch);
 }
 __sync_synchronize();
}
static void present(){
 if(icn_hw_preview_active()){
  restore_model_base_to_buffer(g_fb[g_back]);
  /* Keep the display framebuffer owned by the CPU HUD.  Seed the off-screen
     RSX target from the completed preview background using a GPU-local copy,
     render the model there, then copy only that rectangle back.  This avoids
     CPU readback of freshly rendered RSX local memory. */
  __sync_synchronize();
  rsxSetTransferImage(g_ctx,GCM_TRANSFER_LOCAL_TO_LOCAL,
   g_icn_hw_color_offset,g_pitch,(u32)g_model_base_x,(u32)g_model_base_y,
   g_fb_off[g_back],g_pitch,(u32)g_model_base_x,(u32)g_model_base_y,
   (u32)g_model_base_w,(u32)g_model_base_h,4);
  if(icn_hw_draw_model()){
   rsxSetTransferImage(g_ctx,GCM_TRANSFER_LOCAL_TO_LOCAL,
    g_fb_off[g_back],g_pitch,(u32)g_model_base_x,(u32)g_model_base_y,
    g_icn_hw_color_offset,g_pitch,(u32)g_model_base_x,(u32)g_model_base_y,
    (u32)g_model_base_w,(u32)g_model_base_h,4);
   /* Do not block the PPU here.  The draw, copy-back and following flip are
      in one ordered RSX command stream, so the flip cannot complete before
      the preview blit is done.  Waiting with rsxFinish every animation frame
      can stall the main input loop when switching ICN entries. */
  }
 }
 /* Keep CPU framebuffer writes and RSX rendering on a buffer that is no longer
    being scanned out.  PSL1GHT's double-buffering contract requires waiting
    for the previous flip before reusing the next back buffer. */
 s32 flip_rc=gcmSetFlip(g_ctx,(u8)g_back);
 if(flip_rc==0){
  g_present_frames++;
  rsxFlushBuffer(g_ctx);
  /* Do not enqueue gcmSetWaitFlip here.  This librsx path may implement the
     wait via a command-buffer subroutine; when the FIFO is already inside a
     subroutine RPCS3 correctly rejects the nested CALL.  Buffer ownership is
     enforced by wait_for_previous_flip() on the PPU before the next draw. */
  g_flip_pending=1;
  g_back^=1;
 }else{
  /* A pending flip should be rare after draw()'s frame-acquire wait.  Do not
     enqueue another flip on failure; keep the same back buffer for retry. */
  rsxFlushBuffer(g_ctx);
 }
}
static void shutdown_video(){
 if(g_ctx){wait_for_previous_flip();rsxFinish(g_ctx,1);}
 for(int i=0;i<2;i++){free(g_fb[i]);g_fb[i]=NULL;if(g_scanout[i])tracked_rsx_free(g_scanout[i]);g_scanout[i]=NULL;}
 if(g_icn_hw_fp_ucode)tracked_rsx_free(g_icn_hw_fp_ucode);g_icn_hw_fp_ucode=NULL;
 if(g_icn_hw_vertices)tracked_rsx_free(g_icn_hw_vertices);g_icn_hw_vertices=NULL;
 if(g_icn_hw_texture)tracked_rsx_free(g_icn_hw_texture);g_icn_hw_texture=NULL;
 if(g_icn_hw_color)tracked_rsx_free(g_icn_hw_color);g_icn_hw_color=NULL;
 if(g_icn_hw_depth)tracked_rsx_free(g_icn_hw_depth);g_icn_hw_depth=NULL;g_icn_hw_ready=0;
 free(g_bg_cache); g_bg_cache=NULL; g_bg_cache_ready=0;
 free(g_list_base_cache); g_list_base_cache=NULL; g_list_cache_valid=0;
 free(g_model_cache); g_model_cache=NULL; free(g_model_filter_cache); g_model_filter_cache=NULL;
 free(g_model_zbuf); g_model_zbuf=NULL; g_model_cache_valid=0;
 free(g_model_base_cache); g_model_base_cache=NULL; g_model_base_valid=0;
 free(g_model_sx);g_model_sx=NULL;free(g_model_sy);g_model_sy=NULL;free(g_model_zinv);g_model_zinv=NULL;free(g_model_nx);g_model_nx=NULL;free(g_model_ny);g_model_ny=NULL;g_model_vertex_cap=0;
 free(g_preview_base_cache); g_preview_base_cache=NULL; g_preview_base_valid=0;
}
static void sysutil_cb(u64 status,u64 param,void *userdata){(void)param;(void)userdata;if(status==SYSUTIL_EXIT_GAME)running=0;}

static int endswith(const char *s,const char *x){size_t a=strlen(s),b=strlen(x);return a>=b&&!strcasecmp(s+a-b,x);}static const char *base_name(const char *p){const char*s=strrchr(p,'/');return s?s+1:p;}
static void parent_dir(){char*s=strrchr(cwd,'/');if(!s||s==cwd){strcpy(cwd,"/");return;}*s=0;}static void join(char*out,size_t n,const char*a,const char*b){if(!strcmp(a,"/"))snprintf(out,n,"/%s",b);else snprintf(out,n,"%s/%s",a,b);}static int cmp_items(const void*A,const void*B){const item_t*a=(const item_t*)A,*b=(const item_t*)B;if(a->is_dir!=b->is_dir)return b->is_dir-a->is_dir;return strcasecmp(a->name,b->name);}
static int is_mount_root(const char *p){
 if(!strcmp(p,"/dev_hdd0")||!strcmp(p,"/dev_hdd1")||!strcmp(p,"/dev_bdvd"))return 1;
 if(!strncmp(p,"/dev_usb",8) && strlen(p)==11 && isdigit((unsigned char)p[8]) && isdigit((unsigned char)p[9]) && isdigit((unsigned char)p[10]))return 1;
 return 0;
}
static int path_exists_dir(const char *p){struct stat st;return stat(p,&st)==0 && S_ISDIR(st.st_mode);}
static void refresh_devices(){
 item_count=0;
 for(int i=0;i<2 && item_count<MAX_ITEMS;i++){char p[32];snprintf(p,sizeof(p),"/dev_hdd%d",i);if(path_exists_dir(p)){item_t*it=&items[item_count++];memset(it,0,sizeof(*it));snprintf(it->name,sizeof(it->name),"HDD %d",i);strncpy(it->path,p,sizeof(it->path)-1);it->is_dir=1;}}
 for(int i=0;i<8 && item_count<MAX_ITEMS;i++){char p[32];snprintf(p,sizeof(p),"/dev_usb%03d",i);if(path_exists_dir(p)){item_t*it=&items[item_count++];memset(it,0,sizeof(*it));snprintf(it->name,sizeof(it->name),"USB %03d",i);strncpy(it->path,p,sizeof(it->path)-1);it->is_dir=1;}}
 if(selected>=item_count)selected=item_count?item_count-1:0;if(selected<0)selected=0;
 snprintf(status_line,sizeof(status_line),"%d storage device%s found",item_count,item_count==1?"":"s");
}
static void refresh_fs(){item_count=0;DIR*d=opendir(cwd);if(!d){snprintf(status_line,sizeof(status_line),"Cannot open %s",cwd);return;}struct dirent*de;while((de=readdir(d))&&item_count<MAX_ITEMS){if(!strcmp(de->d_name,".")||!strcmp(de->d_name,".."))continue;item_t*it=&items[item_count];memset(it,0,sizeof(*it));strncpy(it->name,de->d_name,sizeof(it->name)-1);char p[PATHSZ];join(p,sizeof(p),cwd,de->d_name);struct stat st;if(!stat(p,&st)){it->is_dir=S_ISDIR(st.st_mode);it->size=(unsigned long long)st.st_size;}item_count++;}closedir(d);qsort(items,item_count,sizeof(items[0]),cmp_items);if(selected>=item_count)selected=item_count?item_count-1:0;if(selected<0)selected=0;}

#include "emu_ui.inc"
