#ifndef EMU_CONFIG_H
#define EMU_CONFIG_H
struct Settings {
 char bios[1024],elf[1024],iso[1024],mc1[1024],mc2[1024],hdd[1024],host[1024];
 unsigned batch;
 mutable char save_error[160];
 Settings(); bool load(const char*); bool save(const char*) const;
 char* path(unsigned i);
 const char* path(unsigned i) const;
};
#endif
