#ifndef DISC_BOOT_H
#define DISC_BOOT_H
#include <stddef.h>
struct DiscBoot {char path[1024],version[64],vmode[64];};
bool read_disc_boot(const char*root,DiscBoot&boot,char*error,size_t capacity);
#endif
