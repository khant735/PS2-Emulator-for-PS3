#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static void setup(Core&c,unsigned op){std::vector<unsigned char>r(4*1024*1024);for(unsigned j=0;j<4;j++)r[j]=(op>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;
 setup(c,0x700014a9);c.reg[2]=c.reg_hi[2]=~0ull;assert(c.step());assert(c.reg[2]==0&&c.reg_hi[2]==0);
 const unsigned codes[]={0x489,0x4c9,0x4a9,0x4e9};
 const unsigned long long low[]={0x0000000000000000ull,0xffffffffffffffffull,0xffffffffffffffffull,0};
 const unsigned long long high[]={0x0000000000000000ull,0xffffffffffffffffull,0xffffffffffffffffull,0};
 for(unsigned k=0;k<4;k++)for(unsigned d=0;d<4;d++){
  setup(c,0x70000000|(1<<21)|(2<<16)|(d<<11)|codes[k]);c.reg[1]=0x5555555555555555ull;c.reg[2]=0xaaaaaaaaaaaaaaaaull;c.reg_hi[1]=0xf0f0f0f0f0f0f0f0ull;c.reg_hi[2]=0x0f0f0f0f0f0f0f0full;
  assert(c.step());assert(c.reg[d]==(d?low[k]:0)&&c.reg_hi[d]==(d?high[k]:0));
 }
 // Non-complementary bits distinguish AND, OR and XOR on each half.
 setup(c,0x70221ce9);c.reg[1]=0x1234;c.reg[2]=0x1200;c.reg_hi[1]=0xf0;c.reg_hi[2]=0x30;assert(c.step());assert(c.reg[3]==~0x1234ull&&c.reg_hi[3]==~0xf0ull);
 setup(c,0x70221cc9);c.reg[1]=0x1234;c.reg[2]=0x1200;c.reg_hi[1]=0xf0;c.reg_hi[2]=0x30;assert(c.step());assert(c.reg[3]==0x34&&c.reg_hi[3]==0xc0);
 setup(c,0x70221c89);c.reg[1]=0x1234;c.reg[2]=0x1200;c.reg_hi[1]=0xf0;c.reg_hi[2]=0x30;assert(c.step());assert(c.reg[3]==0x1200&&c.reg_hi[3]==0x30);
 setup(c,0x70221809);assert(!c.step()&&c.stop==Core::UNSUPPORTED);
 std::vector<unsigned char> rom(4*1024*1024);const unsigned words[]={0x3c06bfc0,0x34c60100,0x78c20000,0x3c048000,0x34842000,0x7c820000,0x78830000,0x700014a9,0x700024e9,0x70642c89,0x706534c9,0xbf470000,0xbf560000,0xbf560001,0x0000000d};
 for(unsigned i=0;i<15;i++)for(unsigned j=0;j<4;j++)rom[4*i+j]=(words[i]>>(8*j))&255;for(unsigned i=0;i<16;i++)rom[256+i]=i;
 assert(c.loadBios(rom.data(),rom.size()));for(unsigned i=0;i<14;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT);
 assert(c.reg[2]==0&&c.reg_hi[2]==0&&c.reg[3]==0x0706050403020100ull&&c.reg_hi[3]==0x0f0e0d0c0b0a0908ull&&c.reg[4]==~0ull&&c.reg_hi[4]==~0ull&&c.reg[5]==c.reg[3]&&c.reg_hi[5]==c.reg_hi[3]&&c.reg[6]==0&&c.reg_hi[6]==0);
 puts("PASS: 128-bit PAND/PXOR/POR/PNOR, BIOS opcode, overlap, zero and unsupported MMI guard");
}
