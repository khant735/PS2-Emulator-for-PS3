#ifndef UI_PACING_H
#define UI_PACING_H
// Host UI pacing only; independent of guest timing. No unsigned underflow
// after a slow frame or a backwards wall-clock adjustment.
static inline unsigned ui_sleep_us(unsigned long long start,unsigned long long end){
 const unsigned budget=16667;
 if(end<start)return 0;
 unsigned long long elapsed=end-start;
 return elapsed>=budget?0:budget-(unsigned)elapsed;
}
#endif
