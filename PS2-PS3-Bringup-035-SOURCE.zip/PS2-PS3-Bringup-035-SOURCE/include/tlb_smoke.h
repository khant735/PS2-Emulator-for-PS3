#ifndef TLB_SMOKE_H
#define TLB_SMOKE_H
#include <stdint.h>
// Original guest instruction test, no firmware content. Maps VA 00400000/00401000 to RAM 2000/5000.
static const uint32_t tlb_smoke_words[]={
0x40800000u,0x40802800u,0x3c080040u,0x40885000u,0x34080087u,0x40881000u,0x34080147u,0x40881800u,0x42000002u,0x42000008u,0x40090000u,0x42000001u,0x400b1000u,0x3c0c0040u,0x40806000u,0x340d002au,0xad8d0000u,0x8d8e0000u,0x340d002du,0xad8d1000u,0x8d8f1000u,0x0000000du
};
#endif
