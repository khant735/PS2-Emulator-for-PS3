#include "emu_core.h"
#include <assert.h>
#include <stdio.h>
#include <vector>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>rom(4*1024*1024);unsigned at=0;for(unsigned v:w)for(unsigned b=0;b<4;b++)rom[at++]=(v>>(8*b))&255;assert(c.loadBios(rom.data(),rom.size()));}
static void pattern(Core&c,unsigned a){for(unsigned i=0;i<4;i++)assert(c.write32(a+i*4,0x03020100+i*0x04040404));}
static void check(Core&c,unsigned a,bool zero=false){unsigned v;for(unsigned i=0;i<4;i++){assert(c.read32(a+i*4,v));assert(v==(zero?0:0x03020100+i*0x04040404));}}
int main(){Core c;unsigned v;
 // Exact BIOS opcode: LQ v0,0(a2), then SQ. All four words must survive.
 setup(c,{0x78c20000,I(31,4,2,0)});c.reg[6]=0x80001000;c.reg[4]=0x80002000;pattern(c,0x80001000);assert(c.step());assert(c.reg[2]==0x0706050403020100ull);assert(c.step());check(c,0x80002000);
 // Effective addresses round down, including a signed immediate.
 setup(c,{I(30,6,2,-1),I(31,4,2,15)});c.reg[6]=0x80001010;c.reg[4]=0x80002000;pattern(c,0x80001000);assert(c.step()&&c.step());check(c,0x80002000);
 // Scalar writes replace only the lower 64 bits of a 128-bit GPR.
 setup(c,{I(30,6,2,0),I(9,0,2,42),I(31,4,2,0)});c.reg[6]=0x80001000;c.reg[4]=0x80002000;pattern(c,0x80001000);assert(c.step()&&c.step()&&c.step());assert(c.read32(0x80002000,v)&&v==42);assert(c.read32(0x80002004,v)&&v==0);assert(c.read32(0x80002008,v)&&v==0x0b0a0908);assert(c.read32(0x8000200c,v)&&v==0x0f0e0d0c);
 setup(c,{I(30,6,0,0),I(31,4,0,0)});c.reg[6]=0x80001000;c.reg[4]=0x80002000;pattern(c,0x80001000);pattern(c,0x80002000);assert(c.step()&&c.reg[0]==0&&c.step());check(c,0x80002000,true);
 // Failed LQ/SQ does not partially overwrite registers or RAM.
 setup(c,{I(30,6,2,0),I(30,7,2,0)});pattern(c,0x80001000);c.reg[6]=0x80001000;c.reg[7]=0x82000000;assert(c.step());assert(!c.step()&&c.reg[2]==0x0706050403020100ull&&c.fault_size==16);
 setup(c,{I(31,4,2,0)});c.reg[4]=0xbfc00000;assert(!c.step()&&c.fault_write&&c.fault_size==16);assert(c.read32(0xbfc00000,v)&&v==I(31,4,2,0));
 setup(c,{I(30,6,2,0),I(31,4,2,0)});c.reg[6]=0x81fffff0;c.reg[4]=0x70003ff7;pattern(c,0x81fffff0);assert(c.step()&&c.step());check(c,0x70003ff0);
 setup(c,{I(30,6,2,0)});c.reg[6]=0xb000f500;assert(!c.step()&&c.ee_f500_reads==0&&c.ee_f500_writes==0);
 setup(c,{I(31,6,2,0)});c.reg[6]=0xb000f500;assert(!c.step()&&c.ee_f500_writes==0);
 // TLB mapping permissions apply to the whole 16-byte access.
 setup(c,{I(30,6,2,0),I(31,4,2,0)});pattern(c,0x80001000);assert(c.tlb.put(0,0,0x400000,0x47,0x83));c.cp0[12]=0;c.reg[6]=0x400000;c.reg[4]=0x401000;assert(c.step());assert(!c.step()&&c.fault_size==16);assert(c.read32(0x80002000,v)&&v==0);
 // Same ROM-to-RAM program used by the console menu test.
 setup(c,{0x3c06bfc0,0x34c60100,0x78c20000,0x3c048000,0x34842000,0x7c820000,0x78830000,0x0000000d});
 // ROM is read-only to guest code; load a complete fixture with payload.
 std::vector<unsigned char> rom(4*1024*1024);unsigned words[]={0x3c06bfc0,0x34c60100,0x78c20000,0x3c048000,0x34842000,0x7c820000,0x78830000,0x0000000d};
 for(unsigned i=0;i<8;i++)for(unsigned j=0;j<4;j++)rom[i*4+j]=(words[i]>>(8*j))&255;
 for(unsigned i=0;i<16;i++)rom[256+i]=i;assert(c.loadBios(rom.data(),rom.size()));
 for(unsigned i=0;i<7;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT);assert(c.reg[3]==0x0706050403020100ull&&c.reg_hi[3]==0x0f0e0d0c0b0a0908ull);
 puts("PASS: LQ/SQ 128-bit bytes, alignment, signed offsets, scalar preservation, zero, faults, boundaries, scratch and TLB permissions");}
