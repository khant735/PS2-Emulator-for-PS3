from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];s=(r/'source/main.cpp').read_text()
def function(name):
 a=s.index('static '+name);b=s.index('{',a);depth=1;i=b+1
 while depth:
  if s[i]=='{':depth+=1
  if s[i]=='}':depth-=1
  i+=1
 return s[a:i]
p=r/'build/host-framebuffer';p.mkdir(parents=True,exist_ok=True)
code='''
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cstdint>
#include <malloc.h>
#include "text_frame.h"
static FrameDamage g_damage;
using u32=uint32_t;
static void*g_ctx;static u32*g_fb[2];static u32 g_fb_off[2];
static u32 g_width,g_height,g_pitch;static int g_back,g_flip_pending;
static void*local[2];static int allocations;
struct videoState{struct{int resolution,aspect;}displayMode;};
struct videoConfiguration{int resolution,format,aspect;u32 pitch;};
struct videoResolution{u32 width,height;};
#define HOST_ADDR_ALIGNMENT 64
#define HOSTBUFFER_SIZE 1024
#define RSX_COMMAND_BUFFER_SIZE 64
#define VIDEO_BUFFER_FORMAT_XRGB 0
#define GCM_FLIP_VSYNC 0
static int rsxInit(void**,int,int,void*){return 0;}
static int videoGetState(int,int,videoState*){return 0;}
static int videoGetResolution(int,videoResolution*r){r->width=64;r->height=32;return 0;}
static int videoConfigure(int,videoConfiguration*,void*,int){return 0;}
static void gcmSetFlipMode(int){}
static void*tracked_rsx_memalign(int a,size_t n){return local[allocations++]=memalign(a,n);}
static void rsxAddressToOffset(void*p,u32*o){*o=p==local[0]?0:1;}
static void gcmSetDisplayBuffer(int i,u32 offset,u32,u32,u32){assert(offset==unsigned(i));}
static void gcmResetFlipStatus(){}
static void configure_ui_metrics(){}
static void wait_rsx_idle_init(){}
'''
if 'static u32 *g_scanout[2]' in s:code+='static u32*g_scanout[2];\n'
code+=function('int video_init()')
code+='''
int main(){assert(video_init()==0);assert(allocations==2);
 assert(g_fb[0]!=local[0]&&g_fb[1]!=local[1]);
 g_fb[0][0]=0xff123456;
 assert(((u32*)local[0])[0]==0); // CPU drawing must not touch scanout.
'''
if 'static void upload_cpu_frame()' in s:
 code=code.replace('int main(){',function('void upload_cpu_frame()')+'\nint main(){')
 code+='upload_cpu_frame();assert(((u32*)local[0])[0]==0xff123456);assert(((u32*)local[1])[0]==0);\n'
code+='g_damage.begin(g_height);g_damage.mark(0,1);g_fb[0][0]=7;g_fb[0][g_pitch/4]=9;upload_cpu_frame();assert(((u32*)local[0])[0]==7);assert(((u32*)local[0])[g_pitch/4]==0);\n'
code+='}\n' 
(p/'test.cpp').write_text(code)
subprocess.run(['c++','-I'+str(r/'include'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
subprocess.run([str(p/'test')],check=True)
print('PASS: CPU framebuffer separated from RSX scanout; completed frame uploads to selected display buffer')
