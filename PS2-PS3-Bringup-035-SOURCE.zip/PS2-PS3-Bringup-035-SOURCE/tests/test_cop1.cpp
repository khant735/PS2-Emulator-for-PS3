#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));c.cp0[12]|=0x20000000;}
int main(){Core c;unsigned v;
 // MTC1 f12; exact BIOS SWC1 f12,0x48(sp); LWC1 f0; MFC1 v0,f0.
 setup(c,{0x44836000,0xe7ac0048,0xc7a00048,0x44020000});c.reg[3]=0x89abcdef;c.reg[29]=0x80001000;c.reg_hi[2]=0x12345678;
 assert(c.step()&&c.step());assert(c.read32(0x80001048,v)&&v==0x89abcdef);assert(c.step()&&c.step());assert(c.reg[2]==0xffffffff89abcdefull&&c.reg_hi[2]==0x12345678);
 // Negative offset, f31 and exact raw bits (no host floating-point conversion).
 setup(c,{0x4483f800,0xe49ffffc,0xc49efffc,0x4402f000});c.reg[3]=0x7fc12345;c.reg[4]=0x80002004;assert(c.step()&&c.step()&&c.step()&&c.step());assert(c.reg[2]==0x7fc12345);
 // Failed load preserves previous FPR contents; store fails without changing RAM.
 setup(c,{0x44836000,0xc48c0000});c.reg[3]=0x12345678;c.reg[4]=0x82000000;assert(c.step());assert(!c.step()&&c.fault_size==4&&!c.fault_write&&c.fpr[12]==0x12345678);
 setup(c,{0xe7ac0048});c.reg[29]=0x80001001;assert(!c.step()&&c.fault_write&&c.fault_size==4);
 setup(c,{0xe7ac0048});c.reg[29]=0xbfbfffb8;assert(!c.step()&&c.fault_write);
 setup(c,{0x44836000});c.cp0[12]&=~0x20000000u;assert(!c.step()&&c.instructions==0);
 setup(c,{0xe7ac0048});c.cp0[12]&=~0x20000000u;assert(!c.step()&&c.instructions==0);
 setup(c,{0x46000000});assert(!c.step()&&c.stop==Core::UNSUPPORTED);
 setup(c,{0x44836001});assert(!c.step()&&c.stop==Core::UNSUPPORTED);
 setup(c,{0});for(unsigned i=0;i<32;i++)assert(c.fpr[i]==0);
 setup(c,{0x44800000,0x44000000});c.fpr[0]=123;assert(c.step()&&c.fpr[0]==0&&c.step()&&c.reg[0]==0&&c.reg_hi[0]==0);
 setup(c,{0xc48c0000});c.reg[4]=0x80001001;c.fpr[12]=123;assert(!c.step()&&c.fpr[12]==123);
 setup(c,{0xe48c0000});c.reg[4]=0x401000;c.cp0[12]=0x20000000;assert(c.tlb.put(0,0,0x400000,0x47,0x83));assert(!c.step()&&c.fault_write);
 setup(c,{0x10000002,0xe7ac0048,0x24020001,0x24020002});c.reg[29]=0x80001000;c.fpr[12]=0x12345678;assert(c.step()&&c.step()&&c.step()&&c.reg[2]==2);assert(c.read32(0x80001048,v)&&v==0x12345678);
 setup(c,{0x3c1d8000,0x37bd1000,0x3c0389ab,0x3463cdef,0x44836000,0xe7ac0048,0xc7a00048,0x44020000,0x3c08b000,0x3508f130,0x8d090000,0x25080050,0x240a0041,0xa10a0000,0x3c08b000,0x3508f010,0x240a0005,0xad0a0000,0x8d0b0000,0xad0a0000,0x8d0c0000,0x0000000d});
 for(unsigned i=0;i<21;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT&&c.reg[2]==0xffffffff89abcdefull&&c.fpr[0]==0x89abcdef&&c.fpr[12]==0x89abcdef);
 puts("PASS: COP1 raw transfers, BIOS SWC1, f0/f31, sign extension, offsets, faults, CU1 and unsupported guards");
}
