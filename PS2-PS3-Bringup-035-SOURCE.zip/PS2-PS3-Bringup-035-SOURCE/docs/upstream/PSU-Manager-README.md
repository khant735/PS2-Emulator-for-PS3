# PS2 .psu Save Manager v0.01

A small PSL1GHT PS3 homebrew file explorer with uLaunchELF/wLaunchELF `.psu` archive support.

## Controls

**HDD/USB browser**: D-pad Up/Down moves one item, **L1/R1** jumps backward/forward 10 items, **Left/Right** switches between mounted HDD/USB devices, **L2** cancels/clears the staged or current action, **X** opens directories or a `.psu`, **O** goes back, **Square** copies a normal file into the inject clipboard, **L3** exports/extracts the selected `.psu` to `<name>_extracted`, **Select** recursively deletes the selected file or folder, **R2** creates a new blank PSU template (`blank.psu`, then `blank_01.psu`, etc.), and **R3** creates `<folder>.psu` from the selected folder.

**Inside a PSU**: D-pad Up/Down moves one item, **L1/R1** jumps backward/forward 10 items, **L2** cancels/clears the staged or current action, **O** closes it, **Square** exports the selected PSU file to the directory containing the PSU, **Triangle** injects/replaces the file previously copied with Square, and **Select** deletes the selected PSU entry.

The program starts at `/dev_hdd0`; use **Left/Right** to cycle directly between detected `/dev_hdd0`–`/dev_hdd1` and `/dev_usb000`–`/dev_usb007` devices.

## PSU compatibility

The serializer uses 0x200-byte PSU records, normal PS2 MC directory/file attributes (`0x8427`/`0x8497`), 32-byte names, PS2-style 8-byte timestamps, and pads file payloads to 0x400-byte boundaries. Numeric fields are encoded little-endian explicitly because a PS3 PPU is big-endian while the PS2/uLaunchELF representation is little-endian.

Creating a PSU from an ordinary HDD directory necessarily synthesizes PS2 memory-card metadata that does not exist on the PS3 filesystem. Editing an existing PSU preserves its root header and untouched entry headers/data.

## Build

Requirements: current `ps3dev/ps3toolchain` and PSL1GHT. This version uses a software text framebuffer and does not require NVIDIA Cg. Then:

```sh
export PS3DEV=/opt/ps3dev
export PSL1GHT=$PS3DEV/psl1ght
make host-test
make
make pkg
```

Expected outputs are `ps3psumanager.elf`, `ps3psumanager.self`, and `ps3psumanager.pkg`. The on-screen UI is rendered directly into the framebuffer, so no external shader/font vendor step is required.

## Safety

PSU modifications are written to `<archive>.tmp` first and renamed over the original only after a successful write. Keep backups of important saves anyway, especially before testing on real hardware.

## Host PSU utility

For format testing without a PS3:

```sh
cc -std=c11 -O2 -Iinclude source/psu.c tools/psucli.c -o psucli
./psucli create SAVE_FOLDER save.psu BASLUS-12345
./psucli blank blank.psu BLANK
./psucli list save.psu
./psucli extract save.psu output_dir
./psucli add save.psu replacement.bin DATA.BIN
./psucli del save.psu DATA.BIN
```

## Provenance

PSU layout/behavior was checked against `ps2homebrew/wLaunchELF`'s `filer.c` and changelog. PSL1GHT's current `ppu_rules`, RSX test, debugfont renderer, and package target structure were used as the build/UI reference. The vendored PSL1GHT support files retain their upstream license/provenance.


## Exit to XMB
Press **START** at any time to close PS2 .psu Save Manager v0.01 and return to the PS3 XMB. The normal PS button / Quit Game system callback is also supported.


## Storage devices

The browser checks only `/dev_hdd0` and `/dev_hdd1` for HDD volumes and `/dev_usb000` through `/dev_usb007` for USB volumes. Press **Left/Right** at any time to cycle directly between the currently mounted devices. Circle only navigates back/up and does not open a device screen.

## Injection success feedback

When a file is successfully imported/injected into an open `.psu`, the UI changes to a blue success state for about six seconds and displays the exact filename that was injected. Failed injections leave the normal UI in place and report the error in the status line.

UI note: inside a PSU, the currently selected entry (the Square export target) is highlighted in orange. Outside a PSU, the normal cursor keeps its existing colour.

UI note: a file stored in the injection clipboard is shown in pure red, even after moving the cursor away.

## Cancel action

Press **L2** to cancel a staged copy/injection source, clear the currently staged orange PSU export target, and dismiss the current transient success/error feedback. This clears pending UI/action state only; it does not undo filesystem changes that have already completed.

## File/folder and PSU creation actions

Outside an open PSU, **Select** deletes the selected regular file or recursively deletes the selected folder and all of its contents. **R2** creates an empty valid PSU container in the current directory; filenames are automatically chosen as `blank.psu`, `blank_01.psu`, and so on to avoid overwriting an existing template. **R3** packages the currently selected directory into `<directory>.psu`. Directory-to-PSU creation includes regular files in that selected directory; PS2 metadata is synthesized where the host filesystem has no equivalent.


## Whole PSU export

Outside an open PSU, select a `.psu` file and press **L3** to export/extract the entire archive into `<name>_extracted` in the current directory. **L3 is the only whole-archive export key.**

### Folder -> PSU filename cleanup
When R3 creates a PSU from a folder, the output filename is normalized for common extracted-save folder names. A trailing `_EXTRACTED` or `_EXPORTED` suffix is removed, followed by a trailing CRC32/checksum in the form ` (XXXXXXXX)` where X is hexadecimal. For example, `SYS_OSDMENU OSDMENU (5AC43871)_EXTRACTED` becomes `SYS_OSDMENU OSDMENU.psu`. If that filename already exists, `_01`, `_02`, etc. are appended instead of overwriting it.
