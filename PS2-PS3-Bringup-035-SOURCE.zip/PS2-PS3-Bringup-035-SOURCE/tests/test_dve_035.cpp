#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
int main(){
 Core c;std::vector<unsigned char> bios(4*1024*1024);
 const unsigned op[]={0x3c03ba00,0x24020081,0xa4620000,0x0000000d};
 for(unsigned i=0;i<4;i++)for(unsigned j=0;j<4;j++)bios[i*4+j]=(op[i]>>(j*8))&255;
 assert(c.loadBios(bios.data(),bios.size()));
 assert(c.dve.write(2,0x42));
 for(int i=0;i<3;i++)assert(c.step());
 assert(c.dve.bus[0]==0x81&&c.dve.compat_mode42_unselected==1);
 assert(!c.step()&&c.stop==Core::BREAKPOINT);
 printf("PASS: Build 035 BIOS mode42 unselected 0x81 compatibility\n");
}
