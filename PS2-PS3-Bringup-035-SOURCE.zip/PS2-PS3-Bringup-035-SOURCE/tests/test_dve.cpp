#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;setup(c,{0xa4440000,I(37,2,5,0)});c.reg[2]=0xba000008;c.reg[4]=3;assert(c.step()&&c.step()&&c.reg[5]==3);
 for(unsigned a:{0x1a000008u,0x9a000008u,0xba000008u}){setup(c,{0xa4440000,I(37,2,5,0)});c.reg[2]=a;c.reg[4]=0x8123;assert(c.step()&&c.step()&&c.reg[5]==0x8123);}
 for(unsigned op:{32u,35u,55u,40u,43u,63u}){setup(c,{I(op,2,4,0)});c.reg[2]=0xba000008;assert(!c.step()&&c.dve.writes==0&&c.dve.reads==0);}
 setup(c,{I(41,2,4,1)});c.reg[2]=0xba000008;assert(!c.step());
 setup(c,{I(41,2,4,0)});c.reg[2]=0xba000014;assert(!c.step());
 setup(c,{0});c.pc=0xba000008;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);
 setup(c,{I(41,2,4,0)});c.reg[2]=0x400008;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x680003,0x680043));assert(!c.step()&&c.dve.writes==0);
 EeDve d;d.reset();uint64_t v;assert(d.write(8,3)&&d.write(10,1)&&d.write(2,0x43)&&d.write(16,255)&&d.write(18,0x1234)&&d.write(0,0x82));
 assert(d.known[255]&&d.device[255]==0x1234&&d.commands==1);assert(d.read(6,v)&&v==0);assert(d.read(6,v)&&v==0);assert(d.read(6,v)&&v==2);assert(d.read(6,v)&&v==2&&!d.active);
 assert(d.write(6,0)&&d.write(2,0x42)&&d.write(0,0x81)&&d.read(16,v)&&v==0x1234);
 assert(d.write(10,0)&&d.read(6,v)&&(v&1));assert(d.write(10,1)&&d.read(6,v)&&!(v&1));
 unsigned long long count=d.writes;assert(!d.write(0,0x8f)&&d.writes==count);assert(d.write(2,0x43)&&d.write(16,256));count=d.writes;assert(!d.write(0,0x82)&&d.writes==count);
 d.reset();assert(d.write(2,0x42)&&d.write(0,0x81)&&d.compat_mode42_unselected==1&&d.commands==1);assert(d.write(2,0x41)&&d.write(0,0x80)&&d.error);d.reset();assert(!d.active&&!d.error&&!d.known[255]&&d.commands==0);
 setup(c,{0x3c02ba00,0x34420008,0x24040003,0xa4440000,0x94450000,0x0000000d});for(unsigned i=0;i<5;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT&&c.reg[5]==3);
 puts("PASS: DVE BIOS halfword write/readback");}
