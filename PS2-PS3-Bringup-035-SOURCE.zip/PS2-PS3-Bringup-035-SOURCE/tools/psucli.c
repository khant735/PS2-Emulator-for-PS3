#include "psu.h"
#include <stdio.h>
#include <string.h>

static int show(const psu_entry_t *e,size_t i,void *x){(void)x;printf("%3zu  %c  %10u  %s\n",i,(e->attr==PSU_ATTR_FILE?'F':'D'),e->size,e->name);return 0;}
int main(int argc,char **argv){
    if(argc<3){fprintf(stderr,"usage: %s list FILE.psu | extract FILE.psu DIR | create DIR FILE.psu [SAVE] | blank FILE.psu [SAVE] | add FILE.psu FILE [NAME] | del FILE.psu NAME\n",argv[0]);return 2;}
    int rc=-1;
    if(!strcmp(argv[1],"list"))rc=psu_list(argv[2],show,NULL);
    else if(!strcmp(argv[1],"extract")&&argc>=4)rc=psu_extract_all(argv[2],argv[3]);
    else if(!strcmp(argv[1],"create")&&argc>=4)rc=psu_create_from_dir(argv[2],argv[3],argc>4?argv[4]:NULL);
    else if(!strcmp(argv[1],"blank"))rc=psu_create_blank(argv[2],argc>3?argv[3]:NULL);
    else if(!strcmp(argv[1],"add")&&argc>=4){const char *n; if(argc>4) n=argv[4]; else { n=strrchr(argv[3],'/'); n=n?n+1:argv[3]; } rc=psu_add_or_replace(argv[2],argv[3],n);}
    else if(!strcmp(argv[1],"del")&&argc>=4)rc=psu_delete_entry(argv[2],argv[3]);
    if(rc){fprintf(stderr,"error: %s (%d)\n",psu_strerror(rc),rc);return 1;}return 0;
}
