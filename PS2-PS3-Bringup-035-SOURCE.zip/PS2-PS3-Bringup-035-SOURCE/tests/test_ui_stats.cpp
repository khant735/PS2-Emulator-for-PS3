#include "ui_stats.h"
#include <assert.h>
#include <stdio.h>
int main(){UiFps f;assert(f.sample(0,0)&&!f.valid);assert(!f.sample(999999,59));assert(f.sample(1000000,60)&&f.valid&&f.fps==60);assert(f.sample(3000000,150)&&f.fps==45);assert(f.sample(2000000,150)&&!f.valid);assert(f.sample(3000000,150)&&f.fps==0);
 VramUsage v;int a,b;assert(!v.add(0,99)&&v.bytes==0);assert(v.add(&a,10)&&v.add(&b,20)&&v.bytes==30);v.remove(&a);assert(v.bytes==20);v.remove(&a);assert(v.bytes==20);v.remove(&b);assert(v.bytes==0);puts("PASS: measured FPS intervals/reset/idle; tracked VRAM allocation/free");}
