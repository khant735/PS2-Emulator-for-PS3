#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
#include <string>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;
 setup(c,{0x8c620000});c.reg[3]=0xb000f130;assert(c.step()&&c.reg[2]==0);
 setup(c,{I(40,3,2,0)});c.reg[3]=0xb000f180;c.reg[2]='A';assert(c.step());
 assert(c.serial_tx_size==1&&c.serial_tx[0]=='A'&&c.serial_tx_total==1);
 for(unsigned base:{0x1000f130u,0x9000f130u,0xb000f130u}){setup(c,{0x8c620000});c.reg[3]=base;assert(c.step()&&c.reg[2]==0&&c.serial_status_reads==1);}
 for(unsigned base:{0x1000f180u,0x9000f180u,0xb000f180u}){setup(c,{I(40,3,2,0)});c.reg[3]=base;c.reg[2]=0x141;assert(c.step()&&c.serial_tx[0]=='A');}
 for(unsigned op:{41u,43u,63u}){setup(c,{I(op,3,2,0)});c.reg[3]=0xb000f180;assert(!c.step()&&c.serial_tx_total==0);}
 for(unsigned op:{32u,33u,55u}){setup(c,{I(op,3,2,0)});c.reg[3]=0xb000f130;assert(!c.step()&&c.serial_status_reads==0);}
 setup(c,{I(40,3,2,1)});c.reg[3]=0xb000f180;assert(!c.step()&&c.serial_tx_total==0);
 setup(c,{I(43,3,2,0)});c.reg[3]=0xb000f130;assert(!c.step());
 setup(c,{I(35,3,2,4)});c.reg[3]=0xb000f130;assert(!c.step());
 setup(c,{0});c.pc=0xb000f130;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch&&c.serial_status_reads==0);
 setup(c,{I(40,3,2,0)});c.reg[3]=0x400180;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x4003c3,0x400403));assert(!c.step()&&c.serial_tx_total==0);
 setup(c,{I(40,3,2,0)});c.reg[3]=0xb000f180;
 for(unsigned i=0;i<4100;i++){c.pc=0xbfc00000;c.next=c.pc+4;c.reg[2]=i==0?'A':i==1?0:i==2?'\n':i==3?'\\':'B';assert(c.step());}
 assert(c.serial_tx_size==4096&&c.serial_tx_total==4100&&c.serial_tx[0]=='A');
 const char*path="/tmp/ps2emu-serial-test.txt";assert(c.writeReport(path,"serial-test"));FILE*f=fopen(path,"rb");assert(f);std::string report;char buf[512];size_t n;while((n=fread(buf,1,sizeof(buf),f)))report.append(buf,n);fclose(f);remove(path);remove("/tmp/ps2emu-serial-test.txt.previous");
 assert(report.find("TX_omitted=4")!=std::string::npos&&report.find("A\\x00\n\\x5C")!=std::string::npos);
 setup(c,{0});assert(c.serial_tx_size==0&&c.serial_tx_total==0&&c.serial_status_reads==0);
 puts("PASS: serial BIOS status and byte transmit");}
