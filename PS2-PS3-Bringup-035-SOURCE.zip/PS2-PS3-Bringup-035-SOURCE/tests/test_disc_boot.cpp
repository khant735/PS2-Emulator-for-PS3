#include "disc_boot.h"
#include "emu_core.h"
#include "smoke_elf.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
static void write(const char*p,const char*s){FILE*f=fopen(p,"wb");assert(f);assert(fwrite(s,1,strlen(s),f)==strlen(s));assert(!fclose(f));}
int main(){char root[]="/tmp/disc-boot-XXXXXX";assert(mkdtemp(root));char cnf[1200],dir[1200],elf[1200];snprintf(cnf,sizeof(cnf),"%s/system.cnf;1",root);snprintf(dir,sizeof(dir),"%s/Folder",root);assert(!mkdir(dir,0700));snprintf(elf,sizeof(elf),"%s/Folder/boot.ELF;1",root);write(elf,"synthetic");DiscBoot b={};char error[160];
 write(cnf," BOOT2 = cdrom0:\\FOLDER\\BOOT.ELF;1\r\nVER = 1.00\r\nVMODE = NTSC\r\n");assert(read_disc_boot(root,b,error,sizeof(error)));assert(!strcmp(b.path,elf)&&!strcmp(b.version,"1.00")&&!strcmp(b.vmode,"NTSC"));
 write(cnf,"BOOT2=cdrom0:\\..\\outside.elf;1\n");assert(!read_disc_boot(root,b,error,sizeof(error)));
 write(cnf,"BOOT=cdrom:\\PSX.EXE;1\n");assert(!read_disc_boot(root,b,error,sizeof(error)));
 write(cnf,"BOOT2=cdrom0:\\missing.elf;1\n");assert(!read_disc_boot(root,b,error,sizeof(error)));
 unlink(elf);rmdir(dir);snprintf(elf,sizeof(elf),"%s/SLUS_999.99",root);write(elf,"synthetic");
 write(cnf,"BOOT2=cdrom0:\\SLUS_999.99;1\n");assert(read_disc_boot(root,b,error,sizeof(error))&&!strcmp(b.path,elf));
 unlink(cnf);assert(!read_disc_boot(root,b,error,sizeof(error)));
 // A directly selected executable remains readable without any SYSTEM.CNF.
 FILE*f=fopen(elf,"wb");assert(f);assert(fwrite(smoke_elf,1,sizeof(smoke_elf),f)==sizeof(smoke_elf));fclose(f);
 Core core;unsigned char image[sizeof(smoke_elf)];f=fopen(elf,"rb");assert(f);assert(fread(image,1,sizeof(image),f)==sizeof(image));fclose(f);assert(core.loadElf(image,sizeof(image)));
 for(int i=0;i<100&&core.stop==Core::NONE;i++)core.step();assert(core.reg[10]==12&&core.reg[11]==42&&core.stop==Core::BREAKPOINT);
 unlink(elf);rmdir(root);
 puts("PASS: mounted-disc root/subfolder BOOT2 resolution, version suffix/case, metadata and rejected paths");}
