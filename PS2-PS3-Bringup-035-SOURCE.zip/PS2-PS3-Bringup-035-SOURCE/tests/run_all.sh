#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/build/host-tests"
c++ -std=c++11 -Wall -Wextra -Wno-misleading-indentation -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_emu.cpp" "$ROOT/source/emu_core.cpp" "$ROOT/source/emu_config.cpp" -o "$ROOT/build/host-tests/test_emu"
# LeakSanitizer cannot operate in this traced host. ASan + UBSan stay enabled.
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_emu"
c++ -std=c++11 -Wall -Wextra -Wno-misleading-indentation -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_system.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_system"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_system"
python3 "$ROOT/tests/test_flip.py"
python3 "$ROOT/tests/test_graphics.py"
bash "$ROOT/tests/test_roundtrip.sh"

c++ -std=c++11 -I"$ROOT/include" "$ROOT/tests/test_report.cpp" "$ROOT/source/emu_core.cpp" "$ROOT/source/emu_config.cpp" -Wl,--wrap=rename -o "$ROOT/build/host-tests/test_report"
"$ROOT/build/host-tests/test_report"

python3 "$ROOT/tests/test_framebuffer.py"

c++ -std=c++11 -I"$ROOT/include" "$ROOT/tests/test_text_frame.cpp" -o "$ROOT/build/host-tests/test_text_frame"
"$ROOT/build/host-tests/test_text_frame"

c++ -std=c++11 -I"$ROOT/include" "$ROOT/tests/test_ui_pacing.cpp" -o "$ROOT/build/host-tests/test_ui_pacing"
"$ROOT/build/host-tests/test_ui_pacing"

c++ -std=c++11 -I"$ROOT/include" "$ROOT/tests/test_ui_stats.cpp" -o "$ROOT/build/host-tests/test_ui_stats"
"$ROOT/build/host-tests/test_ui_stats"

python3 "$ROOT/tests/test_memory_hud.py"

c++ -std=c++11 -Wall -Wextra -I"$ROOT/include" "$ROOT/tests/test_disc_boot.cpp" "$ROOT/source/disc_boot.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_disc_boot"
"$ROOT/build/host-tests/test_disc_boot"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_mmio.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_mmio"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_mmio"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_tlb.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_tlb"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_tlb"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_tlb_regressions.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_tlb_regressions"
for case_id in 1 2 3 4 5 6 7; do ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_tlb_regressions" "$case_id"; done
echo "PASS: COP0/scratch/fault review regressions"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_quad.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_quad"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_quad"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_logic128.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_logic128"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_logic128"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_cache.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_cache"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_cache"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_cop1.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_cop1"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_cop1"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_serial.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_serial"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_serial"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_intc.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_intc"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_intc"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_dve.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_dve"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_dve"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_iop_ram.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_iop_ram"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_iop_ram"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_gif.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_gif"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_gif"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_gs.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_gs"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_gs"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_iop_probe.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_iop_probe"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_iop_probe"

c++ -std=c++11 -g -fsanitize=address,undefined -I"$ROOT/include" "$ROOT/tests/test_gs_video.cpp" "$ROOT/source/emu_core.cpp" -o "$ROOT/build/host-tests/test_gs_video"
ASAN_OPTIONS=detect_leaks=0 "$ROOT/build/host-tests/test_gs_video"
