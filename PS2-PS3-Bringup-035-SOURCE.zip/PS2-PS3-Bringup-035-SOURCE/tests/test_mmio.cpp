#include "emu_core.h"
#include <assert.h>
#include <stdio.h>
#include <vector>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int imm){return op<<26|rs<<21|rt<<16|(unsigned(imm)&65535);}
static void setup(Core&c,std::initializer_list<unsigned>words){std::vector<unsigned char>rom(4*1024*1024);unsigned at=0;for(unsigned v:words)for(unsigned b=0;b<4;b++)rom[at++]=(v>>(8*b))&255;assert(c.loadBios(rom.data(),rom.size()));}
int main(){Core c;
 setup(c,{0xac620000,I(35,3,8,0)});c.reg[2]=~0ull;c.reg[3]=0xffffffffb000f500ull;
 assert(c.step());assert(c.step()&&c.reg[8]==3);assert(c.ee_f500_known&&c.ee_f500==3&&c.ee_f500_last_write==0xffffffff&&c.ee_f500_reads==1&&c.ee_f500_writes==1); // Exact BIOS SW, then masked readback.
 setup(c,{I(43,3,2,0),I(35,4,8,0),I(39,5,9,0)});c.reg[2]=2;c.reg[3]=0x1000f500;c.reg[4]=0x9000f500;c.reg[5]=0xb000f500;
 assert(c.step()&&c.step()&&c.step());assert(c.reg[8]==2&&c.reg[9]==2);
 setup(c,{I(43,3,2,0),I(43,3,0,0),I(35,3,8,0)});c.reg[2]=~0ull;c.reg[3]=0xb000f500;
 assert(c.step()&&c.step()&&c.step()&&c.reg[8]==0);
 setup(c,{I(35,3,8,0)});assert(!c.ee_f500_known&&!c.ee_f500_reads&&!c.ee_f500_writes);c.reg[3]=0xb000f500;assert(!c.step()&&c.stop==Core::MEMORY); // Unverified reset value is not invented.
 for(unsigned op:{40u,41u,63u,32u,33u,55u}){setup(c,{I(43,3,2,0),I(op,3,2,0)});c.reg[3]=0xb000f500;c.reg[2]=~0ull;assert(c.step());assert(!c.step()&&c.stop==Core::MEMORY&&c.ee_f500==3&&c.ee_f500_writes==1&&c.ee_f500_reads==0);}
 setup(c,{I(43,3,2,1)});c.reg[3]=0xb000f500;assert(!c.step()&&c.fault_address==0xb000f501);
 setup(c,{I(43,3,2,4)});c.reg[3]=0xb000f500;assert(!c.step()&&c.fault_address==0xb000f504);
 setup(c,{I(43,3,2,0)});c.reg[3]=0xb000f500;c.reg[2]=1;assert(c.step());c.pc=0xb000f500;assert(!c.step()&&c.fault_fetch);
 setup(c,{I(4,0,0,1),I(43,3,2,0),I(35,3,8,0)});c.reg[3]=0xb000f500;c.reg[2]=3;assert(c.step()&&c.step()&&c.step()&&c.reg[8]==3);
 puts("PASS: experimental F500 mask/readback, aliases, zero writes, reset guard, access widths, alignment, neighboring register and fetch rejection");}
