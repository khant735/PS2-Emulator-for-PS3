#include "emu_core.h"
#include "tlb_smoke.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <vector>
static unsigned CP(unsigned rs,unsigned rt,unsigned rd){return 16u<<26|rs<<21|rt<<16|rd<<11;}
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>rom(4*1024*1024);unsigned at=0;for(unsigned v:w)for(unsigned b=0;b<4;b++)rom[at++]=(v>>(8*b))&255;assert(c.loadBios(rom.data(),rom.size()));}
static unsigned lo(unsigned physical,unsigned flags=7){return (physical>>12)<<6|flags;}
int main(){Core c;unsigned v;
 setup(c,{0x40830000});c.reg[3]=0;assert(c.step()&&c.cp0[0]==0); // exact BIOS opcode
 setup(c,{0x42000002,0x42000001,0x42000008});c.cp0[0]=7;c.cp0[2]=lo(0x2000);c.cp0[3]=lo(0x5000);c.cp0[10]=0x400003;
 assert(c.step());c.cp0[2]=c.cp0[3]=c.cp0[10]=0;assert(c.step());assert(c.cp0[2]==lo(0x2000)&&c.cp0[3]==lo(0x5000)&&c.cp0[10]==0x400003);assert(c.step()&&c.cp0[0]==7);
 c.cp0[12]=0;assert(c.write32(0x80002000,0x12345678));assert(c.read32(0x400000,v)&&v==0x12345678);assert(c.write32(0x401000,0xabcdef01));assert(c.read32(0x80005000,v)&&v==0xabcdef01);
 // ASID mismatch versus global (both G bits required).
 setup(c,{0x42000002});c.cp0[2]=lo(0x2000,6);c.cp0[3]=lo(0x5000,6);c.cp0[10]=0x400003;assert(c.step());c.cp0[12]=0;c.cp0[10]=4;assert(!c.read32(0x400000,v));c.cp0[10]=3;assert(c.read32(0x400000,v));
 setup(c,{0x42000002,I(43,4,5,0)});c.cp0[2]=lo(0x2000,3);c.cp0[3]=lo(0x5000);c.cp0[10]=0x400000;assert(c.step());c.cp0[12]=0;c.reg[4]=0x400000;c.reg[5]=9;assert(!c.step()&&strstr(c.error,"dirty"));assert(c.read32(0x80002000,v)&&v==0);
 setup(c,{0x42000002,I(35,4,5,0)});c.cp0[2]=lo(0x2000,5);c.cp0[3]=lo(0x5000);c.cp0[10]=0x400000;assert(c.step());c.cp0[12]=0;c.reg[4]=0x400000;assert(!c.step()&&strstr(c.error,"invalid"));
 // All legal page masks: low physical page bits must be ignored for alignment.
 for(unsigned mask:{0u,0x6000u,0x1e000u,0x7e000u,0x1fe000u,0x7fe000u,0x1ffe000u}){
  setup(c,{0x42000002});c.cp0[5]=mask;c.cp0[10]=0x40000000;unsigned page=(mask+0x2000)/2;c.cp0[2]=lo(page>4096?4096:0);c.cp0[3]=lo(page+(page>4096?4096:0));assert(c.step());c.cp0[12]=0;assert(c.write32(0x80000004,0x55));assert(c.read32(0x40000004,v)&&v==0x55);assert(c.write32(0x40000000+page+4,0x66));assert(c.read32(0x80000000+page+4,v)&&v==0x66);
 }
 setup(c,{0x42000002});c.cp0[0]=48;assert(!c.step());
 setup(c,{0x42000002});c.cp0[5]=0x2000;assert(!c.step());
 setup(c,{0x42000008});c.cp0[10]=0x400000;assert(c.step()&&c.cp0[0]==0x80000000);
 // TLBWR respects Wired; read-only Random cannot be overwritten by MTC0.
 setup(c,{CP(4,8,6),0x42000006});c.reg[8]=46;assert(c.step()&&c.cp0[6]==46&&c.cp0[1]>=46&&c.cp0[1]<48);c.cp0[2]=c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());
 setup(c,{CP(4,8,1)});assert(!c.step());
 // Scratchpad mapping is a 16K window with permissions from EntryLo0.
 setup(c,{0x42000002});c.cp0[10]=0x70000000;c.cp0[2]=0x80000007;c.cp0[3]=7;assert(c.step());c.cp0[12]=0;assert(c.write32(0x70003ffc,0x9988));assert(c.read32(0x70003ffc,v)&&v==0x9988);assert(!c.read32(0x70004000,v));
 // A G bit in only one half does not make the pair global.
 setup(c,{0x42000002});c.cp0[10]=0x400003;c.cp0[2]=lo(0x2000,7);c.cp0[3]=lo(0x5000,6);assert(c.step());c.cp0[12]=0;c.cp0[10]=4;assert(!c.read32(0x400000,v));
 // Scratch probing covers the whole 16K window; TLBR reports uncached C=2.
 setup(c,{0x42000002,0x42000008,0x42000001});c.cp0[10]=0x40000000;c.cp0[2]=0x80000007;c.cp0[3]=7;assert(c.step());c.cp0[10]=0x40002000;assert(c.step()&&c.cp0[0]==0);assert(c.step()&&((c.cp0[2]>>3)&7)==2&&((c.cp0[3]>>3)&7)==2);
 // Duplicate matching entries stop; replacement removes the previous mapping.
 setup(c,{0x42000002,0x42000002,0x42000008});c.cp0[2]=c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());c.cp0[0]=1;assert(c.step());assert(!c.step());
 setup(c,{0x42000002,0x42000002});c.cp0[2]=c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());c.cp0[10]=0x600000;assert(c.step());c.cp0[12]=0;assert(!c.read32(0x400000,v)&&c.read32(0x600000,v));
 // Fetch instructions through a mapped page, and route mapped MMIO data writes.
 setup(c,{0x42000002});c.cp0[2]=lo(0x2000);c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());assert(c.write32(0x80002000,I(9,0,8,42)));c.cp0[12]=0;c.pc=0x400000;c.next=0x400004;assert(c.step()&&c.reg[8]==42);
 setup(c,{0x42000002,I(43,4,5,0)});c.cp0[2]=lo(0x1000f000);c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());c.cp0[12]=0;c.reg[4]=0x400500;c.reg[5]=~0ull;assert(c.step()&&c.ee_f500==3&&c.ee_f500_writes==1);
 setup(c,{0x42000002,I(43,4,5,0)});c.cp0[2]=lo(0x1000f000,3);c.cp0[3]=7;c.cp0[10]=0x400000;assert(c.step());c.cp0[12]=0;c.reg[4]=0x400500;c.reg[5]=~0ull;assert(!c.step()&&c.ee_f500_writes==0);
 // Reset removes all installed mappings.
 setup(c,{0});c.cp0[12]=0;assert(!c.read32(0x400000,v));c.cp0[12]=4;assert(c.read32(0x1000,v));c.cp0[12]=16;assert(!c.read32(0x80000000,v));
 std::vector<unsigned char>built_in(4*1024*1024);for(unsigned i=0;i<sizeof(tlb_smoke_words)/sizeof(tlb_smoke_words[0]);i++)for(unsigned j=0;j<4;j++)built_in[4*i+j]=(tlb_smoke_words[i]>>(8*j))&255;assert(c.loadBios(built_in.data(),built_in.size()));for(int i=0;i<100&&c.stop==Core::NONE;i++)c.step();assert(c.stop==Core::BREAKPOINT&&c.reg[14]==42&&c.reg[15]==45&&c.reg[9]==0&&c.reg[11]==0x87);
 puts("PASS: CP0 TLB setup/ops, even/odd/large pages, ASID/global, permissions, scratchpad, random/wired, bounds and reset");}
