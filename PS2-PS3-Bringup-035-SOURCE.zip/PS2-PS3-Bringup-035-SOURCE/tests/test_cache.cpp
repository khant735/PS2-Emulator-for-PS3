#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;unsigned v;
 // Exact BIOS DXIN and both ways: no memory translation or data modification.
 for(unsigned way=0;way<2;way++){
  setup(c,{0xbf560000|way,0x2402002a});c.reg[26]=0;c.reg[22]=123;c.reg_hi[22]=456;c.cp0[28]=0x12345678;
  assert(c.write32(0x80001000,0xdeadbeef));assert(c.step());assert(c.pc==0xbfc00004&&c.instructions==1&&c.reg[22]==123&&c.reg_hi[22]==456&&c.cp0[28]==0x12345678);assert(c.read32(0x80001000,v)&&v==0xdeadbeef);assert(c.step()&&c.reg[2]==42);
 }
 setup(c,{0xbf56ffff});c.reg[26]=0xb000f501;assert(c.step()&&c.ee_f500_reads==0&&c.ee_f500_writes==0);
 setup(c,{0x10000002,0xbf560000,0x24020001,0x24020002});assert(c.step()&&c.step()&&c.step());assert(c.reg[2]==2);
 setup(c,{0});assert(c.write32(0x80001000,0xbf560000));assert(c.tlb.put(0,0,0x400000,0x47,0x87));c.pc=0x400000;c.next=0x400004;c.cp0[12]=0x10;assert(!c.step()&&c.instructions==0);
 // Exact BIOS IXIN, index zero need not be a mapped memory address.
 setup(c,{0xbf470000,0x2402002a});c.reg[26]=0;c.reg[7]=123;c.reg_hi[7]=456;assert(c.write32(0x80001000,0xdeadbeef));assert(c.step());assert(c.pc==0xbfc00004&&c.instructions==1&&c.reg[7]==123&&c.reg_hi[7]==456);assert(c.read32(0x80001000,v)&&v==0xdeadbeef);assert(c.step()&&c.reg[2]==42);
 // Unaligned indices and signed offsets must not become data accesses.
 setup(c,{0xbf47ffff});c.reg[26]=0xb000f501;assert(c.step()&&c.ee_f500_reads==0&&c.ee_f500_writes==0);
 setup(c,{0x10000002,0xbf470000,0x24020001,0x24020002});assert(c.step()&&c.step()&&c.step());assert(c.reg[2]==2);
 // Unsupported cache modes and non-kernel execution stop rather than silently pass.
 setup(c,{0xbf460000});assert(!c.step()&&c.stop==Core::UNSUPPORTED&&c.instructions==0);
 setup(c,{0xbf470000});assert(c.write32(0x80001000,0xbf470000));assert(c.tlb.put(0,0,0x400000,0x47,0x87));c.pc=0x400000;c.next=0x400004;c.cp0[12]=0x10;assert(!c.step()&&c.instructions==0);
 puts("PASS: CACHE IXIN/DXIN BIOS opcode, indices, state preservation, no MMIO, delay slot, mode and privilege guards");
}
