#!/usr/bin/env python3
# Original redistributable MIPS instruction test. It has no Sony code.
from pathlib import Path
import struct
root=Path(__file__).resolve().parents[1]
b=bytearray(0x120)
b[:7]=b'\x7fELF\x01\x01\x01'
struct.pack_into('<HHIIIIIHHHHHH',b,16,2,8,1,0x100000,52,0,0,52,32,1,0,0,0)
struct.pack_into('<IIIIIIII',b,52,1,0x100,0x100000,0x100000,32,64,5,16)
words=[0x24080005,0x24090007,0x01095021,0x114a0002,0x240b002a,0x240b0063,0x0000000d,0]
struct.pack_into('<8I',b,0x100,*words)
(root/'pkgfiles/USRDIR/SMOKE.ELF').write_bytes(b)
(root/'include/smoke_elf.h').write_text('static const unsigned char smoke_elf[] = {\n'+','.join(str(v) for v in b)+'\n};\n')
# Extended system test; false BEQL annuls the R11=99 delay instruction.
def reg(rs,rt,rd,sh,fn): return rs<<21|rt<<16|rd<<11|sh<<6|fn
def imm(op,rs,rt,value): return op<<26|rs<<21|rt<<16|(value&65535)
def cop(rs,rt,rd): return 16<<26|rs<<21|rt<<16|rd<<11
system_words=[imm(13,0,8,7),imm(13,0,9,3),reg(8,9,10,0,24),reg(0,0,11,0,18),
 cop(0,12,15),imm(13,0,13,0x1234),cop(4,13,14),cop(0,14,14),reg(0,8,15,0,60),
 imm(13,0,16,0x1000),imm(63,16,15,0),imm(55,16,17,0),imm(20,8,9,1),imm(9,0,11,99),13]
sysb=bytearray(0x100+len(system_words)*4)
sysb[:52]=b[:52]
struct.pack_into('<IIIIIIII',sysb,52,1,0x100,0x100000,0x100000,len(system_words)*4,len(system_words)*4,5,16)
struct.pack_into('<'+'I'*len(system_words),sysb,0x100,*system_words)
(root/'pkgfiles/USRDIR/SYSTEM.ELF').write_bytes(sysb)
(root/'include/system_elf.h').write_text('static const unsigned char system_elf[] = {\n'+','.join(str(v) for v in sysb)+'\n};\n')
