#include "emu_config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
static const char* keys[]={"bios","elf","iso","mc1","mc2","hdd","host"};
Settings::Settings():batch(1000){bios[0]=elf[0]=iso[0]=mc1[0]=mc2[0]=hdd[0]=host[0]=0;save_error[0]=0;}
char* Settings::path(unsigned i){switch(i){case 0:return bios;case 1:return elf;case 2:return iso;case 3:return mc1;case 4:return mc2;case 5:return hdd;case 6:return host;default:return NULL;}}
const char* Settings::path(unsigned i)const{return const_cast<Settings*>(this)->path(i);}
static bool validPath(const char*p){size_t n=strlen(p);if(n>=1024||(n&&p[0]!='/'))return false;for(size_t i=0;i<n;i++)if((unsigned char)p[i]<32)return false;return true;}
bool Settings::load(const char*name){
 FILE*f=fopen(name,"rb");if(!f)return false;Settings tmp;char line[1152];bool ok=true;
 while(fgets(line,sizeof(line),f)){
  size_t n=strlen(line);if(!n||line[n-1]!='\n'){if(!feof(f)){ok=false;break;}}while(n&&(line[n-1]=='\n'||line[n-1]=='\r'))line[--n]=0;
  if(!n||line[0]=='#')continue;char*eq=strchr(line,'=');if(!eq){ok=false;break;}*eq++=0;
  if(!strcmp(line,"batch")){char*end=NULL;errno=0;unsigned long v=strtoul(eq,&end,10);if(errno||*end||end==eq||(v!=1&&v!=100&&v!=1000&&v!=10000)){ok=false;break;}tmp.batch=(unsigned)v;}
  else for(unsigned i=0;i<7;i++)if(!strcmp(line,keys[i])){if(!validPath(eq)){ok=false;break;}strcpy(tmp.path(i),eq);}
  if(!ok)break;
 }
 if(ferror(f))ok=false;if(fclose(f))ok=false;if(ok)*this=tmp;return ok;
}
bool Settings::save(const char*name)const{
 save_error[0]=0;
 auto failed=[this](const char*stage,int code){snprintf(save_error,sizeof(save_error),"Config %s failed: errno %d (%s)",stage,code,strerror(code));return false;};
 if(!name)return failed("path",EINVAL);
 if(batch!=1&&batch!=100&&batch!=1000&&batch!=10000)return failed("batch validation",EINVAL);
 for(unsigned i=0;i<7;i++)if(!validPath(path(i)))return failed("path validation",EINVAL);
 char temp[1152],backup[1152];int n=snprintf(temp,sizeof(temp),"%s.tmp",name);
 int m=snprintf(backup,sizeof(backup),"%s.previous",name);
 if(n<0||n>=(int)sizeof(temp)||m<0||m>=(int)sizeof(backup))return failed("path length",ENAMETOOLONG);
 FILE*f=fopen(temp,"wb");if(!f)return failed("open",errno);
 fprintf(f,"# PS2 PS3 bring-up 033; device paths do not enable emulation\nversion=1\nbatch=%u\n",batch);
 for(unsigned i=0;i<7;i++)fprintf(f,"%s=%s\n",keys[i],path(i));
 int saved=ferror(f)?(errno?errno:EIO):0;const char*stage="write";
 if(fflush(f)&&!saved){saved=errno?errno:EIO;stage="flush";}
 if(fclose(f)&&!saved){saved=errno?errno:EIO;stage="close";}
 if(saved){remove(temp);return failed(stage,saved);}
 if(rename(temp,name)==0)return true;
 saved=errno;
 if(saved!=EEXIST&&saved!=ENOTEMPTY){remove(temp);return failed("rename",saved);}
 // Some host filesystems refuse replacement. Keep the previous config until
 // the completed temporary file is installed; never unlink the only copy.
 struct stat st;
 if(stat(name,&st)||!S_ISREG(st.st_mode)){remove(temp);return failed("destination",EINVAL);}
 if(stat(backup,&st)==0){remove(temp);return failed("backup exists",EEXIST);}
 if(errno!=ENOENT){saved=errno;remove(temp);return failed("backup check",saved);}
 if(rename(name,backup)){saved=errno;remove(temp);return failed("backup rename",saved);}
 if(rename(temp,name)){
  saved=errno;
  if(rename(backup,name)){remove(temp);return failed("restore; old config in .previous",errno);}
  remove(temp);return failed("install; old config restored",saved);
 }
 remove(backup);return true;
}
