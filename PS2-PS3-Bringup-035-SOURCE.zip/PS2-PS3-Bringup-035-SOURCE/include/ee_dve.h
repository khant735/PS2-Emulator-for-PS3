#ifndef EE_DVE_H
#define EE_DVE_H
#include <stdint.h>
#include <string.h>
// Experimental control-bus subset; no encoder output or cycle timing.
struct EeDve {
 uint16_t bus[10],device[256];bool known[256],active,error,selected;
 unsigned current,phase;uint64_t reads,writes,commands,compat_mode42_unselected;
 void reset(){memset(bus,0,sizeof(bus));memset(device,0,sizeof(device));memset(known,0,sizeof(known));active=error=selected=false;current=phase=0;reads=writes=commands=compat_mode42_unselected=0;}
 static bool valid(unsigned off){return off==0||off==2||off==4||off==6||off==8||off==10||off==16||off==18;}
 bool read(unsigned off,uint64_t&v){
  if(!valid(off))return false;
  if(off==6){v=(phase&2)|(error?1:0);if(active){if(phase<3)phase++;else active=false;}}
  else v=bus[off/2];
  reads++;return true;
 }
 bool write(unsigned off,uint16_t v){
  if(!valid(off))return false;
  if(off==0){
   unsigned mode=bus[1];
   if(mode==0x41||mode==0x4f){error=true;}
   else if(v&0x80){
    // Only a register selector plus one data value, or one-value read.
    if(mode==0x43){if((v&15)!=2||bus[8]>255)return false;current=bus[8];selected=true;device[current]=bus[9];known[current]=true;}
    else if(mode==0x42){if((v&15)!=1)return false; if(!selected||!known[current]){
     // Build 035 diagnostic compatibility: BIOS sends mode 0x42 / command 0x81
     // before a known selector. Acknowledge, but do not fabricate device data.
     compat_mode42_unselected++;
    }else bus[8]=device[current];}
    else return false;
    active=true;phase=0;error=false;commands++;
   }
  }
  if(off==6)phase=0;
  else bus[off/2]=v;
  if(off==10)error=v==0;
  writes++;return true;
 }
};
#endif
