#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;setup(c,{0xfc440000});c.reg[2]=0x12000010;c.reg[4]=0x0000000740814504ull;assert(c.step());assert(c.gs_video[1]==0x740814504ull&&c.gs_video_writes==1);
 for(unsigned i=0;i<15;i++){setup(c,{0xfc440000});c.reg[2]=0xb2000000+i*16;c.reg[4]=0x1234567889abcdefull;assert(c.step()&&c.gs_video[i]==c.reg[4]&&c.gs_video_writes==1);}
 setup(c,{I(43,2,4,0),I(43,2,5,4)});c.reg[2]=0x92000010;c.reg[4]=0x89abcdef;c.reg[5]=0x76543210;assert(c.step()&&c.step()&&c.gs_video[1]==0x7654321089abcdefull);
 setup(c,{I(63,2,4,0),I(63,3,5,0)});c.reg[2]=0xb2000010;c.reg[3]=0xb2001000;c.reg[4]=0x740814504ull;c.reg[5]=0x200;assert(c.step()&&c.step()&&c.gs_video[1]==0&&c.gs_resets==1);
 for(unsigned op:{40u,41u,35u,55u}){setup(c,{I(op,2,4,0)});c.reg[2]=0xb2000010;assert(!c.step()&&c.gs_video_writes==0);}
 for(unsigned off:{8u,12u,0xf0u,1u}){setup(c,{I(43,2,4,off)});c.reg[2]=0xb2000000;assert(!c.step()&&c.gs_video_writes==0);}
 setup(c,{0});c.pc=0xb2000010;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);
 setup(c,{0xfc440000});c.reg[2]=0x400000;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x480003,0x480043));assert(!c.step()&&c.gs_video_writes==0);
 setup(c,{0x10000002,0xfc440000,0x24050001,0});c.reg[2]=0xb2000010;c.reg[4]=0x740814504ull;assert(c.step()&&c.step()&&c.step()&&c.gs_video[1]==c.reg[4]);
 setup(c,{0});assert(c.gs_video_writes==0);for(unsigned i=0;i<15;i++)assert(c.gs_video[i]==0);
 puts("PASS: BIOS GS SMODE1 configuration write");}
