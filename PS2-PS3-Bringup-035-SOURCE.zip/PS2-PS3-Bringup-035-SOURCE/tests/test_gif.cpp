#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;
 setup(c,{0xac440000,I(35,2,5,32)});c.reg[2]=0x10003000;c.reg[4]=1;assert(c.step()&&c.step()&&c.reg[5]==0);
 setup(c,{I(43,2,4,16),I(43,2,6,0),I(35,2,5,32),I(43,2,7,0),I(35,2,8,32)});c.reg[2]=0xb0003000;c.reg[4]=~0ull;c.reg[6]=8;c.reg[7]=1;assert(c.step()&&c.step()&&c.step()&&c.reg[5]==13);assert(c.step()&&c.step()&&c.reg[8]==0);

 for(unsigned a:{0x10003000u,0x90003000u,0xb0003000u}){setup(c,{0xac440000,I(35,2,5,32)});c.reg[2]=a;c.reg[4]=9;c.gif_mode=5;c.gif_pause=8;assert(c.step()&&c.step()&&c.reg[5]==0&&c.gif_resets==1);}
 setup(c,{I(43,2,4,0),I(35,2,5,32)});c.reg[2]=0xb0003000;c.reg[4]=0xfffffff6;assert(c.step()&&c.step()&&c.reg[5]==0&&c.gif_resets==0);
 for(unsigned op:{32u,33u,55u,40u,41u,63u}){setup(c,{I(op,2,4,0)});c.reg[2]=0xb0003000;c.reg[4]=1;assert(!c.step()&&c.gif_resets==0);}
 for(unsigned off:{0u,16u,4u,0x6000u-0x3000u}){setup(c,{I(35,2,4,off)});c.reg[2]=0xb0003000;assert(!c.step());}
 setup(c,{I(43,2,4,32)});c.reg[2]=0xb0003000;assert(!c.step());
 setup(c,{I(43,2,4,1)});c.reg[2]=0xb0003000;c.reg[4]=1;assert(!c.step()&&c.gif_resets==0);
 setup(c,{0});c.pc=0xb0003020;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);
 setup(c,{I(43,2,4,0)});c.reg[2]=0x400000;c.reg[4]=1;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x4000c3,0x400103));assert(!c.step()&&c.gif_resets==0);
 setup(c,{0x10000002,0xac440000,0x24050001,I(35,2,5,32)});c.reg[2]=0xb0003000;c.reg[4]=1;assert(c.step()&&c.step()&&c.step()&&c.reg[5]==0&&c.gif_resets==1);
 setup(c,{0});assert(c.gif_mode==0&&c.gif_pause==0&&c.gif_resets==0);
 setup(c,{0x3c021000,0x34423000,0x24040001,0xac440000,0x8c450020,0x0000000d});for(unsigned i=0;i<5;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT&&c.reg[5]==0&&c.gif_resets==1);
 puts("PASS: GIF reset/control/mode and idle status");}
