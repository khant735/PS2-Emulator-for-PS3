#include "psu.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <time.h>

#ifndef _WIN32
#include <dirent.h>
#include <unistd.h>
#else
#include <direct.h>
#endif

#define PSU_EINVAL -1
#define PSU_EIO     -2
#define PSU_ENOMEM  -3
#define PSU_EFORMAT -4
#define PSU_ENOENT  -5
#define PSU_EEXIST  -6

static uint16_t rd16le(const uint8_t *p){ return (uint16_t)(p[0] | ((uint16_t)p[1] << 8)); }
static uint32_t rd32le(const uint8_t *p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
static uint64_t rd64le(const uint8_t *p){ uint64_t v=0; for(int i=7;i>=0;--i) v=(v<<8)|p[i]; return v; }
static void wr16le(uint8_t *p,uint16_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); }
static void wr32le(uint8_t *p,uint32_t v){ p[0]=(uint8_t)v; p[1]=(uint8_t)(v>>8); p[2]=(uint8_t)(v>>16); p[3]=(uint8_t)(v>>24); }
static void wr64le(uint8_t *p,uint64_t v){ for(int i=0;i<8;i++){ p[i]=(uint8_t)(v&0xff); v>>=8; } }

static int is_file_attr(uint16_t a){ return a == PSU_ATTR_FILE || ((a & 0x8000u) && (a & 0x0010u)); }
static int is_dir_attr(uint16_t a){ return a == PSU_ATTR_DIR || ((a & 0x8000u) && (a & 0x0020u)); }
static uint32_t pad_for(uint32_t n){ uint32_t r=n & (PSU_DATA_ALIGN-1); return r ? PSU_DATA_ALIGN-r : 0; }

static void unpack_time(psu_time_t *t,const uint8_t *p){
    t->unused=p[0]; t->sec=p[1]; t->min=p[2]; t->hour=p[3]; t->day=p[4]; t->month=p[5]; t->year=rd16le(p+6);
}
static void pack_time(uint8_t *p,const psu_time_t *t){
    p[0]=t->unused; p[1]=t->sec; p[2]=t->min; p[3]=t->hour; p[4]=t->day; p[5]=t->month; wr16le(p+6,t->year);
}
static void time_from_time_t(psu_time_t *out,time_t when){
    struct tm *tmv=localtime(&when); memset(out,0,sizeof(*out)); if(!tmv) return;
    out->sec=(uint8_t)tmv->tm_sec; out->min=(uint8_t)tmv->tm_min; out->hour=(uint8_t)tmv->tm_hour;
    out->day=(uint8_t)tmv->tm_mday; out->month=(uint8_t)(tmv->tm_mon+1); out->year=(uint16_t)(tmv->tm_year+1900);
}

static void unpack_header(psu_entry_t *e,const uint8_t h[PSU_HEADER_SIZE]){
    memset(e,0,sizeof(*e)); e->attr=rd16le(h+0x00); e->size=rd32le(h+0x04);
    unpack_time(&e->ctime,h+0x08); unpack_time(&e->mtime,h+0x18); e->unknown2=rd64le(h+0x20);
    memcpy(e->name,h+0x40,PSU_NAME_MAX); e->name[PSU_NAME_MAX]=0;
}
static void pack_header(uint8_t h[PSU_HEADER_SIZE],const psu_entry_t *e){
    memset(h,0,PSU_HEADER_SIZE); wr16le(h+0x00,e->attr); wr32le(h+0x04,e->size);
    pack_time(h+0x08,&e->ctime); pack_time(h+0x18,&e->mtime); wr64le(h+0x20,e->unknown2);
    size_t n=strlen(e->name); if(n>PSU_NAME_MAX) n=PSU_NAME_MAX; memcpy(h+0x40,e->name,n);
}
static int read_header(FILE *f,psu_entry_t *e){ uint8_t h[PSU_HEADER_SIZE]; if(fread(h,1,sizeof(h),f)!=sizeof(h)) return PSU_EIO; unpack_header(e,h); return 0; }
static int write_header(FILE *f,const psu_entry_t *e){ uint8_t h[PSU_HEADER_SIZE]; pack_header(h,e); return fwrite(h,1,sizeof(h),f)==sizeof(h)?0:PSU_EIO; }
static int skip_data(FILE *f,uint32_t size){ long long n=(long long)size+pad_for(size); return fseek(f,(long)n,SEEK_CUR)==0?0:PSU_EIO; }

const char *psu_strerror(int c){
    switch(c){case 0:return "ok";case PSU_EINVAL:return "invalid argument";case PSU_EIO:return "I/O error";case PSU_ENOMEM:return "out of memory";case PSU_EFORMAT:return "invalid/unsupported PSU";case PSU_ENOENT:return "entry not found";case PSU_EEXIST:return "entry already exists";default:return "unknown PSU error";}
}

int psu_list(const char *path,psu_list_cb cb,void *opaque){
    if(!path) return PSU_EINVAL; FILE *f=fopen(path,"rb"); if(!f) return PSU_EIO;
    psu_entry_t root; int rc=read_header(f,&root); if(rc){fclose(f);return rc;}
    if(!is_dir_attr(root.attr) || root.size<2 || root.size>10000){ fclose(f); return PSU_EFORMAT; }
    for(uint32_t i=0;i<root.size;i++){
        psu_entry_t e; if(read_header(f,&e)){fclose(f);return PSU_EFORMAT;}
        if(cb && cb(&e,i,opaque)){ fclose(f); return 0; }
        if(is_file_attr(e.attr) && e.size){ rc=skip_data(f,e.size); if(rc){fclose(f);return rc;} }
    }
    fclose(f); return 0;
}

static int safe_name(const char *s){
    if(!s || !*s || !strcmp(s,".") || !strcmp(s,"..")) return 0;
    for(;*s;s++) if(*s=='/'||*s=='\\'||*s==':'||((unsigned char)*s<32)) return 0;
    return 1;
}
static int mkdir_one(const char *p){
#ifdef _WIN32
    if(_mkdir(p)==0 || errno==EEXIST) return 0;
#else
    if(mkdir(p,0777)==0 || errno==EEXIST) return 0;
#endif
    return PSU_EIO;
}
static int copy_n(FILE *in,FILE *out,uint32_t n){
    uint8_t b[64*1024]; while(n){ size_t chunk=n<sizeof(b)?n:sizeof(b); if(fread(b,1,chunk,in)!=chunk) return PSU_EIO; if(fwrite(b,1,chunk,out)!=chunk) return PSU_EIO; n-=(uint32_t)chunk; } return 0;
}

int psu_extract_all(const char *path,const char *dest){
    if(!path||!dest) return PSU_EINVAL; if(mkdir_one(dest)) return PSU_EIO;
    FILE *f=fopen(path,"rb"); if(!f) return PSU_EIO; psu_entry_t root; if(read_header(f,&root)||!is_dir_attr(root.attr)){fclose(f);return PSU_EFORMAT;}
    for(uint32_t i=0;i<root.size;i++){
        psu_entry_t e; if(read_header(f,&e)){fclose(f);return PSU_EFORMAT;}
        if(is_file_attr(e.attr) && safe_name(e.name)){
            char outp[1024]; snprintf(outp,sizeof(outp),"%s/%s",dest,e.name); FILE *o=fopen(outp,"wb"); if(!o){fclose(f);return PSU_EIO;}
            int rc=copy_n(f,o,e.size); fclose(o); if(rc){fclose(f);return rc;} if(fseek(f,(long)pad_for(e.size),SEEK_CUR)){fclose(f);return PSU_EIO;}
        } else if(is_file_attr(e.attr)) { if(skip_data(f,e.size)){fclose(f);return PSU_EIO;} }
    }
    fclose(f); return 0;
}

int psu_extract_one(const char *path,const char *name,const char *dest){
    if(!path||!name||!dest) return PSU_EINVAL; FILE *f=fopen(path,"rb"); if(!f) return PSU_EIO; psu_entry_t root; if(read_header(f,&root)||!is_dir_attr(root.attr)){fclose(f);return PSU_EFORMAT;}
    for(uint32_t i=0;i<root.size;i++){
        psu_entry_t e; if(read_header(f,&e)){fclose(f);return PSU_EFORMAT;}
        if(is_file_attr(e.attr) && !strncmp(e.name,name,PSU_NAME_MAX)){
            FILE *o=fopen(dest,"wb"); if(!o){fclose(f);return PSU_EIO;} int rc=copy_n(f,o,e.size); fclose(o); fclose(f); return rc;
        }
        if(is_file_attr(e.attr) && skip_data(f,e.size)){fclose(f);return PSU_EIO;}
    }
    fclose(f); return PSU_ENOENT;
}

int psu_read_file(const char *path,const char *name,void **data_out,size_t *size_out){
    if(data_out) *data_out=NULL; if(size_out) *size_out=0;
    if(!path||!name||!data_out||!size_out) return PSU_EINVAL;
    FILE *f=fopen(path,"rb"); if(!f) return PSU_EIO; psu_entry_t root; if(read_header(f,&root)||!is_dir_attr(root.attr)){fclose(f);return PSU_EFORMAT;}
    for(uint32_t i=0;i<root.size;i++){
        psu_entry_t e; if(read_header(f,&e)){fclose(f);return PSU_EFORMAT;}
        if(is_file_attr(e.attr) && !strncmp(e.name,name,PSU_NAME_MAX)){
            uint8_t *buf=(uint8_t*)malloc(e.size?e.size:1); if(!buf){fclose(f);return PSU_ENOMEM;}
            if(e.size && fread(buf,1,e.size,f)!=e.size){free(buf);fclose(f);return PSU_EIO;}
            *data_out=buf; *size_out=e.size; fclose(f); return 0;
        }
        if(is_file_attr(e.attr) && skip_data(f,e.size)){fclose(f);return PSU_EIO;}
    }
    fclose(f); return PSU_ENOENT;
}


typedef struct { char name[PSU_NAME_MAX+1]; char path[1024]; uint32_t size; psu_time_t ct,mt; } host_file_t;
static int cmp_hf(const void *a,const void *b){return strcmp(((const host_file_t*)a)->name,((const host_file_t*)b)->name);}

static int scan_dir(const char *dir,host_file_t **out,size_t *count){
#ifndef _WIN32
    DIR *d=opendir(dir); if(!d) return PSU_EIO; size_t cap=16,n=0; host_file_t *v=(host_file_t*)calloc(cap,sizeof(*v)); if(!v){closedir(d);return PSU_ENOMEM;}
    struct dirent *de; while((de=readdir(d))){ if(!strcmp(de->d_name,".")||!strcmp(de->d_name,".."))continue; if(strlen(de->d_name)>PSU_NAME_MAX) continue;
        char p[1024]; snprintf(p,sizeof(p),"%s/%s",dir,de->d_name); struct stat st; if(stat(p,&st)||!S_ISREG(st.st_mode))continue;
        if(n==cap){cap*=2; host_file_t *nv=(host_file_t*)realloc(v,cap*sizeof(*v)); if(!nv){free(v);closedir(d);return PSU_ENOMEM;}v=nv;}
        strncpy(v[n].name,de->d_name,PSU_NAME_MAX); strncpy(v[n].path,p,sizeof(v[n].path)-1); v[n].size=(uint32_t)st.st_size; time_from_time_t(&v[n].ct,st.st_ctime); time_from_time_t(&v[n].mt,st.st_mtime); n++; }
    closedir(d); qsort(v,n,sizeof(*v),cmp_hf); *out=v;*count=n;return 0;
#else
    (void)dir;(void)out;(void)count; return PSU_EINVAL;
#endif
}

static int write_zeros(FILE *f,uint32_t n){ uint8_t z[1024]={0}; while(n){uint32_t c=n>sizeof(z)?sizeof(z):n;if(fwrite(z,1,c,f)!=c)return PSU_EIO;n-=c;}return 0; }
static int copy_file_to_psu(FILE *out,const host_file_t *hf){
    psu_entry_t e; memset(&e,0,sizeof(e));e.attr=PSU_ATTR_FILE;e.size=hf->size;e.ctime=hf->ct;e.mtime=hf->mt;strncpy(e.name,hf->name,PSU_NAME_MAX);
    int rc=write_header(out,&e); if(rc)return rc; FILE *in=fopen(hf->path,"rb"); if(!in)return PSU_EIO; rc=copy_n(in,out,e.size); fclose(in); if(rc)return rc; return write_zeros(out,pad_for(e.size));
}

int psu_create_from_dir(const char *src,const char *outp,const char *save_name){
    if(!src||!outp) return PSU_EINVAL; host_file_t *files=NULL; size_t n=0; int rc=scan_dir(src,&files,&n); if(rc)return rc;
    const char *nm=(save_name&&*save_name)?save_name:"SAVE";
    FILE *o=fopen(outp,"wb"); if(!o){free(files);return PSU_EIO;} time_t now=time(NULL); psu_entry_t e; memset(&e,0,sizeof(e));
    e.attr=PSU_ATTR_DIR;e.size=(uint32_t)(n+2);time_from_time_t(&e.ctime,now);e.mtime=e.ctime;strncpy(e.name,nm,PSU_NAME_MAX);e.name[PSU_NAME_MAX]=0; if((rc=write_header(o,&e)))goto done;
    e.attr=PSU_ATTR_DIR;e.size=0;strcpy(e.name,"."); if((rc=write_header(o,&e)))goto done; strcpy(e.name,".."); if((rc=write_header(o,&e)))goto done;
    for(size_t i=0;i<n;i++) if((rc=copy_file_to_psu(o,&files[i])))goto done;
done: fclose(o);free(files); if(rc) remove(outp);return rc;
}

int psu_create_blank(const char *outp,const char *save_name){
    if(!outp) return PSU_EINVAL;
    const char *nm=(save_name&&*save_name)?save_name:"BLANK";
    if(strlen(nm)>PSU_NAME_MAX) return PSU_EINVAL;
    FILE *o=fopen(outp,"wb"); if(!o) return PSU_EIO;
    time_t now=time(NULL); psu_entry_t e; int rc=0; memset(&e,0,sizeof(e));
    e.attr=PSU_ATTR_DIR; e.size=2; time_from_time_t(&e.ctime,now); e.mtime=e.ctime; strncpy(e.name,nm,PSU_NAME_MAX);
    if((rc=write_header(o,&e))) goto done_blank;
    memset(&e,0,sizeof(e)); e.attr=PSU_ATTR_DIR; strcpy(e.name,".");
    if((rc=write_header(o,&e))) goto done_blank;
    strcpy(e.name,".."); rc=write_header(o,&e);
done_blank:
    if(fclose(o)!=0 && !rc) rc=PSU_EIO;
    if(rc) remove(outp);
    return rc;
}

typedef struct { psu_entry_t e; uint8_t *data; } mem_entry_t;
static void free_entries(mem_entry_t *v,size_t n){if(!v)return;for(size_t i=0;i<n;i++)free(v[i].data);free(v);}
static int load_psu(const char *path,psu_entry_t *root,mem_entry_t **out,size_t *n){
    FILE *f=fopen(path,"rb");if(!f)return PSU_EIO;if(read_header(f,root)||!is_dir_attr(root->attr)||root->size>10000){fclose(f);return PSU_EFORMAT;}
    mem_entry_t *v=(mem_entry_t*)calloc(root->size,sizeof(*v));if(!v){fclose(f);return PSU_ENOMEM;}
    for(uint32_t i=0;i<root->size;i++){if(read_header(f,&v[i].e)){free_entries(v,i);fclose(f);return PSU_EFORMAT;} if(is_file_attr(v[i].e.attr)&&v[i].e.size){v[i].data=(uint8_t*)malloc(v[i].e.size);if(!v[i].data){free_entries(v,i);fclose(f);return PSU_ENOMEM;} if(fread(v[i].data,1,v[i].e.size,f)!=v[i].e.size){free_entries(v,i+1);fclose(f);return PSU_EFORMAT;} if(fseek(f,(long)pad_for(v[i].e.size),SEEK_CUR)){free_entries(v,i+1);fclose(f);return PSU_EFORMAT;}}}
    fclose(f);*out=v;*n=root->size;return 0;
}
static int save_psu(const char *path,const psu_entry_t *root,mem_entry_t *v,size_t n){
    char tmp[1200];snprintf(tmp,sizeof(tmp),"%s.tmp",path);FILE *o=fopen(tmp,"wb");if(!o)return PSU_EIO;psu_entry_t r=*root;r.size=(uint32_t)n;int rc=write_header(o,&r);
    for(size_t i=0;!rc&&i<n;i++){rc=write_header(o,&v[i].e);if(!rc&&is_file_attr(v[i].e.attr)){if(v[i].e.size && fwrite(v[i].data,1,v[i].e.size,o)!=v[i].e.size)rc=PSU_EIO;if(!rc)rc=write_zeros(o,pad_for(v[i].e.size));}}
    if(fclose(o)!=0&&!rc)rc=PSU_EIO;if(rc){remove(tmp);return rc;}remove(path);if(rename(tmp,path)!=0){remove(tmp);return PSU_EIO;}return 0;
}

int psu_add_or_replace(const char *path,const char *src,const char *entry_name){
    if(!safe_name(entry_name)||strlen(entry_name)>PSU_NAME_MAX)return PSU_EINVAL; struct stat st;if(stat(src,&st)||!S_ISREG(st.st_mode)||st.st_size>0xffffffffLL)return PSU_EIO;
    FILE *in=fopen(src,"rb");if(!in)return PSU_EIO;uint8_t *data=(uint8_t*)malloc((size_t)st.st_size?((size_t)st.st_size):1);if(!data){fclose(in);return PSU_ENOMEM;}if(st.st_size&&fread(data,1,(size_t)st.st_size,in)!=(size_t)st.st_size){free(data);fclose(in);return PSU_EIO;}fclose(in);
    psu_entry_t root;mem_entry_t *v=NULL;size_t n=0;int rc=load_psu(path,&root,&v,&n);if(rc){free(data);return rc;}size_t idx=n;
    for(size_t i=0;i<n;i++)if(is_file_attr(v[i].e.attr)&&!strncmp(v[i].e.name,entry_name,PSU_NAME_MAX)){idx=i;break;}
    if(idx==n){mem_entry_t *nv=(mem_entry_t*)realloc(v,(n+1)*sizeof(*v));if(!nv){free_entries(v,n);free(data);return PSU_ENOMEM;}v=nv;memset(&v[n],0,sizeof(v[n]));n++;}
    else free(v[idx].data);
    memset(&v[idx].e,0,sizeof(v[idx].e));v[idx].e.attr=PSU_ATTR_FILE;v[idx].e.size=(uint32_t)st.st_size;time_from_time_t(&v[idx].e.ctime,st.st_ctime);time_from_time_t(&v[idx].e.mtime,st.st_mtime);strncpy(v[idx].e.name,entry_name,PSU_NAME_MAX);v[idx].data=data;
    rc=save_psu(path,&root,v,n);free_entries(v,n);return rc;
}

int psu_delete_entry(const char *path,const char *name){
    if(!safe_name(name))return PSU_EINVAL;psu_entry_t root;mem_entry_t *v=NULL;size_t n=0;int rc=load_psu(path,&root,&v,&n);if(rc)return rc;size_t idx=n;
    for(size_t i=0;i<n;i++)if(is_file_attr(v[i].e.attr)&&!strncmp(v[i].e.name,name,PSU_NAME_MAX)){idx=i;break;}if(idx==n){free_entries(v,n);return PSU_ENOENT;}
    free(v[idx].data);for(size_t i=idx+1;i<n;i++)v[i-1]=v[i];n--;rc=save_psu(path,&root,v,n);free_entries(v,n);return rc;
}
