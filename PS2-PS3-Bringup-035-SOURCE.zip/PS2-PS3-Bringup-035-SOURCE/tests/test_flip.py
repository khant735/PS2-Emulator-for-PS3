#!/usr/bin/env python3
# Exercise the actual wait function with controllable RSX flip status.
from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];s=(r/'source/main.cpp').read_text()
a=s.index('static ',s.index('static int video_init'))
a=s.index('wait_for_previous_flip(){',a)
a=s.rfind('static ',0,a);b=s.index('\nstatic void upload_cpu_frame()',a)
f=s[a:b]
p=r/'build/host-flip';p.mkdir(parents=True,exist_ok=True)
(p/'test.cpp').write_text('''
#include <assert.h>
static int g_flip_pending=1, status=1, resets=0;static void*g_ctx=0;
static int gcmGetFlipStatus(){return status;}
static void gcmResetFlipStatus(){resets++;}
static void rsxFlushBuffer(void*){}
static void usleep(int){}
'''+f+'''
int main(){
 wait_for_previous_flip();assert(g_flip_pending==1);assert(resets==0);
 status=0;wait_for_previous_flip();assert(g_flip_pending==0);assert(resets==1);
 wait_for_previous_flip();assert(resets==1);
}
''')
subprocess.run(['c++',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
subprocess.run([str(p/'test')],check=True)
print('PASS: flip timeout preserves pending ownership; completed flip releases once')
