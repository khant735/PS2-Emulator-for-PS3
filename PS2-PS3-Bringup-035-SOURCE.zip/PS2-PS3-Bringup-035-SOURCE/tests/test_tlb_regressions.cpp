#include "emu_core.h"
#include <assert.h>
#include <stdlib.h>
#include <vector>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>rom(4*1024*1024);unsigned at=0;for(unsigned v:w)for(unsigned b=0;b<4;b++)rom[at++]=(v>>(8*b))&255;assert(c.loadBios(rom.data(),rom.size()));}
int main(int argc,char**argv){assert(argc==2);Core c;unsigned v;int which=atoi(argv[1]);
 if(which==1){setup(c,{0x42000002});c.cp0[10]=0x40000000;c.cp0[2]=(2<<6)|7;c.cp0[3]=7;assert(c.step());assert(c.write32(0x80002000,0x40886000));c.pc=0x40000000;c.next=c.pc+4;c.cp0[12]=16;c.reg[8]=0;unsigned long long retired=c.instructions;assert(!c.step()&&c.cp0[12]==16&&c.instructions==retired);}
 if(which==2){setup(c,{0x42000002});c.cp0[10]=0x40000000;c.cp0[2]=(0x70000000u>>12)<<6|7;c.cp0[3]=7;assert(c.step());c.cp0[12]=0;assert(!c.write32(0x40000000,123));}
 if(which==3){setup(c,{0x42000002});c.cp0[10]=0x40000000;c.cp0[2]=0x80000007;c.cp0[3]=7;assert(c.step());c.cp0[12]=0;assert(c.write32(0x40000000,0x2402002a));c.pc=0x40000000;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);}
 if(which==4){setup(c,{0x42000002});c.cp0[10]=0x40000000;c.cp0[2]=0x80000007;c.cp0[3]=7;c.cp0[5]=0x6000;assert(!c.step());}
 if(which==5){setup(c,{0x42000002});c.cp0[10]=0x40000000;c.cp0[2]=0x80000007;c.cp0[3]=1;assert(!c.step());}
 if(which==6){setup(c,{I(35,4,5,1)});c.reg[4]=0x1000;assert(!c.step()&&c.cp0[8]==0x1001);}
 if(which==7){setup(c,{I(35,4,5,0)});c.cp0[12]=0;c.cp0[4]=0x88800000;c.reg[4]=0x40000000;assert(!c.step());assert(c.cp0[4]==(0x88800000|((0x40000000u>>9)&0x7ffff0)));}
 (void)v;
}
