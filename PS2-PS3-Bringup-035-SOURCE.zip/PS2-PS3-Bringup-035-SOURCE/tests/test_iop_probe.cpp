#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;setup(c,{0x90430000});c.reg[2]=0xbf80146e;assert(c.step()&&c.reg[3]==0);assert(c.iop_probe_reads==1);
 for(unsigned a:{0x1f80146eu,0x9f80146eu,0xbf80146eu}){setup(c,{0x90430000,0x90430000});c.reg[2]=a;assert(c.step()&&c.step()&&c.reg[3]==0&&c.iop_probe_reads==2);}
 for(unsigned op:{33u,35u,55u,40u,41u,43u,63u}){setup(c,{I(op,2,3,0)});c.reg[2]=0xbf80146e;assert(!c.step()&&c.iop_probe_reads==0);}
 for(unsigned off:{-1u,1u}){setup(c,{I(36,2,3,off)});c.reg[2]=0xbf80146e;assert(!c.step()&&c.iop_probe_reads==0);}
 setup(c,{0});c.pc=0xbf80146c;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch&&c.iop_probe_reads==0);
 setup(c,{I(36,2,3,0)});c.reg[2]=0x40046e;c.cp0[12]=0;assert(!c.step()&&c.iop_probe_reads==0);
 setup(c,{I(36,2,3,0)});c.reg[2]=0x40046e;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x7e0043,0x7e0083));assert(c.step()&&c.reg[3]==0&&c.iop_probe_reads==1);
 setup(c,{0x10000002,0x90430000,0x24030001,0});c.reg[2]=0xbf80146e;assert(c.step()&&c.step()&&c.step()&&c.reg[3]==0&&c.iop_probe_reads==1);
 setup(c,{0});assert(c.iop_probe_reads==0);
 puts("PASS: BIOS IOP probe byte compatibility read");}
