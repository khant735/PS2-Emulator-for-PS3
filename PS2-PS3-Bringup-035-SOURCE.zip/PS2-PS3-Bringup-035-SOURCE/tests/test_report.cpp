#include "emu_core.h"
#include "emu_config.h"
#include <cassert>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <unistd.h>
extern "C" int __real_rename(const char*,const char*);
static bool deny_install=false;
extern "C" int __wrap_rename(const char*a,const char*b){
 if(strstr(a,".tmp")&&deny_install&&access(b,F_OK)!=0){errno=EIO;return -1;}
 if(access(b,F_OK)==0){errno=EEXIST;return -1;}
 return __real_rename(a,b);
}
int main(){
 Core c;char path[128];snprintf(path,sizeof(path),"/tmp/ps2-report-%d",int(getpid()));
 assert(c.writeReport(path,"first"));
 assert(c.writeReport(path,"second"));
 FILE*f=fopen(path,"rb");char b[512]={0};assert(f);fread(b,1,511,f);fclose(f);assert(strstr(b,"second"));
 deny_install=true;assert(!c.writeReport(path,"third"));assert(strstr(c.report_error,"old trace restored"));
 f=fopen(path,"rb");memset(b,0,sizeof(b));assert(f);fread(b,1,511,f);fclose(f);assert(strstr(b,"second"));
 assert(!c.writeReport("/no/such/directory/report","test"));assert(strstr(c.report_error,"open failed"));
 deny_install=false;unlink(path);
 Settings settings,loaded;assert(settings.save(path));settings.batch=10000;
 strcpy(settings.bios,"/dev_hdd0/PS2/BIOS.bin");assert(settings.save(path));
 assert(loaded.load(path)&&loaded.batch==10000&&!strcmp(loaded.bios,settings.bios));
 deny_install=true;settings.batch=1;assert(!settings.save(path));
 assert(loaded.load(path)&&loaded.batch==10000);
 unlink(path);puts("PASS: report replacement on no-overwrite filesystem; failed install retains prior report");
}
