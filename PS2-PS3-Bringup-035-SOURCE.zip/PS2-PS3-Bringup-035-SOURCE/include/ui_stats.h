#ifndef UI_STATS_H
#define UI_STATS_H
#include <stddef.h>
struct UiFps {
 unsigned long long start,frames;double fps;bool valid,started;
 UiFps():start(0),frames(0),fps(0),valid(false),started(false){}
 bool sample(unsigned long long now,unsigned long long submitted){
  if(!started||now<start||submitted<frames){start=now;frames=submitted;started=true;valid=false;return true;}
  unsigned long long dt=now-start;if(dt<1000000)return false;
  fps=double(submitted-frames)*1000000.0/double(dt);valid=true;start=now;frames=submitted;return true;
 }
};
struct VramUsage {
 struct Block{void*ptr;size_t size;};Block blocks[64];size_t bytes;
 VramUsage():bytes(0){for(unsigned i=0;i<64;i++)blocks[i].ptr=0;}
 bool add(void*p,size_t n){if(!p)return false;for(unsigned i=0;i<64;i++)if(!blocks[i].ptr){blocks[i].ptr=p;blocks[i].size=n;bytes+=n;return true;}return false;}
 void remove(void*p){if(!p)return;for(unsigned i=0;i<64;i++)if(blocks[i].ptr==p){bytes-=blocks[i].size;blocks[i].ptr=0;return;}}
};
#endif
