from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];s=(r/'source/main.cpp').read_text();a=s.index('static u32 lerp_color');b=s.index('static void gradient_fill_v',a)
p=r/'build/host-graphics';p.mkdir(parents=True,exist_ok=True)
(p/'test.cpp').write_text('#include <stdint.h>\n#include <assert.h>\ntypedef uint32_t u32;\n'+s[a:b]+'''
int main(){assert(lerp_color(0x30ffffff,0,0,100)==0x30ffffff);assert(lerp_color(0x30ffffff,0,100,100)==0);assert(lerp_color(0xff000000,0xffffffff,100,100)==0xffffffff);}
''')
subprocess.run(['c++',str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
print('PASS: panel gradients preserve alpha endpoints')
