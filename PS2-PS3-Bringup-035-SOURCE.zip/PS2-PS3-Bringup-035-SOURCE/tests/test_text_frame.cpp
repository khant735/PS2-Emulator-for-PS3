#include "text_frame.h"
#include <assert.h>
int main(){
 TextFrame t;FrameDamage d;int clears=0,draws=0;bool full=false;
 auto clear=[&](int,int,int,int,bool all){clears++;full=all;};auto draw=[&](const TextFrame::Line&){draws++;};
 auto frame=[&](int back,const char*s){d.begin(100);t.begin();t.add(2,10,60,8,1,s);t.flush(back,d,clear,draw);};
 frame(0,"long string");assert(full&&draws==1&&d.full);
 clears=draws=0;frame(0,"long string");assert(clears==0&&draws==0&&!d.full&&!d.changed(10));
 frame(0,"short");assert(clears==1&&draws==1&&!full&&d.changed(10)&&!d.changed(9)&&!d.changed(18));
 frame(1,"short");assert(full); // Independent backbuffer has never been drawn.
 clears=draws=0;frame(0,"short");assert(draws==0); // Other buffer didn't alter its cache.
 t.begin();d.begin(100);t.add(2,10,60,8,1,"short",0xff00ff00);t.flush(0,d,clear,draw);assert(draws==1&&d.changed(10));
 t.begin();d.begin(100);t.flush(0,d,clear,draw);assert(full&&d.full); // Removed text clears.
 d.begin(100);d.mark(-5,10);assert(d.changed(0)&&d.changed(4)&&!d.changed(5));
 d.begin(3000);assert(d.full&&d.changed(2999));
 puts("PASS: retained text, shortened lines, independent buffers, removed lines and damage bounds");
}
