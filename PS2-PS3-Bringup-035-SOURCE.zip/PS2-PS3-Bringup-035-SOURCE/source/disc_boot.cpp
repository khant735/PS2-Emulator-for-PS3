#include "disc_boot.h"
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
static char*trim(char*s){while(isspace((unsigned char)*s))s++;size_t n=strlen(s);while(n&&isspace((unsigned char)s[n-1]))s[--n]=0;return s;}
static void unversion(char*s){char*p=strrchr(s,';');if(!p||!p[1])return;for(char*q=p+1;*q;q++)if(!isdigit((unsigned char)*q))return;*p=0;}
// Resolve mounted-disc spelling, including mounts which retain ISO ;1 suffixes.
static bool child(const char*parent,const char*name,char*out,size_t cap){
 DIR*d=opendir(parent);if(!d)return false;struct dirent*e;bool ok=false;
 while((e=readdir(d))){char candidate[256];snprintf(candidate,sizeof(candidate),"%s",e->d_name);unversion(candidate);
  if(strcasecmp(candidate,name))continue;
  int n=snprintf(out,cap,"%s/%s",parent,e->d_name);ok=n>=0&&(size_t)n<cap;break;}
 closedir(d);return ok;
}
bool read_disc_boot(const char*root,DiscBoot&boot,char*error,size_t capacity){
 auto fail=[&](const char*s){snprintf(error,capacity,"%s",s);return false;};
 DiscBoot result={};char cnf[1024];if(!root||!child(root,"SYSTEM.CNF",cnf,sizeof(cnf)))return fail("SYSTEM.CNF not found at disc root");
 FILE*f=fopen(cnf,"rb");if(!f)return fail("Cannot read disc SYSTEM.CNF");
 char text[16385];size_t n=fread(text,1,sizeof(text)-1,f);bool bad=ferror(f)||n==sizeof(text)-1;if(fclose(f))bad=true;
 if(bad)return fail("SYSTEM.CNF unreadable or too large");text[n]=0;if(memchr(text,0,n))return fail("SYSTEM.CNF contains binary data");
 char target[1024]={0};bool found=false;
 for(char*line=text;line&&*line;){char*next=strchr(line,'\n');if(next)*next++=0;char*p=trim(line);char*eq=strchr(p,'=');
  if(eq){*eq++=0;char*key=trim(p),*value=trim(eq);size_t len=strlen(value);
   if(len>=2&&value[0]=='"'&&value[len-1]=='"'){value[len-1]=0;value++;}
   if(!strcasecmp(key,"BOOT2")){if(found)return fail("Duplicate BOOT2 entries");found=true;if(strlen(value)>=sizeof(target))return fail("BOOT2 path too long");strcpy(target,value);}
   else if(!strcasecmp(key,"VER"))snprintf(result.version,sizeof(result.version),"%s",value);
   else if(!strcasecmp(key,"VMODE"))snprintf(result.vmode,sizeof(result.vmode),"%s",value);
  }line=next;
 }
 if(!found||!target[0])return fail("No PS2 BOOT2 entry in SYSTEM.CNF");
 if(strncasecmp(target,"cdrom0:",7))return fail("BOOT2 must use cdrom0:");
 char*relative=target+7;while(*relative=='\\'||*relative=='/')relative++;
 for(char*q=relative;*q;q++)if(*q=='\\')*q='/';
 char path[1024];if(strlen(root)>=sizeof(path))return fail("Disc path too long");strcpy(path,root);
 bool component=false;
 for(char*p=relative;p&&*p;){char*next=strchr(p,'/');if(next)*next++=0;unversion(p);
  if(!*p||!strcmp(p,".")||!strcmp(p,"..")||strchr(p,':'))return fail("Invalid BOOT2 path component");
  for(char*q=p;*q;q++)if((unsigned char)*q<32)return fail("Invalid BOOT2 path character");
  char resolved[1024];if(!child(path,p,resolved,sizeof(resolved)))return fail("BOOT2 executable path not found on disc");strcpy(path,resolved);component=true;p=next;
 }
 struct stat st;if(!component||stat(path,&st)||!S_ISREG(st.st_mode))return fail("BOOT2 is not a readable file");
 strcpy(result.path,path);boot=result;error[0]=0;return true;
}
