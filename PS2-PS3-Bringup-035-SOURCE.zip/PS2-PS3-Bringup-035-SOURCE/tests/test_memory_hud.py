from pathlib import Path
import subprocess
r=Path(__file__).resolve().parents[1];s=(r/'source/main.cpp').read_text()
a=s.index('static void ui_memory_text(');b=s.index('\nSYS_PROCESS_PARAM',a)
f=s[a:b]
p=r/'build/host-memory';p.mkdir(parents=True,exist_ok=True)
(p/'test.cpp').write_text('''
#include <cstdio>
#include <cstring>
#include <cassert>
#include <cstdint>
#include <malloc.h>
static char ui_memory_pages[2][11][180];
using u32=uint32_t;
struct UiMemoryInfo{u32 total,available;};
struct gcmConfiguration{u32 localSize,coreFreq,memoryFreq;};
static struct{size_t bytes;}ui_vram={16*1024*1024};
static u32 returned_size=249*1024*1024;
static int ui_get_memory(UiMemoryInfo*m){m->total=200*1024*1024;m->available=100*1024*1024;return 0;}
static int gcmGetConfiguration(gcmConfiguration*c){c->localSize=returned_size;c->coreFreq=500000000;c->memoryFreq=650000000;return 12345;}
'''+f+'''
int main(){char b[256];ui_memory_text(b,sizeof(b));assert(strstr(b,"16.0/249.0 MiB"));
assert(strstr(ui_memory_pages[0][3],"50.0%"));assert(strstr(ui_memory_pages[1][4],"6.4%"));
assert(strstr(ui_memory_pages[1][0],"500.00 MHz"));assert(strstr(ui_memory_pages[1][0],"650.00 MHz"));assert(strstr(ui_memory_pages[0][0],"NOT DETECTED"));
returned_size=0;ui_memory_text(b,sizeof(b));assert(strstr(b,"TOTAL N/A"));
returned_size=0xffffffff;ui_memory_text(b,sizeof(b));assert(strstr(b,"TOTAL N/A"));
returned_size=8*1024*1024;ui_memory_text(b,sizeof(b));assert(strstr(b,"TOTAL N/A"));
assert(strstr(ui_memory_pages[0][8],"NOT MEASURED"));
puts("PASS: valid VRAM capacity accepted independently of status; missing/invalid capacity remains N/A");}
''')
subprocess.run(['c++',str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True)
