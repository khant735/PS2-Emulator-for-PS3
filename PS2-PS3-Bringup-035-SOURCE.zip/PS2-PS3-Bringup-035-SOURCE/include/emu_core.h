#ifndef EMU_CORE_H
#define EMU_CORE_H
#include <stdint.h>
#include <stddef.h>
#include "ee_tlb.h"
#include "ee_dve.h"
// CPU bring-up: partial CP0/TLB, explicit fault stops; no IOP/VU/GS/SPU2.
class Core {
public:
 enum Stop { NONE, BREAKPOINT, UNSUPPORTED, MEMORY, CONTROL };
 uint64_t reg[32],reg_hi[32], instructions, hi, lo;
 uint32_t cp0[32],fpr[32];
 uint32_t intc_stat,intc_mask;
 uint32_t gif_mode,gif_pause;uint64_t gif_resets;
 uint32_t gs_csr;uint64_t gs_resets,gs_flushes;
 uint64_t gs_video[15],gs_video_writes;
 uint64_t iop_probe_reads;
 EeTlb tlb;
 EeDve dve;
 uint32_t ee_f500,ee_f500_last_write;bool ee_f500_known;
 uint64_t ee_f500_reads,ee_f500_writes;
 unsigned char serial_tx[4096];unsigned serial_tx_size;
 uint64_t serial_tx_total,serial_status_reads;
 struct Trace { uint32_t pc,opcode; bool delay,fetched; };
 uint32_t fault_address;
 unsigned fault_size;
 bool fault_write,fault_fetch,stopped_in_delay;
 unsigned historyCount() const;
 bool historyAt(unsigned,Trace&) const;
 bool writeReport(const char* path,const char* guest) const;
 uint32_t pc, next, opcode;
 Stop stop;
 char error[160];
 mutable char report_error[160];
 Core(); ~Core(); bool ready() const;
 bool loadElf(const unsigned char*,size_t);
 bool loadBios(const unsigned char*,size_t);
 bool step(); bool read32(uint32_t,uint32_t&); bool write32(uint32_t,uint32_t);
 const char* reason() const;
private:
 unsigned char *ram,*rom,*scratch,*iop_ram;
 bool delay;
 bool translated_scratch,instruction_fetch;
 char translation_error[80];
 bool translate(uint32_t,size_t,bool,uint32_t&);
 Trace history[64];
 unsigned history_head,history_count;
 bool halt(Stop,const char*);
 bool memoryHalt(uint32_t,unsigned,bool,bool);
 bool mmioRead(uint32_t,unsigned,uint64_t&);
 bool mmioWrite(uint32_t,unsigned,uint64_t);
 Core(const Core&); Core& operator=(const Core&);
 unsigned char* address(uint32_t,size_t,bool);
 void reset(uint32_t);
 bool fail(const char*);
};
#endif
