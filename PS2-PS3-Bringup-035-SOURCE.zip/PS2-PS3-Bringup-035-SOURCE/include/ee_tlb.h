#ifndef EE_TLB_H
#define EE_TLB_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
struct EeTlb {
 struct Entry{uint32_t mask,hi,lo0,lo1;bool written;};
 Entry entry[48];
 EeTlb(){clear();}
 void clear(){memset(entry,0,sizeof(entry));}
 static bool validMask(uint32_t m){return m==0||m==0x6000||m==0x1e000||m==0x7e000||m==0x1fe000||m==0x7fe000||m==0x1ffe000;}
 bool put(unsigned i,uint32_t mask,uint32_t hi,uint32_t lo0,uint32_t lo1){
  if(i>=48||!validMask(mask))return false;
  // Reject unusual scratch layouts rather than mapping beyond its 16K backing.
  if((lo0&0x80000000u)&&(mask||((hi&0xffffe000u)&0x3fffu)||((lo0^lo1)&6)))return false;
  if(lo0&0x80000000u){lo0=(lo0&~0x38u)|0x10u;lo1=(lo1&~0x38u)|0x10u;}
  Entry e={mask,hi&0xffffe0ffu,lo0&0x83ffffffu,lo1&0x03ffffffu,true};entry[i]=e;return true;
 }
 static bool asidMatch(const Entry&e,uint32_t asid){return (e.lo0&e.lo1&1)||((e.hi&255)==(asid&255));}
 static bool vpnMatch(const Entry&e,uint32_t a){uint32_t mask=(e.lo0&0x80000000u)?0x3fffu:e.mask|0x1fffu;return (a&~mask)==(e.hi&~mask);}
 int probe(uint32_t hi)const{
  int found=-1;for(unsigned i=0;i<48;i++)if(entry[i].written&&vpnMatch(entry[i],hi)&&asidMatch(entry[i],hi)){if(found>=0)return -2;found=i;}return found;
 }
 const char*map(uint32_t a,size_t n,uint32_t asid,bool wr,uint32_t&physical,bool&scratch)const{
  scratch=false;
  int found=-1;
  for(unsigned i=0;i<48;i++){
   const Entry&e=entry[i];if(!e.written||!asidMatch(e,asid))continue;
   uint32_t base=e.hi&~(e.mask|0x1fffu);
   bool match=(e.lo0&0x80000000u)?(a>=base&&uint64_t(a)-base<0x4000):vpnMatch(e,a);
   if(match){if(found>=0)return "TLB duplicate mappings";found=i;}
  }
  if(found<0)return "TLB miss";
  const Entry&e=entry[found];uint32_t page=(e.mask+0x2000)/2;
  scratch=(e.lo0&0x80000000u)!=0;uint32_t lo=scratch?e.lo0:((a&page)?e.lo1:e.lo0);
  if(!(lo&2))return "TLB invalid page";
  if(wr&&!(lo&4))return "TLB dirty permission denied";
  if(scratch){uint32_t offset=a-(e.hi&~(e.mask|0x1fffu));if(n>0x4000-offset)return "TLB scratch boundary";physical=offset;}
  else{uint32_t offset=a&(page-1);if(n>page-offset)return "TLB page boundary";physical=(((lo>>6)&0xfffffu)<<12)&~(page-1);physical|=offset;}
  return 0;
 }
};
#endif
