#!/usr/bin/env bash
set -euo pipefail
BASE=https://raw.githubusercontent.com/ps3dev/PSL1GHT/master/samples/graphics
mkdir -p vendor/debugfont/{source,include,shaders} vendor/rsxutil/source vendor/rsxutil/include
for f in debugfont.cpp debugfontdata.h debugfontrenderer.cpp rsxdebugfontrenderer.cpp; do curl -fL "$BASE/debugfont_renderer/source/$f" -o "vendor/debugfont/source/$f"; done
for f in debugfont.h debugfontrenderer.h rsxdebugfontrenderer.h; do curl -fL "$BASE/debugfont_renderer/include/$f" -o "vendor/debugfont/include/$f"; done
for f in fpshader_dbgfont.fcg vpshader_dbgfont.vcg; do curl -fL "$BASE/debugfont_renderer/shaders/$f" -o "vendor/debugfont/shaders/$f"; done
curl -fL "$BASE/rsxtest/source/rsxutil.cpp" -o vendor/rsxutil/source/rsxutil.cpp
curl -fL "$BASE/rsxtest/include/rsxutil.h" -o vendor/rsxutil/include/rsxutil.h
printf 'Vendored PSL1GHT debugfont/rsxutil sample support.\n'
