#ifndef TEXT_FRAME_H
#define TEXT_FRAME_H
#include <string.h>
#include <stdio.h>
struct FrameDamage {
 enum { MAX_ROWS=2160 };
 unsigned height;bool full;unsigned char rows[MAX_ROWS];
 FrameDamage():height(0),full(true){}
 void begin(unsigned h){height=h;full=h>MAX_ROWS;memset(rows,0,sizeof(rows));}
 void mark(int y,int h){if(full)return;int end=y+h;if(y<0)y=0;if(end>(int)height)end=height;for(int i=y;i<end;i++)rows[i]=1;}
 void all(){full=true;}
 bool changed(unsigned y)const{return full||rows[y]!=0;}
};
struct TextFrame {
 enum { CAP=96 };
 struct Line {int x,y,w,h,scale;unsigned color;char text[256];};
 Line current[CAP],previous[2][CAP];unsigned count,old_count[2];bool valid[2];
 TextFrame():count(0){invalidate();}
 void invalidate(){valid[0]=valid[1]=false;old_count[0]=old_count[1]=0;}
 void begin(){count=0;}
 void add(int x,int y,int w,int h,int scale,const char*text,unsigned color=0xffffffffu){
  if(count==CAP)return;Line&l=current[count++];l.x=x;l.y=y;l.w=w;l.h=h;l.scale=scale;l.color=color;snprintf(l.text,sizeof(l.text),"%s",text);
 }
 template<class Clear,class Draw> void flush(unsigned back,FrameDamage&damage,Clear clear,Draw draw){
  bool full=!valid[back]||count!=old_count[back];
  for(unsigned i=0;i<count&&!full;i++){
   Line&a=current[i],&b=previous[back][i];
   if(a.x!=b.x||a.y!=b.y||a.w!=b.w||a.h!=b.h||a.scale!=b.scale)full=true;
  }
  if(full){clear(0,0,0,0,true);damage.all();}
  for(unsigned i=0;i<count;i++){
   Line&l=current[i];if(!full&&l.color==previous[back][i].color&&!strcmp(l.text,previous[back][i].text))continue;
   if(!full){clear(l.x,l.y,l.w,l.h,false);damage.mark(l.y,l.h);}
   draw(l);
  }
  memcpy(previous[back],current,count*sizeof(Line));old_count[back]=count;valid[back]=true;
 }
};
#endif
