#!/usr/bin/env python3
"""Render the actual software HUD functions on host; NOT a PS3 runtime test."""
from pathlib import Path
import re, subprocess
root=Path(__file__).resolve().parents[1]
s=(root/'source/main.cpp').read_text()
draw=s[s.index('static int scale125'):s.index('static int draw_face_button_token')]
draw=re.sub(r'static int model_update_interval\(\);|static int icn_hw_init\(\);|static int icn_hw_draw_model\(\);','',draw)
line=re.search(r'static void line\(int x0.*?\n}',s,re.S)
# The actual line helper follows the icon geometry section; get by brace matching.
start=s.index('static void line(',s.index('static void line(')+1)
end=s.index('{',start);depth=1;i=end+1
while depth:
 if s[i]=='{':depth+=1
 elif s[i]=='}':depth-=1
 i+=1
draw+=s[start:i]
fs=s[s.index('static int endswith(const char *s,const char *x){'):s.index('#include "emu_ui.inc"')]
ui=(root/'source/emu_ui.inc').read_text().split('int main(){')[0]
header='''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <malloc.h>
#include <dirent.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdarg.h>
#include <math.h>
#include <stdint.h>
#include <assert.h>
#include "text_frame.h"
static FrameDamage g_damage;
typedef uint8_t u8;typedef uint32_t u32;
#define PATHSZ 1024
#define MAX_ITEMS 512
struct item_t {char name[256];char path[1024];int is_dir;unsigned long long size;};
static item_t items[MAX_ITEMS];static int item_count,selected,top_index,running=1;
static char cwd[1024]="/dev_hdd0",status_line[256]="Ready";
static u32 *g_fb[2],*g_bg_cache;static int g_back,g_bg_cache_ready,g_frame_counter;
static u32 g_width,g_height,g_pitch;
static int g_title_scale,g_body_scale,g_help_scale,g_margin,g_title_x,g_title_y,g_path_x,g_path_y,g_list_x,g_list_y,g_row_h;
static bool wait_for_previous_flip(){return true;}static unsigned long long g_present_frames=0;
static char ui_memory_pages[2][11][180];
static void ui_memory_text(char*out,size_t n){
 snprintf(out,n,"RAM HEAP 60.0 USED 4.0 FREE MiB  VRAM 15.8/249.0 MiB");
 const char*fixtures[11]={"CPU SYSTEM RAM","TOTAL INSTALLED: NOT DETECTED","APP MEMORY LIMIT: 209.00 MiB (100%)","FREE FOR NEW ALLOCATIONS: 151.04 MiB (72.3%)","APP RAM USED (HEAP ONLY): 53.84 MiB (25.8%)","FREE INSIDE APP HEAP: 1.01 MiB (0.5%)","TOTAL APP RAM USE: NOT MEASURED","OS MEMORY IN USE: NOT MEASURED","SET ASIDE FOR OS: NOT MEASURED","OS RESERVED SPACE USED/FREE: NOT MEASURED","% OF APP LIMIT; APP USE EXCLUDES CODE/STACK"};
 for(int p=0;p<2;p++)for(int i=0;i<11;i++)snprintf(ui_memory_pages[p][i],180,"%s",fixtures[i]);
}
static void upload_cpu_frame(){}static void present(){g_present_frames++;}
'''
main='''
int main(int argc,char**argv){
 if(argc<4)return 1;g_width=atoi(argv[1]);g_height=atoi(argv[2]);g_pitch=g_width*4;
 g_fb[0]=(u32*)calloc(g_width*g_height,4);g_fb[1]=(u32*)calloc(g_width*g_height,4);configure_ui_metrics();core=new Core();
 ui_fps.sample(0,0);ui_fps.sample(1000000,60);ui_memory_text(ui_memory_line,sizeof(ui_memory_line));
 for(int page=0;page<7;page++){screen=page<6?page:5;memory_page=page>=6?page-5:0;dirty=true;menu_sel=0;notice("Experimental CPU harness - no BIOS boot or games");
 if(page==1){item_count=2;strcpy(items[0].name,"PS2");items[0].is_dir=1;strcpy(items[1].name,"SMOKE.ELF");}
 if(page==3){core->loadElf(smoke_elf,sizeof(smoke_elf));core_loaded=true;for(int i=0;i<6;i++)core->step();}
 render_emu();char name[1200];snprintf(name,sizeof(name),"%s/%ux%u-page%d.ppm",argv[3],g_width,g_height,page);FILE*f=fopen(name,"wb");if(!f)return 2;
 fprintf(f,"P6\\n%u %u\\n255\\n",g_width,g_height);for(unsigned i=0;i<g_width*g_height;i++){unsigned char p[3]={(unsigned char)(g_fb[0][i]>>16),(unsigned char)(g_fb[0][i]>>8),(unsigned char)g_fb[0][i]};fwrite(p,1,3,f);}fclose(f);
 }
 data_dir=argv[3];screen=0;start_ui_test();for(int n=0;n<60;n++)render_emu();
 assert(ui_test_frames==60&&ui_test_remaining==0);
 char report[1200];snprintf(report,sizeof(report),"%s/ui-timing.txt",argv[3]);FILE*rf=fopen(report,"rb");assert(rf);char rb[2000]={0};fread(rb,1,sizeof(rb)-1,rf);fclose(rf);assert(strstr(rb,"Frames=60")&&strstr(rb,"upload average_us=")&&strstr(rb,"wait_timeouts="));
 // Compare incremental output with forced full redraw at identical UI state.
 for(int k=0;k<36;k++){
  g_back=k%2;screen=(k/6)%6;menu_sel=k%10;dirty=true;memset(ui_last,0,sizeof(ui_last));render_emu();
  size_t bytes=(size_t)g_pitch*g_height;void*expected=malloc(bytes);memcpy(expected,g_fb[g_back],bytes);
  TextFrame saved=text_frame;text_frame.invalidate();dirty=true;memset(ui_last,0,sizeof(ui_last));render_emu();assert(!memcmp(expected,g_fb[g_back],bytes));text_frame=saved;free(expected);
 }
 delete core;free(g_fb[0]);free(g_fb[1]);free(g_bg_cache);return 0;
}
'''
out=root/'build/host-ui';out.mkdir(parents=True,exist_ok=True)
(out/'render.cpp').write_text(header+draw+fs+ui+main)
subprocess.run(['c++','-std=c++11','-O1','-I'+str(root/'include'),str(out/'render.cpp'),str(root/'source/emu_core.cpp'),str(root/'source/emu_config.cpp'),str(root/'source/disc_boot.cpp'),'-o',str(out/'render')],check=True)
for w,h in [(720,480),(720,576),(1280,720),(1920,1080)]:subprocess.run([str(out/'render'),str(w),str(h),str(out)],check=True)
from PIL import Image
for p in out.glob('*.ppm'):
 Image.open(p).save(p.with_suffix('.png'));p.unlink()
print('Rendered 28 actual HUD screens at SD/HD resolutions; not PS3 execution.')
