# PS2 on PS3 — CPU Bring-up 033

**Experimental development harness. This does NOT boot the PS2 BIOS or run games.**
This is an initial step toward the requested emulator, not completion of it.
Target for future hardware testing: FAT PS3, Evilnat CFW 4.92/Cobra.

## Implemented
- Plain text HUD derived from PSU Manager, coloured diagnostics and HDD/USB/disc browser.
- Separate PS3 title ID `P2E000001` (does not replace PSU Manager).
- Home, file selection, settings, CPU diagnostics and implementation-status pages.
- Automatic config save after a selection/change using a temporary file and rename.
- Bounded ELF32 little-endian MIPS ET_EXEC loader, PT_LOAD validation and BSS clearing.
- Raw 4 MiB ROM0 mapping at the PS2 reset vector for limited instruction tracing.
  File size validation does not authenticate a BIOS dump.
- 32 MiB RAM, 16 KiB scratchpad, 4 MiB ROM; explicit little-endian accesses.
- Integer instruction subset and branch delay handling; explicit stops at missing
  instructions, MMIO, misalignment and unmapped addresses.
- Original built-in MIPS ELF test: R10=12, R11=42, PC=00100018 after 5 instructions.

## Build 033 changes

Captures writes to the 15 GS video configuration registers at 12000000 through
120000E0 (16-byte spacing): PMODE, SMODE1/2, SRFSH, SYNCH1/2, SYNCV,
DISPFB1/2, DISPLAY1/2, EXTBUF, EXTDATA, EXTWRITE and BGCOLOR. Aligned 64-bit
writes and 32-bit low/high lanes are recorded as raw bits, without reserved-bit
validation or hardware effects. Reads, gaps and other widths remain unsupported.
GS reset clears captured values; trace shows named values and total writes.
No clocks, video timings, field events, scanout, drawing or host video changes
are implemented. This is write capture for bring-up, not full register emulation.
Select RUN GS RESET TEST, then reload the BIOS before tracing.

## Build 032 changes

Adds a byte-read compatibility fallback only at physical 1F80146E. It returns
zero, consistent with PCSX2's unknown-register backing after reset; the actual
physical register meaning/value is UNVERIFIED. This is not hardware emulation
or detection. Every trace labels the assumption and counts uses. Writes,
neighboring addresses, wider accesses and instruction fetch still stop.
Translation and privilege checks run before the fallback. The GS RESET TEST
now includes this probe. Reload the BIOS before tracing.
References: PCSX2 psxHwReset zeroes the IOP register backing; IopHwRead8_Page1
returns backing storage for unknown addresses:
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/IopHw.cpp/
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/ps2/Iop/IopHwRead.cpp

## Build 031 changes

Adds limited GS_CSR handling at 12001000: aligned 32/64-bit reads/writes,
upper-word read-only zero, reset bit9, event acknowledgement bits0..4 and
flush bit8 (no-op with no FIFO). Idle CSR is 551B4000: FIFO empty, emulated
REV=1B/ID=55 following PCSX2's model, not host PS3 hardware detection. No field
changes or events are generated. GS reset leaves GIF control state intact.
Other GS registers, byte/halfword CSR accesses, packets and rendering remain
unsupported. Trace records CSR/reset/flush counts.
Select RUN GS RESET TEST, then reload the BIOS before tracing.
References: https://github.com/PCSX2/pcsx2/blob/master/pcsx2/GS.cpp
https://github.com/PCSX2/pcsx2/blob/master/pcsx2/GS.h

## Build 030 changes

Adds an aligned word GIF control subset: writes to GIF_CTRL (10003000) and
GIF_MODE (10003010), reads from GIF_STAT (10003020). Reset clears mode/pause;
CTRL bit3 pauses, MODE bits0/2 select PATH3 masking/intermittent mode, reflected
in status. Unsupported bits are ignored. No packets are accepted and status
has no active path/FIFO contents. CTRL/MODE reads, STAT writes, other registers
and widths still stop. Trace shows mode, pause, status and reset count.
Select RUN GIF CONTROL TEST, then reload the BIOS before tracing.
No GIF packet processing, DMA paths or GS rendering is implemented.
Reference: https://psi-rockin.github.io/ps2tek/ (GIF I/O)

## Build 029 changes

Adds a separate 2 MiB IOP RAM backing, mirrored four times in the EE physical
window 1C000000..1C7FFFFF. KSEG aliases and TLB permissions use the existing
translation path. RAM is zeroed on loading a BIOS or ELF. No IOP CPU runs,
no configuration pointer is synthesized at offset 3C0, and no IOP modules,
SIF protocol or IOP hardware registers are emulated. The trace reports the raw
word at 3C0. Zero here is initial RAM content, not a valid system configuration.
Select RUN IOP RAM TEST, then reload the BIOS to clear test data before tracing.
Reference: https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/IopMem.cpp/

## Build 028 changes

Adds an experimental DVE control-bus subset at physical 1A000000, with aligned
halfword accesses to offsets 00,02,04,06,08,0A,10,12 only. Includes the exact
BIOS write of 3 to BA000008, register latches, power/error state and status
acknowledgement. Single-register write (mode43/count2) and readback of a known
selected register (mode42/count1) are supported. Device indices are bounded to
0..255. Status progresses on polling, not hardware cycles. Unknown commands,
lengths, device reads, offsets and widths stop explicitly. This approximation
follows PCSX2's partially documented bus model; it is not complete DVE hardware.
There is no encoder output, GS rendering or host video-mode change.
Select RUN DVE BUS TEST, then reload the BIOS before tracing.
Reference: https://github.com/PCSX2/pcsx2/blob/master/pcsx2/Memory.cpp

## Build 027 changes

Adds aligned word INTC_STAT (1000F000) and INTC_MASK (1000F010) accesses.
Status writes clear selected bits; mask writes toggle selected low 16 bits.
Registers start at zero in the bring-up model. No devices currently generate
pending interrupts and no interrupt exceptions are delivered. Trace files show
both registers. The COP1 / SERIAL TEST now also checks mask toggle/readback.
Other register addresses and access widths remain explicit faults.
Reference: PCSX2 HwWrite.cpp INTC_STAT/INTC_MASK handlers:
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/HwWrite.cpp/

## Build 026 changes

Adds a limited disconnected debug-serial approximation: word reads from SIO_ISR
(1000F130) return zero, matching PCSX2; byte writes to SIO_TXFIFO (1000F180)
are captured immediately. No physical PS3 serial port is accessed.
The first 4096 output bytes appear between SERIAL_OUTPUT_BEGIN/END in the trace,
with total/captured/omitted counts. Non-text bytes and backslashes are escaped.
RX, timing, interrupts, control registers and wider TX accesses are unsupported.
Select RUN COP1 / SERIAL TEST, then reload the BIOS before tracing.
References:
https://ps2dev.github.io/ps2sdk/sio_8h.html
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/HwRead.cpp/
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/HwWrite.cpp/

## Build 025 changes

Adds 32 raw 32-bit COP1 registers, MFC1/MTC1 transfers and LWC1/SWC1.
MFC1 sign-extends to the lower 64 bits of its destination GPR, preserving the
upper half. Memory operations use the existing mapped memory/permission path,
check 4-byte alignment and require Status.CU1. Faults stop explicitly.
FPRs reset to zero as a deterministic bring-up choice, not a claim about
physical power-on contents. Trace files include F00-F31 raw bits.
Select RUN COP1 TRANSFER TEST, then reload the BIOS before tracing.
FPU arithmetic, control-register transfers and COP1 branches remain unsupported.

## Build 024 changes

Adds CACHE 0x16 (DXIN: data cache index invalidate), including both ways.
Like IXIN, this retires without a data-memory access in the current cacheless
interpreter. There are no dirty cache lines to discard. This is not a full
cache model and cannot reproduce cache-dependent software behavior.
Other CACHE modes and non-kernel execution still stop. The built-in 128-bit
test now executes both DXIN way indices. BIOS boot remains unfinished.

## Build 023 changes

Adds CACHE operation 0x07 (IXIN: instruction cache index invalidate).
Because this interpreter fetches directly from memory, IXIN retires without
changing memory or translating its index as a data address. This is a limited
cacheless approximation, not a hardware cache model. Other CACHE operations
and non-kernel CACHE execution stop explicitly. The built-in 128-bit test
also executes the exact BIOS opcode BF470000 before its intentional BREAK.
Reference: PCSX2 Cache.cpp, IXIN implementation:
https://sources.debian.org/src/pcsx2/1.6.0%2Bdfsg-2/pcsx2/Cache.cpp/

## Build 022 changes

Adds 128-bit PAND, PXOR, POR and PNOR with both register halves updated.
The console 128-bit test now checks packed logic after its ROM-to-RAM copy.
The BIOS trace opcode 700014A9 (POR v0,zero,zero) is covered by a host test.
Other MMI instructions still stop explicitly; BIOS boot remains unfinished.

## Build 021 changes

Adds upper 64-bit storage for every general-purpose register and LQ/SQ 16-byte
loads/stores. Scalar instructions preserve the upper halves. LQ/SQ round the
effective address down to a 16-byte boundary and validate the complete access
before changing state. Trace reports include each register's upper half.
Select **RUN 128-BIT TEST** to check a complete ROM-to-RAM transfer, then reload
the BIOS before tracing. Other R5900/MMI instructions remain unfinished.

## Build 020 changes
- 48-entry partial EE TLB: Index, Random, EntryLo0/1, Context, PageMask, Wired, EntryHi and BadVAddr reads; TLBR/TLBWI/TLBWR/TLBP.
- Standard 4 KiB through 16 MiB even/odd page mappings, ASID/global matching, V/D permissions, kernel direct aliases and ERL low-address mapping. Random cycles in the unwired range per retired instruction.
- Scratch mappings require S=1, mask=0, 16 KiB alignment and matching V/D bits. Scratch cache attributes read as uncached. Scratch instruction fetches and ordinary physical PFNs targeting scratch backing are rejected. ERL direct scratch alias is retained for harness compatibility.
- COP0 usability checks reject unprivileged CU0-disabled access. TLB operations remain kernel-only in this partial implementation.
- Translation/alignment faults stop with BadVAddr; TLB faults also update diagnostic Context/EntryHi fields. Guest exception vectors are not delivered. Caches, DMA, timer/interrupt delivery and a complete MMU remain unimplemented.
- CPU diagnostics has a fourth TLB-register page (L1/R1). Trace lists written entries.
- RUN TLB TEST should report TLB TEST PASS; mapped even/odd RAM reads return R14=42/R15=45. Reload BIOS after the test before tracing firmware.
- References: https://psi-rockin.github.io/ps2tek/ ; Sony EE Core User's Manual sections 4.2 and 5.2, mirrored at https://docs.alexrp.com/mips/ee.pdf ; PCSX2 COP0.cpp (no source copied).
- No BIOS boot or game compatibility claim; console verification required.

## Build 019 changes
- Experimental aligned 32-bit data MMIO at EE physical 0x1000F500, including KSEG aliases. Writes retain only bits 0-1; readback is supported after a write.
- Based on wisi's published hardware observations in the PS2Ident discussion, post 55 (1 December 2019): https://www.psx-place.com/threads/request-im-collecting-info-about-ps2-consoles-revisions.23276/page-3
- Register purpose/side effects remain uncertain. This is a provisional stored-bit model, not full EE control, DMA or TLB emulation. Reads before initialization stop because reset contents are unverified.
- Narrow/wide/unaligned accesses, neighboring registers and instruction fetches remain rejected. Trace includes last raw write, masked state and access counts.
- Reload BIOS and trace again. No claim of correct complete hardware initialization or BIOS boot.

## Build 018 changes
- CP0 Compare register transfers: MTC0 stores low 32 bits; MFC0 sign-extends into the supported 64-bit GPR portion.
- Exact user BIOS opcode 409A5800 is exercised by host regression tests. Compare appears on CPU diagnostics CP0 page.
- Count writes remain supported, but timed Count reads, Count advancement, timer events and interrupt delivery remain unsupported. Equal Count/Compare storage does not generate interrupts.
- Does not implement complete BIOS boot. Reload and trace BIOS to obtain the next stop.

## Build 017 changes
- SELECT ELF FROM DISC opens /dev_bdvd. X enters any folder or selects any file; Circle goes up and stops at the disc root. Select cancels.
- Selected files use the existing Load selected ELF action. No SYSTEM.CNF or .ELF extension is required; actual ELF contents are validated by the loader.
- LOAD DISC BOOT ELF (SYSTEM.CNF) reads BOOT2 from the disc root, resolves cdrom0 paths including subfolders, and loads the executable paused in CPU diagnostics. VER/VMODE are metadata, not applied video settings.
- Device cycling includes mounted /dev_bdvd. Files are read only; no mounting, sector/CDVD emulation or game compatibility is added.
- Eject/unreadable files return errors; a loaded executable does not retain disc data for guest CDVD access.

## Build 016 changes
- Simplified memory/clock labels: app memory limit, free for new allocations, app RAM used (heap only), set aside for OS, GPU speed.
- Measurements, colours, percentage denominators and unsupported fields unchanged.

## Build 015 changes
- Clock information now appears on the CPU/GPU memory pages. Separate Clocks page removed.
- GPU page header includes GCM-reported core and VRAM clocks; CPU page identifies unavailable core-clock measurement.
- Left/Right or L1/R1 switches between only CPU RAM and GPU VRAM.

## Build 014 changes
- Memory Details includes a third Clocks page: CPU RAM / GPU VRAM / Clocks, via Left/Right or L1/R1.
- GPU core and VRAM frequencies come from GCM configuration (Hz converted to MHz); no fixed frequency fallback. These are reported configuration values, not live measurements, and may not reflect CFW overclocks.
- CPU-core frequency remains unavailable; timebase frequency is not substituted for core frequency.
- No clock changes, register writes or firmware changes.

## Build 013 changes
- Memory Details now has CPU RAM and GPU VRAM pages; Left/Right or L1/R1 changes page.
- Categories use distinct text colours: white total, green free/unassigned, cyan app, orange OS used, purple OS reserve.
- Percentages refer explicitly to runtime app-accessible capacity, not unknown physical totals. Values use binary MiB (1,048,576 bytes).
- Heap-only app usage, exact allocator-free limitations and unavailable physical/OS-reserve figures remain explicitly identified. No guessed OS usage or fixed physical-total fallback.

## Build 012 changes
- Memory Details page separates heap used/free/arena, runtime user-pool total/free, requested VRAM bytes, runtime VRAM capacity and unassigned capacity before overhead.
- Heap values come from supplied newlib mallinfo; heap usage excludes code, stacks and direct system allocations. Heap free is reusable allocator space, not all remaining RAM.
- HUD now identifies RAM HEAP used/free.
- OS reserve total/used/free and exact RSX allocator free blocks are explicitly unavailable. No physical-memory constants are used as fallback or to infer OS usage.
- Reviewed PS3MAPI memory opcodes (Mamba core header/server) and RPCS3 user-memory syscall semantics; no supported OS-reserve usage query identified in those interfaces. No kernel-address guessing or firmware modifications.

## Build 011 changes
- VRAM capacity uses validated returned GCM configuration data instead of requiring a zero return value. Matches the configuration consumption in the supplied librsx allocator.
- Missing, implausible, or smaller-than-tracked capacity still displays TOTAL N/A. No guessed capacity is displayed.

## Build 010 changes
- Live UI FPS and average frame interval from successful display submissions over one-second windows. Continuous retained redraw/flip allows an actual UI FPS measurement while idle. This is not guest PS2 FPS.
- RAM SYS is used/total PS3 user-memory pool reported by syscall 352 (allocator reservations, not exact process working set).
- VRAM APP is tracked bytes requested by this app via RSX allocations, alongside GCM local memory capacity. Excludes allocator overhead and other system allocations.
- Memory readings refresh once per second; failures display N/A. Plain text/dirty rows retained.

## Build 009 changes
- UI loop sleeps only the remainder of a 16,667 us frame budget, including input, drawing and upload time. Over-budget frames get no additional sleep.
- Idle input polling stays bounded; guest execution/timer behavior is unchanged.
- Target is approximately 60 loop iterations per second, not a guaranteed display refresh or emulator speed.

## Build 008 changes
- Retains text separately for both display buffers. Only changed text is cleared/redrawn; screen layout changes trigger a full clear.
- Uploads only scanlines affected by changed text; retains flip-completion ownership checks.
- Benchmark and timing report remain available for a direct 1080p comparison.
- Speed on PS3 remains unmeasured.

## Build 007 changes
- LAST FRAME US shows previous redraw timing: flip wait, CPU drawing, framebuffer copy, flip submission. Static menus do not continuously redraw; these numbers are not idle FPS.
- RUN UI TIMING TEST renders 60 frames with guest execution paused and saves USRDIR/ui-timing.txt, with per-stage averages/maxima and total elapsed time (including loop/input/sleep overhead). Circle cancels.
- Full framebuffer copy retained for measurement; no speed claim.

## Build 006 changes
- Plain white text on black on every screen, with a > selection marker.
- Wallpaper, panels, gradients, rounded boxes and button-icon rendering removed from active UI.
- Settings, browser, CPU controls and trace reports retained.
- PS3 responsiveness is unverified; there is no FPS claim.

## Build 005 changes
- Software HUD draws into cached PPU RAM, then uploads the completed frame to RSX scanout. Alpha blending no longer reads RSX local memory.
- Idle menus retain the displayed frame and poll input; they do not continuously redraw.
- Hardware speed improvement is unmeasured until PS3 testing.

## Build 004 changes
- Config updates use backup-and-replace on filesystems refusing overwrite.
- Failed config replacement restores the old config where possible; errors name the failed operation and errno.
- Emulation changes remain as in Build 003; Compare writes still stop explicitly.

## Build 003 changes
- CP0 Count writes accepted (low 32 bits); timed reads still stop explicitly.
- Trace save errors identify the failing operation and errno.
- On no-overwrite rename errors, the existing report is backed up to `.previous` before installation; failed installation attempts restoration. If restoration fails, the old report remains at `.previous`.

## Build 002 additions
- HI/LO multiply/divide, 64-bit shifts and LD/SD, additional conditional and likely branches.
- Limited CP0 register transfers and ERET; unsupported operations stop explicitly.
- Last 64 instruction attempts, stop/access context, and CP0/HI/LO diagnostics.
- Select on CPU diagnostics saves `last-trace.txt`; Left/Right switches diagnostic pages.
- Second built-in system test: expected `SYSTEM TEST PASS`, R10=21, R11=21, PC=00100038, 13 completed instructions.

## Not implemented
IOP, VU0/VU1, full CP0, guest exception delivery, complete MMU, DMA, GS rendering, SPU2 sound, complete R5900
remaining R5900/MMI instructions, BIOS boot, ELF SDK syscalls, game compatibility,
CDVD/ISO execution, physical discs, memory-card protocols, virtual HDD emulation,
DEV9/SMAP Ethernet, USB controller/device emulation, or guest pad/SIO2 emulation.
The PS3 controller currently operates the UI only. Device-image settings are
reserved paths; selecting them does not activate hardware emulation.
No Sony `ps2_netemu`, dynarec, firmware patch, BIOS or game content is included.

## Install and test
Install `PS2-PS3-Bringup-033.pkg` using your CFW package manager. Launch
**PS2 CPU Bring-up 033 (Experimental)**. Select **Run built-in CPU test**.
Expected: `CPU TEST PASS: R10=12 R11=42, delay slot correct`.
This checks the compiled CPU harness on your PPU; it does not test BIOS boot.
The signed SELF is supplied for homebrew loading; the PKG is the convenient route.
The unsigned host executable is the PowerPC `.elf`. `SMOKE.ELF` is a separate
little-endian MIPS guest executable, included in the installed USRDIR and source.

Controls:
- Up/Down: select; X: activate; Circle: back; Start: exit to XMB.
- File browser: X opens directory/selects file; Circle goes up; Select cancels;
  Left/Right switches mounted HDD/USB; L1/R1 moves ten entries.
- Host-directory picker: Triangle enters a directory; X chooses current directory.
- Settings: X picks a file/path or cycles instruction batch 1/100/1000/10000.
- CPU status: Square steps; X executes a bounded batch; Triangle runs/pauses;
  Circle pauses and returns. A stopped guest must be reloaded before restarting.

Configuration: `/dev_hdd0/game/P2E000001/USRDIR/config.ini`.
Last stop/register report: `/dev_hdd0/game/P2E000001/USRDIR/last-trace.txt`.
Selected BIOS, ELF, ISO, memory card and HDD images are never modified.
Save failures remain visible; new values stay in memory. Invalid existing config
loads defaults and is preserved until the next explicit settings change.
Browser currently enumerates up to 512 entries per directory; shorten large lists.

## Instruction subset
SLL, SRL, SRA, SLLV, SRLV; JR, JALR, J, JAL, BEQ, BNE;
ADDU, SUBU, DADDU, DSUBU, ADDIU, DADDIU;
AND, OR, XOR, NOR, SLT, SLTU, SLTI, SLTIU, ANDI, ORI, XORI, LUI;
LB, LBU, LH, LHU, LW, LWU, SB, SH, SW.
NOP executes as SLL zero. BREAK stops the harness; it does not deliver a PS2
exception. Branch-in-delay-slot stops. This is NOT a complete R5900 interpreter.
No cycle-accurate scheduling or device behavior is implied. CP0 support includes selected register transfers, ERET and partial TLB operations; timer/interrupt/guest exception delivery and complete MMU/cache behavior remain missing.

## Build
Use the supplied full PSL1GHT/GCC 7.2 toolchain. Its extracted `ps3dev` directory
contains `ppu_rules` directly, so both PS3DEV and PSL1GHT point to that directory:

```sh
export PS3DEV=/absolute/path/to/ps3dev
export PSL1GHT="$PS3DEV"
python3 tools/make_smoke.py
make
make pkg
bash tests/run_all.sh
```

Outputs: `ps2emu_bringup_033.elf`, `.self`, `.pkg`, `.gnpdrm.pkg`.
The distributed `PS2-PS3-Bringup-033.pkg` is the finalized `.gnpdrm.pkg` output.
A tool-generated `.fake.self` is not the signed deliverable.

Optional HUD layout test: `python3 tests/render_ui.py` (C++ compiler and Pillow).
It renders the production software drawing functions on the host at 480p, 576p,
720p and 1080p, without exercising RSX, PS3 pad input or installation.

## Provenance and core-port investigation
UI source came from the supplied `ps3psu_manager_icn_rsx_cpu_only_transitions.zip`.
The retained archive identified itself as v0.01; it is not asserted to be v1.64.
MIT license retained. Upstream README is archived under docs/upstream and its
controls do NOT apply to this program. Unused PSU/icon support remains in the
source baseline; old mutation controls are not reachable in this application's UI.

PCSX2's Interpreter.cpp was inspected (blob 4faad6c99691f2d4c11f8f1953efdd4e5eda6a64):
https://github.com/PCSX2/pcsx2/blob/master/pcsx2/Interpreter.cpp
It depends on Common, opcode tables, VMManager, cache and debug infrastructure.
The inspected CMakeLists declares C++17. No PCSX2 code was copied into this build.
A complete core port remains future work. Play!'s external-BIOS limitation makes
it unsuitable as-is for the requested BIOS execution. The current harness does
not resolve the performance or compatibility questions of either port.

See TEST-REPORT.txt for evidence and untested areas.
