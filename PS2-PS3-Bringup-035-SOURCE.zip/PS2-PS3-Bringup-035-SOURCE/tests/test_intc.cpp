#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;
 setup(c,{0x8c620000,I(43,3,4,0),I(35,3,2,0),I(43,3,4,0),I(35,3,2,0)});c.reg[3]=0xb000f010;c.reg[4]=0xffff0005;assert(c.step()&&c.reg[2]==0);assert(c.step()&&c.step()&&c.reg[2]==5);assert(c.step()&&c.step()&&c.reg[2]==0);
 setup(c,{I(43,3,4,0),I(35,3,2,0)});c.reg[3]=0xb000f000;c.reg[4]=5;c.intc_stat=15;assert(c.step()&&c.step()&&c.reg[2]==10&&c.intc_mask==0);
 for(unsigned base:{0x1000f010u,0x9000f010u,0xb000f010u}){setup(c,{I(43,3,4,0),I(35,3,2,0)});c.reg[3]=base;c.reg[4]=0xffff;assert(c.step()&&c.step()&&c.reg[2]==0xffff);}
 for(unsigned a:{0xb000f000u,0xb000f010u})for(unsigned op:{32u,33u,55u,40u,41u,63u}){setup(c,{I(op,3,4,0)});c.reg[3]=a;c.intc_stat=15;c.intc_mask=5;assert(!c.step()&&c.intc_stat==15&&c.intc_mask==5);}
 setup(c,{I(43,3,4,1)});c.reg[3]=0xb000f010;assert(!c.step()&&c.intc_mask==0);
 setup(c,{I(35,3,2,4)});c.reg[3]=0xb000f010;assert(!c.step());
 setup(c,{0});c.pc=0xb000f010;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);
 setup(c,{I(43,3,4,0)});c.reg[3]=0x400010;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x4003c3,0x400403));assert(!c.step()&&c.intc_mask==0);
 setup(c,{0x10000002,I(43,3,4,0),0x24020001,I(35,3,2,0)});c.reg[3]=0xb000f010;c.reg[4]=5;assert(c.step()&&c.step()&&c.step()&&c.reg[2]==5);
 setup(c,{0});assert(c.intc_stat==0&&c.intc_mask==0);
 puts("PASS: INTC BIOS read and mask toggle");}
