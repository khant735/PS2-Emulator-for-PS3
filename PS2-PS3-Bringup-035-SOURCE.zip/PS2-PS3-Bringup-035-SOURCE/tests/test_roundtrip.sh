#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cc -std=c11 -Wall -Wextra -I"$ROOT/include" "$ROOT/source/psu.c" "$ROOT/tools/psucli.c" -o "$TMP/psucli"
mkdir "$TMP/in"; printf 'hello psu\n' > "$TMP/in/icon.sys"; dd if=/dev/zero of="$TMP/in/data.bin" bs=1 count=1500 status=none
"$TMP/psucli" create "$TMP/in" "$TMP/test.psu" BASLUS-TEST
"$TMP/psucli" list "$TMP/test.psu"
mkdir "$TMP/out"; "$TMP/psucli" extract "$TMP/test.psu" "$TMP/out"
cmp "$TMP/in/icon.sys" "$TMP/out/icon.sys"; cmp "$TMP/in/data.bin" "$TMP/out/data.bin"
printf 'replacement\n' > "$TMP/new.bin"; "$TMP/psucli" add "$TMP/test.psu" "$TMP/new.bin" data.bin
rm -rf "$TMP/out"; mkdir "$TMP/out"; "$TMP/psucli" extract "$TMP/test.psu" "$TMP/out"; cmp "$TMP/new.bin" "$TMP/out/data.bin"
"$TMP/psucli" del "$TMP/test.psu" data.bin
! "$TMP/psucli" list "$TMP/test.psu" | grep -q 'data.bin'
"$TMP/psucli" blank "$TMP/blank.psu" BLANK
BLANK_LIST="$("$TMP/psucli" list "$TMP/blank.psu")"
! printf '%s\n' "$BLANK_LIST" | grep -q ' F  '
echo PASS
