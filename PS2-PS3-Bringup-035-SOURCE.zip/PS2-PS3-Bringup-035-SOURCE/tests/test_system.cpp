#include "emu_core.h"
#include "system_elf.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <unistd.h>
static unsigned R(unsigned rs,unsigned rt,unsigned rd,unsigned sh,unsigned fn){return rs<<21|rt<<16|rd<<11|sh<<6|fn;}
static unsigned I(unsigned op,unsigned rs,unsigned rt,int imm){return op<<26|rs<<21|rt<<16|(unsigned(imm)&65535);}
static unsigned CP(unsigned rs,unsigned rt,unsigned rd){return 16u<<26|rs<<21|rt<<16|rd<<11;}
static void setup(Core&c,std::initializer_list<unsigned>w){
 std::vector<unsigned char>rom(4*1024*1024);size_t a=0;
 for(unsigned x:w){for(unsigned i=0;i<4;i++)rom[a++]=(x>>(8*i))&255;}
 assert(c.loadBios(rom.data(),rom.size()));
}
int main(){
 Core c;
 setup(c,{CP(0,8,15),CP(0,9,12)});
 assert(c.cp0[12]==0x70400004&&c.cp0[16]==0x440&&c.cp0[15]==0x2e20);
 assert(c.step()&&c.reg[8]==0x2e20);assert(c.step()&&c.reg[9]==(0x70400004&0xf0c79c1f));
 setup(c,{CP(4,8,16),CP(0,9,16)});c.reg[8]=0xffffffff;assert(c.step());assert(c.step());assert(c.reg[9]==0xfffffffffffff47full); // Config fixed cache sizes
 setup(c,{CP(4,8,12),CP(0,9,12)});c.reg[8]=0xffffffff;assert(c.step()&&c.step());assert(c.reg[9]==0xfffffffff0c79c1full);
 setup(c,{CP(4,8,9),CP(0,9,9)});c.reg[8]=0x123456789ull;assert(c.step()&&c.cp0[9]==0x23456789);assert(!c.step()&&c.stop==Core::UNSUPPORTED); // Count writes allowed; timed reads still stop
 // BIOS opcode at BFC00824: MTC0 k0, Compare. Preserve unrelated CP0 state.
 setup(c,{0x409a5800,CP(0,8,11),CP(0,0,11)});c.reg[26]=0x1234567880000001ull;c.cp0[9]=123;c.cp0[13]=0xdeadbeef;
 assert(c.step()&&c.cp0[11]==0x80000001&&c.cp0[9]==123&&c.cp0[13]==0xdeadbeef);
 assert(c.step()&&c.reg[8]==0xffffffff80000001ull);assert(c.step()&&c.reg[0]==0);
 setup(c,{CP(4,0,11),CP(0,8,11)});c.cp0[11]=~0u;assert(c.step()&&c.cp0[11]==0);assert(c.step()&&c.reg[8]==0);
 setup(c,{CP(4,8,11),CP(4,8,11),CP(0,9,9)});c.reg[8]=42;c.cp0[9]=42;
 assert(c.step()&&c.step()&&c.cp0[11]==42&&c.cp0[9]==42);assert(!c.step()&&c.stop==Core::UNSUPPORTED);
 setup(c,{0x42000002});assert(c.step()); // TLBWI of an invalid (V=0) entry
 setup(c,{0x42000018});c.cp0[30]=0x1000;assert(c.step()&&c.pc==0x1000&&c.next==0x1004&&!(c.cp0[12]&4));
 setup(c,{0x42000018});c.cp0[12]=2;c.cp0[14]=0x2000;assert(c.step()&&c.pc==0x2000&&!(c.cp0[12]&2));
 setup(c,{R(0,8,9,0,0x3c),R(0,8,10,0,0x3f)});c.reg[8]=0x80000001;assert(c.step()&&c.reg[9]==0x8000000100000000ull);assert(c.step()&&c.reg[10]==0);
 setup(c,{R(9,8,10,0,0x17)});c.reg[8]=0x8000000000000000ull;c.reg[9]=63;assert(c.step()&&c.reg[10]==~0ull);
 setup(c,{R(8,9,10,0,0x18),R(0,0,11,0,0x10),R(0,0,12,0,0x12)});c.reg[8]=uint64_t(-7ll);c.reg[9]=3;
 assert(c.step()&&c.lo==0xffffffffffffffebull&&c.hi==~0ull&&c.reg[10]==c.lo);assert(c.step()&&c.reg[11]==c.hi);assert(c.step()&&c.reg[12]==c.lo);
 setup(c,{R(8,9,0,0,0x1a)});c.reg[8]=uint64_t(-7ll);c.reg[9]=3;assert(c.step()&&c.lo==uint64_t(-2ll)&&c.hi==~0ull);
 setup(c,{R(8,9,0,0,0x1a)});c.reg[8]=0x80000000;c.reg[9]=0xffffffff;assert(c.step()&&c.lo==0xffffffff80000000ull&&c.hi==0);
 setup(c,{R(8,9,0,0,0x1a)});c.reg[8]=uint64_t(-7ll);c.reg[9]=0;assert(c.step()&&c.lo==1&&c.hi==uint64_t(-7ll));
 setup(c,{R(8,9,0,0,0x1b)});c.reg[8]=0xffffffff;c.reg[9]=0;assert(c.step()&&c.lo==~0ull&&c.hi==~0ull);
 // Branch likely false must annul the unsupported delay-slot instruction.
 setup(c,{I(20,8,9,2),0xffffffff,I(9,0,10,42)});c.reg[8]=1;c.reg[9]=2;
 assert(c.step()&&c.pc==0xbfc00008&&c.instructions==1);assert(c.step()&&c.reg[10]==42);
 setup(c,{I(1,8,0,2),I(9,0,9,42),I(9,0,9,99),0});c.reg[8]=~0ull;
 assert(c.step()&&c.step()&&c.pc==0xbfc0000c&&c.reg[9]==42);
 setup(c,{I(7,8,0,2),0,0,0});c.reg[8]=1;assert(c.step()&&c.step()&&c.pc==0xbfc0000c);
 setup(c,{I(63,8,9,0),I(55,8,10,0)});c.reg[8]=0x1000;c.reg[9]=0x123456789abcdef0ull;assert(c.step()&&c.step()&&c.reg[10]==c.reg[9]);
 unsigned v;assert(c.read32(0x1000,v)&&v==0x9abcdef0&&c.read32(0x1004,v)&&v==0x12345678);
 setup(c,{I(4,0,0,1),I(35,8,9,0)});c.reg[8]=0x10000000;assert(c.step());assert(!c.step());
 assert(c.fault_address==0x10000000&&c.fault_size==4&&!c.fault_write&&!c.fault_fetch&&c.stopped_in_delay);
 assert(c.historyCount()==2);Core::Trace t;assert(c.historyAt(1,t)&&t.pc==0xbfc00004&&t.opcode==I(35,8,9,0)&&t.delay&&t.fetched);
 setup(c,{R(0,0,0,0,8),0});assert(c.step()&&c.step());assert(c.pc==0); // then manual invalid fetch
 c.pc=0x10000000;assert(!c.step()&&c.fault_fetch&&c.opcode==0);
 setup(c,{0});for(unsigned i=0;i<100;i++)assert(c.step());assert(c.historyCount()==64);assert(c.historyAt(0,t)&&t.pc==0xbfc00090);
 char path[128];snprintf(path,sizeof(path),"/tmp/ps2emu-trace-%d.txt",int(getpid()));assert(c.writeReport(path,"synthetic test"));FILE*f=fopen(path,"rb");assert(f);char text[20000]={0};assert(fread(text,1,sizeof(text)-1,f)>0);fclose(f);unlink(path);assert(strstr(text,"synthetic test")&&strstr(text,"CP0")&&strstr(text,"BFC00090"));
 assert(!c.writeReport("/no/such/directory/report.txt","test"));
 setup(c,{0});assert(c.historyCount()==0&&c.hi==0&&c.lo==0&&c.fault_size==0);
 setup(c,{R(8,9,10,0,25)});c.reg[8]=0xffffffff;c.reg[9]=2;assert(c.step()&&c.lo==0xfffffffffffffffeull&&c.hi==1&&c.reg[10]==c.lo);
 setup(c,{CP(4,8,15)});c.reg[8]=0;assert(!c.step()&&c.cp0[15]==0x2e20);
 setup(c,{I(4,0,0,1),0x42000018});unsigned status=c.cp0[12];assert(c.step());assert(!c.step()&&c.stop==Core::CONTROL&&c.cp0[12]==status);
 setup(c,{I(20,8,9,2),I(9,0,10,42),0,I(9,0,11,7)});c.reg[8]=c.reg[9]=1;assert(c.step()&&c.step()&&c.pc==0xbfc0000c&&c.reg[10]==42);
 setup(c,{I(1,8,2,1),0x48000000,0});c.reg[8]=0;assert(c.step()&&c.pc==0xbfc00008);assert(c.step());
 setup(c,{I(63,8,9,0)});c.reg[8]=0x1001;c.reg[9]=~0ull;assert(!c.step()&&c.fault_write&&c.fault_size==8);assert(c.read32(0x1000,v)&&v==0);
 setup(c,{I(43,8,9,0)});c.reg[8]=0xbfc00000;assert(!c.step()&&c.fault_write&&c.fault_address==0xbfc00000);
 assert(c.loadElf(system_elf,sizeof(system_elf)));for(unsigned i=0;i<100&&c.stop==Core::NONE;i++)c.step();
 assert(c.stop==Core::BREAKPOINT&&c.instructions==13&&c.pc==0x100038);
 assert(c.reg[10]==21&&c.reg[11]==21&&c.reg[12]==0x2e20&&c.reg[14]==0x1234&&c.reg[17]==0x700000000ull);
 puts("PASS: CP0 subset, ERET, shifts, HI/LO, branches, LD/SD, stop context, trace ring/report");
}
