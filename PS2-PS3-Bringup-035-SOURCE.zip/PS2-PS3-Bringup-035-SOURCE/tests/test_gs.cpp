#include "emu_core.h"
#include <cassert>
#include <vector>
#include <cstdio>
static unsigned I(unsigned op,unsigned rs,unsigned rt,int v){return op<<26|rs<<21|rt<<16|(v&65535);}
static void setup(Core&c,std::initializer_list<unsigned>w){std::vector<unsigned char>r(4*1024*1024);unsigned p=0;for(unsigned v:w)for(unsigned j=0;j<4;j++)r[p++]=(v>>(8*j))&255;assert(c.loadBios(r.data(),r.size()));}
int main(){Core c;
 setup(c,{0xfc620000,I(55,3,4,0)});c.reg[3]=0x12001000;c.reg[2]=0x200;assert(c.step()&&c.step()&&c.reg[4]==0x551b4000);

 for(unsigned a:{0x12001000u,0x92001000u,0xb2001000u}){setup(c,{0xfc620000,I(35,3,4,0)});c.reg[3]=a;c.reg[2]=0x200;c.gs_csr|=31;c.gif_mode=5;c.gif_pause=8;assert(c.step()&&c.step()&&c.reg[4]==0x551b4000&&c.gs_resets==1&&c.gif_mode==5&&c.gif_pause==8);}
 setup(c,{I(43,3,2,0),I(55,3,4,0)});c.reg[3]=0xb2001000;c.reg[2]=5;c.gs_csr|=31;assert(c.step()&&c.step()&&c.reg[4]==0x551b401a);
 setup(c,{I(63,3,2,0),I(55,3,4,0)});c.reg[3]=0xb2001000;c.reg[2]=0xffffffff00000100ull;assert(c.step()&&c.step()&&c.reg[4]==0x551b4000&&c.gs_flushes==1&&c.gs_resets==0);
 setup(c,{I(43,3,2,4),I(35,3,4,4)});c.reg[3]=0xb2001000;c.reg[2]=~0ull;assert(c.step()&&c.step()&&c.reg[4]==0&&c.gs_resets==0&&c.gs_csr==0x551b4000);
 for(unsigned op:{32u,33u,40u,41u}){setup(c,{I(op,3,2,0)});c.reg[3]=0xb2001000;c.reg[2]=0x200;assert(!c.step()&&c.gs_resets==0);}
 setup(c,{I(63,3,2,4)});c.reg[3]=0xb2001000;c.reg[2]=0x200;assert(!c.step()&&c.gs_resets==0);
 setup(c,{I(63,3,2,16)});c.reg[3]=0xb2001000;assert(!c.step());
 setup(c,{0});c.pc=0xb2001000;c.next=c.pc+4;assert(!c.step()&&c.fault_fetch);
 setup(c,{0xfc620000});c.reg[3]=0x400000;c.reg[2]=0x200;c.cp0[12]=0;assert(c.tlb.put(0,0,0x400000,0x480043,0x480083));assert(!c.step()&&c.gs_resets==0);
 setup(c,{0x10000002,0xfc620000,0x24040001,I(55,3,4,0)});c.reg[3]=0xb2001000;c.reg[2]=0x200;assert(c.step()&&c.step()&&c.step()&&c.reg[4]==0x551b4000);
 setup(c,{0x3c031200,0x34631000,0x24020200,0xfc620000,0xdc640000,0x3c05bf80,0x34a5146e,0x90a60000,0x3c051200,0x34a50010,0xfca40000,0x0000000d});for(unsigned i=0;i<11;i++)assert(c.step());assert(!c.step()&&c.stop==Core::BREAKPOINT&&c.reg[4]==0x551b4000&&c.gs_resets==1);
 setup(c,{0});assert(c.gs_csr==0x551b4000&&c.gs_resets==0&&c.gs_flushes==0);
 puts("PASS: GS CSR exact BIOS reset / idle model status");}
