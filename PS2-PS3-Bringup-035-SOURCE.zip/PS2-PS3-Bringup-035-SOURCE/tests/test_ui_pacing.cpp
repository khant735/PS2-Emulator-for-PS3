#include "ui_pacing.h"
#include <assert.h>
#include <stdio.h>
int main(){
 assert(ui_sleep_us(100000,100000)==16667);
 assert(ui_sleep_us(100000,101626)==15041);
 assert(ui_sleep_us(100000,116666)==1);
 assert(ui_sleep_us(100000,116667)==0);
 assert(ui_sleep_us(100000,200000)==0);
 assert(ui_sleep_us(100000,99999)==0);
 assert(ui_sleep_us(0,~0ull)==0);
 puts("PASS: UI sleep uses remaining frame budget, skips over-budget frames and guards clock reversal");
}
