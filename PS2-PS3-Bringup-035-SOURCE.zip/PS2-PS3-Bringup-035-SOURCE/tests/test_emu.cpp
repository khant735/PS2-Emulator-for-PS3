#include "emu_core.h"
#include "emu_config.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <unistd.h>
static void put(std::vector<unsigned char>& b,size_t o,unsigned v){for(int k=0;k<4;k++)b[o+k]=(v>>(8*k))&255;}
static std::vector<unsigned char> elf(){
 std::vector<unsigned char>b(0x120,0); b[0]=127;b[1]='E';b[2]='L';b[3]='F';b[4]=1;b[5]=1;b[6]=1;
 b[16]=2;b[18]=8;put(b,20,1);put(b,24,0x100000);put(b,28,52);b[40]=52;b[42]=32;b[44]=1;
 put(b,52,1);put(b,56,0x100);put(b,60,0x100000);put(b,64,0x100000);put(b,68,32);put(b,72,64);put(b,76,5);put(b,80,16);
 // t0=5; t1=7; t2=12; branch skips the bad write but runs delay slot.
 unsigned w[]={0x24080005,0x24090007,0x01095021,0x114a0002,0x240b002a,0x240b0063,0x0000000d,0};
 for(int i=0;i<8;i++)put(b,0x100+4*i,w[i]);return b;
}
int main(){
 Core c; assert(c.ready()); std::vector<unsigned char>b=elf();
 assert(c.loadElf(&b[0],b.size())); for(int i=0;i<5;i++)assert(c.step());
 assert(c.reg[10]==12&&c.reg[11]==42&&c.pc==0x100018); assert(!c.step());assert(c.stop==Core::BREAKPOINT);
 assert(c.reg[0]==0); unsigned v=123;assert(c.read32(0x100020,v)&&v==0); // BSS
 unsigned oldpc=c.pc;put(b,68,0xfffffff0);assert(!c.loadElf(&b[0],b.size()));assert(c.pc==oldpc); // reject before mutation
 b=elf();b[5]=2;assert(!c.loadElf(&b[0],b.size()));
 b=elf();put(b,24,0x100040);assert(!c.loadElf(&b[0],b.size()));
 b=elf();put(b,0x100,0x48000000);assert(c.loadElf(&b[0],b.size()));assert(!c.step());assert(c.stop==Core::UNSUPPORTED&&c.pc==0x100000);
 b=elf();put(b,0x100,0x3c081000);put(b,0x104,0x8d090000);assert(c.loadElf(&b[0],b.size()));assert(c.step());assert(!c.step());assert(c.stop==Core::MEMORY);
 b=elf();put(b,0x100,0x2400ffff);assert(c.loadElf(&b[0],b.size()));assert(c.step());assert(c.reg[0]==0);
 b=elf();put(b,0x100,0x2408ffff);assert(c.loadElf(&b[0],b.size()));assert(c.step());assert(c.reg[8]==~(uint64_t)0);
 b=elf();put(b,0x100,0x14000002);assert(c.loadElf(&b[0],b.size()));assert(c.step());assert(c.step());assert(c.pc==0x100008); // not taken
 b=elf();put(b,0x100,0x3c080010);put(b,0x104,0x2409ffff);put(b,0x108,0xad090040);put(b,0x10c,0x8d0a0040);
 assert(c.loadElf(&b[0],b.size()));for(int i=0;i<4;i++)assert(c.step());assert(c.reg[10]==~(uint64_t)0);assert(c.read32(0x80100040,v)&&v==0xffffffff);
 std::vector<unsigned char>rom(4*1024*1024,0);put(rom,0,0x3c081234);
 assert(c.loadBios(&rom[0],rom.size()));assert(c.pc==0xbfc00000);assert(c.step());assert(c.reg[8]==0x12340000);assert(!c.write32(0xbfc00000,0));
 put(rom,0,0x0ff00008);assert(c.loadBios(&rom[0],rom.size()));assert(c.step());assert(c.reg[31]==0xffffffffbfc00008ull); // JAL
 put(rom,0,0x0000f809);assert(c.loadBios(&rom[0],rom.size()));assert(c.step());assert(c.reg[31]==0xffffffffbfc00008ull); // JALR
 assert(!c.loadBios(&rom[0],16));
 Settings s,t;strcpy(s.bios,"/dev_hdd0/PS2/bios=a.bin");s.batch=1000;
 char path[128];snprintf(path,sizeof(path),"/tmp/ps2emu-settings-%d.ini",(int)getpid());
 assert(s.save(path));assert(t.load(path));assert(!strcmp(t.bios,s.bios)&&t.batch==1000);unlink(path);
 assert(!s.save("/path/that/does/not/exist/config.ini"));
 FILE*f=fopen(path,"w");assert(f);fputs("batch=999999999\nbios=relative\n",f);fclose(f);assert(!t.load(path));unlink(path);
 puts("PASS: ELF validation, integer execution, delay slots, memory protection, BIOS mapping, config persistence");
}
