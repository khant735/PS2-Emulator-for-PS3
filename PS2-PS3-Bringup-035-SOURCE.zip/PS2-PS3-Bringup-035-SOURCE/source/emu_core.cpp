#include "emu_core.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
static const size_t RAM=32*1024*1024, ROM=4*1024*1024, SCRATCH=16*1024, IOP_RAM=2*1024*1024;
static uint32_t le32(const unsigned char*p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
static unsigned le16(const unsigned char*p){return p[0]|(unsigned(p[1])<<8);}
static uint64_t sx32(uint32_t x){return (x&0x80000000u)?(0xffffffff00000000ull|x):x;}
static uint64_t sx16(uint32_t x){x&=65535;return x&32768?0xffffffffffff0000ull|x:x;}
static uint32_t phys(uint32_t a){return a>=0x80000000u&&a<0xc0000000u?a&0x1fffffffu:a;}
static bool ramRange(uint32_t a,uint32_t n){a=phys(a);return a<RAM&&n<=RAM-a;}
Core::Core():ram((unsigned char*)calloc(1,RAM)),rom((unsigned char*)calloc(1,ROM)),scratch((unsigned char*)calloc(1,SCRATCH)),iop_ram((unsigned char*)calloc(1,IOP_RAM)){reset(0);}
Core::~Core(){free(ram);free(rom);free(scratch);free(iop_ram);}
bool Core::ready()const{return ram&&rom&&scratch&&iop_ram;}
void Core::reset(uint32_t entry){
 memset(reg,0,sizeof(reg));memset(reg_hi,0,sizeof(reg_hi));memset(cp0,0,sizeof(cp0));memset(fpr,0,sizeof(fpr));tlb.clear();translation_error[0]=0;translated_scratch=instruction_fetch=false;cp0[1]=47;
 cp0[12]=0x70400004;cp0[15]=0x00002e20;cp0[16]=0x440;
 ee_f500=ee_f500_last_write=0;ee_f500_known=false;ee_f500_reads=ee_f500_writes=0;
 memset(serial_tx,0,sizeof(serial_tx));serial_tx_size=0;serial_tx_total=serial_status_reads=0;
 intc_stat=intc_mask=0;dve.reset();gif_mode=gif_pause=0;gif_resets=0;gs_csr=0x551b4000u;gs_resets=gs_flushes=0;iop_probe_reads=0;memset(gs_video,0,sizeof(gs_video));gs_video_writes=0;
 hi=lo=0;pc=entry;next=entry+4;instructions=0;opcode=0;stop=NONE;delay=false;error[0]=0;report_error[0]=0;
 fault_address=0;fault_size=0;fault_write=fault_fetch=stopped_in_delay=false;
 history_head=history_count=0;memset(history,0,sizeof(history));
}
bool Core::fail(const char*s){snprintf(error,sizeof(error),"%s",s);return false;}
bool Core::translate(uint32_t a,size_t n,bool wr,uint32_t&physical){
 translation_error[0]=0;translated_scratch=false;
 unsigned mode=(cp0[12]&6)?0:((cp0[12]>>3)&3);
 if((mode>=2&&a>=0x80000000u)||(mode==1&&((a>=0x80000000u&&a<0xc0000000u)||a>=0xe0000000u))){strcpy(translation_error,"address privilege denied");return false;}
 if(uint64_t(a)+n>0x100000000ull){strcpy(translation_error,"address range wraps");return false;}
 if(a>=0x80000000u&&a<0xc0000000u){physical=a&0x1fffffffu;return true;}
 // MIPS ERL grants direct access to low addresses during reset/ELF bring-up.
 if(a<0x80000000u&&(cp0[12]&4)){physical=a;
  if(a>=0x70000000u&&a<0x70004000u){translated_scratch=true;physical=a-0x70000000u;}return true;}
 const char*why=tlb.map(a,n,cp0[10]&255,wr,physical,translated_scratch);
 if(why){snprintf(translation_error,sizeof(translation_error),"%s",why);return false;}return true;
}
unsigned char* Core::address(uint32_t a,size_t n,bool wr){
 if(!ready())return NULL;
 uint32_t physical;if(!translate(a,n,wr,physical))return NULL;a=physical;
 if(translated_scratch){if(instruction_fetch){strcpy(translation_error,"scratchpad instruction fetch unsupported");return NULL;}return a<SCRATCH&&n<=SCRATCH-a?scratch+a:NULL;}
 if(a<RAM&&n<=RAM-a)return ram+a;
 // EE physical 1C000000..1C7FFFFF mirrors the IOP's 2 MiB main RAM.
 if(a>=0x1c000000u&&a<0x1c800000u){size_t off=(a-0x1c000000u)&(IOP_RAM-1);return n<=IOP_RAM-off?iop_ram+off:NULL;}

 if(!wr&&a>=0x1fc00000u&&a<0x20000000u){size_t off=a-0x1fc00000u;return n<=ROM-off?rom+off:NULL;}
 return NULL;
}
bool Core::read32(uint32_t a,uint32_t&v){unsigned char*p=address(a,4,false);if((a&3)||!p)return false;v=le32(p);return true;}
bool Core::write32(uint32_t a,uint32_t v){unsigned char*p=address(a,4,true);if((a&3)||!p)return false;for(int i=0;i<4;i++)p[i]=(v>>(8*i))&255;return true;}
// Explicit MMIO subset. Width/address whitelists are per device.
bool Core::mmioRead(uint32_t a,unsigned size,uint64_t&v){
 uint32_t p;if((size!=1&&size!=2&&size!=4&&size!=8)||(a&(size-1))||!translate(a,size,false,p))return false;
 // Exact unknown IOP probe only: compatibility value, not verified hardware.
 if(size==1&&p==0x1f80146eu){v=0;iop_probe_reads++;return true;}
 if((size==4||size==8)&&p==0x12001000u){v=gs_csr;return true;}
 if(size==4&&p==0x12001004u){v=0;return true;}
 if(p>=0x1a000000u&&p<=0x1a000012u)return size==2&&dve.read(p-0x1a000000u,v);
 if(size!=4)return false;
 if(p==0x10003020u){v=gif_mode|gif_pause;return true;}
 if(p==0x1000f000u){v=intc_stat;return true;}
 if(p==0x1000f010u){v=intc_mask;return true;}
 // Disconnected debug-serial approximation, matching PCSX2's zero SIO_ISR.
 if(p==0x1000f130u){v=0;serial_status_reads++;return true;}
 if(p!=0x1000f500u||!ee_f500_known)return false;
 v=ee_f500;ee_f500_reads++;return true;
}
bool Core::mmioWrite(uint32_t a,unsigned size,uint64_t v){
 uint32_t p;if((size!=1&&size!=2&&size!=4&&size!=8)||(a&(size-1))||!translate(a,size,true,p))return false;
 // Record the low-page privileged video registers; no display side effects.
 if(p>=0x12000000u&&p<=0x120000e4u){
  unsigned off=p-0x12000000u,index=off/16,lane=off%16;
  if(index>=15||!((size==8&&lane==0)||(size==4&&(lane==0||lane==4))))return false;
  if(size==8)gs_video[index]=v;
  else if(lane==0)gs_video[index]=(gs_video[index]&0xffffffff00000000ull)|uint32_t(v);
  else gs_video[index]=(gs_video[index]&0xffffffffull)|(uint64_t(uint32_t(v))<<32);
  gs_video_writes++;return true;
 }
 if((size==4||size==8)&&p==0x12001000u){
  if(v&0x200){gs_csr=0x551b4000u;memset(gs_video,0,sizeof(gs_video));gs_resets++;}
  if(v&0x100)gs_flushes++; // No GS FIFO exists in this bring-up model.
  gs_csr&=~(uint32_t(v)&31);return true;
 }
 if(size==4&&p==0x12001004u)return true; // Upper CSR bits are read-only zero.
 if(p>=0x1a000000u&&p<=0x1a000012u)return size==2&&dve.write(p-0x1a000000u,uint16_t(v));
 if(p==0x1000f180u&&size==1){
  if(serial_tx_size<sizeof(serial_tx))serial_tx[serial_tx_size++]=uint8_t(v);
  serial_tx_total++;return true;
 }
 if(size==4&&p==0x10003000u){
  if(v&1){gif_mode=gif_pause=0;gif_resets++;}else gif_pause=uint32_t(v)&8;
  return true;
 }
 if(size==4&&p==0x10003010u){gif_mode=uint32_t(v)&5;return true;}
 if(size==4&&p==0x1000f000u){intc_stat&=~uint32_t(v);return true;}
 if(size==4&&p==0x1000f010u){intc_mask^=uint32_t(v)&0xffffu;return true;}
 if(size!=4||p!=0x1000f500u)return false;
 ee_f500_last_write=uint32_t(v);ee_f500=uint32_t(v)&3u;ee_f500_known=true;ee_f500_writes++;return true;
}
bool Core::loadBios(const unsigned char*b,size_t n){
 if(!ready())return fail("Cannot allocate guest memory");
 if(!b||n!=ROM)return fail("Expected a raw 4 MiB PS2 ROM0 dump");
 memcpy(rom,b,ROM);memset(ram,0,RAM);memset(scratch,0,SCRATCH);memset(iop_ram,0,IOP_RAM);reset(0xbfc00000u);return true;
}
bool Core::loadElf(const unsigned char*b,size_t n){
 if(!ready())return fail("Cannot allocate guest memory");
 if(!b||n<52||memcmp(b,"\177ELF",4)||b[4]!=1||b[5]!=1||b[6]!=1||le16(b+16)!=2||le16(b+18)!=8||le32(b+20)!=1||le16(b+40)!=52)
  return fail("Expected ELF32 little-endian MIPS executable");
 uint32_t entry=le32(b+24),ph=le32(b+28);unsigned count=le16(b+44),stride=le16(b+42);
 if(!count||count>128||stride!=32||ph>n||size_t(count)*32>n-ph||(entry&3))return fail("Invalid ELF program-header table or entry");
 bool entryOK=false;unsigned loads=0;
 for(unsigned i=0;i<count;i++){
  const unsigned char*p=b+ph+i*32;if(le32(p)!=1)continue;loads++;
  uint32_t off=le32(p+4),v=le32(p+8),fs=le32(p+16),ms=le32(p+20),align=le32(p+28);
  if(fs>ms||off>n||fs>n-off||!ramRange(v,ms))return fail("ELF segment outside file or guest RAM");
  if(align>1&&((align&(align-1))||((v-off)&(align-1))))return fail("Invalid ELF segment alignment");
  if((le32(p+24)&1)&&entry>=v&&uint64_t(entry)+4<=uint64_t(v)+fs)entryOK=true;
  for(unsigned j=0;j<i;j++){const unsigned char*q=b+ph+j*32;if(le32(q)!=1)continue;uint32_t a=phys(v),c=phys(le32(q+8)),s=le32(q+20);
   if(ms&&s&&uint64_t(a)<uint64_t(c)+s&&uint64_t(c)<uint64_t(a)+ms)return fail("Overlapping ELF load segments unsupported");}
 }
 if(!loads||!entryOK)return fail("ELF entry must be inside executable file data");
 memset(ram,0,RAM);memset(scratch,0,SCRATCH);memset(iop_ram,0,IOP_RAM);memset(rom,0,ROM);
 for(unsigned i=0;i<count;i++){const unsigned char*p=b+ph+i*32;if(le32(p)==1)memcpy(ram+phys(le32(p+8)),b+le32(p+4),le32(p+16));}
 reset(entry);return true;
}
const char*Core::reason()const{
 switch(stop){case NONE:return "PAUSED / READY";case BREAKPOINT:return "BREAK instruction";case UNSUPPORTED:return "Unsupported instruction";case MEMORY:return "Unmapped, MMIO or unaligned access";case CONTROL:return "Branch in delay slot unsupported";}return "Unknown";
}
unsigned Core::historyCount()const{return history_count;}
bool Core::historyAt(unsigned index,Trace& out)const{
 if(index>=history_count)return false;
 out=history[(history_head+64-history_count+index)%64];return true;
}
bool Core::halt(Stop why,const char* detail){
 stop=why;stopped_in_delay=delay;snprintf(error,sizeof(error),"%s",detail);return false;
}
bool Core::memoryHalt(uint32_t a,unsigned size,bool wr,bool fetch){
 fault_address=a;fault_size=size;fault_write=wr;fault_fetch=fetch;
 char msg[160];const char*why=(a&(size-1))?"unaligned":translation_error[0]?translation_error:"unmapped/MMIO/ROM write";snprintf(msg,sizeof(msg),"%s %u-byte access at %08X (%s)",fetch?"FETCH":wr?"WRITE":"READ",size,a,why);if(translation_error[0]||(a&(size-1)))cp0[8]=a;
 if(!strncmp(translation_error,"TLB ",4)){
  cp0[4]=(cp0[4]&0xff800000u)|((a>>9)&0x007ffff0u);
  cp0[10]=(cp0[10]&255)|(a&0xffffe000u);
 }
 return halt(MEMORY,msg);
}
bool Core::writeReport(const char* name,const char* guest)const{
 report_error[0]=0;
 auto failed=[this](const char*stage,int code){snprintf(report_error,sizeof(report_error),"Trace %s failed: errno %d (%s)",stage,code,strerror(code));return false;};
 if(!name||!guest)return failed("path",EINVAL);
 char temp[1152],backup[1152];int n=snprintf(temp,sizeof(temp),"%s.tmp",name);
 int m=snprintf(backup,sizeof(backup),"%s.previous",name);
 if(n<0||n>=(int)sizeof(temp)||m<0||m>=(int)sizeof(backup))return failed("path",ENAMETOOLONG);
 FILE*f=fopen(temp,"wb");if(!f)return failed("open",errno);
 fprintf(f,"PS2 PS3 experimental bring-up 033\nGuest: %s\nBIOS boot and game support unfinished\n",guest);
 fprintf(f,"PC=%08X NEXT=%08X OPCODE=%08X RETIRED=%llu\nSTOP=%s\nDETAIL=%s\nDELAY_SLOT=%u\n",pc,next,opcode,(unsigned long long)instructions,reason(),error,unsigned(stop!=NONE?stopped_in_delay:delay));
 if(fault_size)fprintf(f,"FAULT_ADDRESS=%08X SIZE=%u WRITE=%u FETCH=%u\n",fault_address,fault_size,unsigned(fault_write),unsigned(fault_fetch));
 fprintf(f,"HI=%016llX LO=%016llX\n",(unsigned long long)hi,(unsigned long long)lo);
 for(unsigned i=0;i<32;i++)fprintf(f,"F%02u=%08X\n",i,fpr[i]);
 for(unsigned i=0;i<32;i++){fprintf(f,"R%02u=%016llX\n",i,(unsigned long long)reg[i]);fprintf(f,"R%02u_UPPER=%016llX\n",i,(unsigned long long)reg_hi[i]);}
 fprintf(f,"Experimental F500 latch (DMA/TLB side effects unimplemented): known=%u value=%08X last_write=%08X reads=%llu writes=%llu\n",unsigned(ee_f500_known),ee_f500,ee_f500_last_write,(unsigned long long)ee_f500_reads,(unsigned long long)ee_f500_writes);
 fprintf(f,"Debug serial approximation: ISR=0, byte TX only; no RX/timing/interrupts\nStatus_reads=%llu TX_total=%llu TX_captured=%u TX_omitted=%llu\nSERIAL_OUTPUT_BEGIN\n",(unsigned long long)serial_status_reads,(unsigned long long)serial_tx_total,serial_tx_size,(unsigned long long)(serial_tx_total-serial_tx_size));
 for(unsigned i=0;i<serial_tx_size;i++){unsigned ch=serial_tx[i];if(ch=='\n'||ch=='\r'||ch=='\t'||(ch>=32&&ch<=126&&ch!='\\'))fputc(ch,f);else fprintf(f,"\\x%02X",ch);}
 fprintf(f,"\nSERIAL_OUTPUT_END\n");
 fprintf(f,"UNVERIFIED IOP probe compatibility fallback: 1F80146E byte read=00 USES=%llu; physical register meaning/value unknown\n",(unsigned long long)iop_probe_reads);
 fprintf(f,"GS CSR idle model (REV=1B ID=55 emulated; no events/rendering): CSR=%08X RESETS=%llu FLUSHES=%llu\n",gs_csr,(unsigned long long)gs_resets,(unsigned long long)gs_flushes);
 static const char*gs_names[]={"PMODE","SMODE1","SMODE2","SRFSH","SYNCH1","SYNCH2","SYNCV","DISPFB1","DISPLAY1","DISPFB2","DISPLAY2","EXTBUF","EXTDATA","EXTWRITE","BGCOLOR"};
 fprintf(f,"GS video write capture (no timing/scanout/rendering): WRITES=%llu\n",(unsigned long long)gs_video_writes);
 for(unsigned i=0;i<15;i++)fprintf(f,"GS_%s=%016llX\n",gs_names[i],(unsigned long long)gs_video[i]);
 fprintf(f,"GIF control subset (no packets/DMA/rendering): MODE=%08X PAUSE=%u STAT=%08X RESETS=%llu\n",gif_mode,unsigned(gif_pause!=0),gif_mode|gif_pause,(unsigned long long)gif_resets);
 if(iop_ram)fprintf(f,"IOP RAM: 2 MiB, 8 MiB mirrored EE window; IOP CPU not running\nIOP_RAM[000003C0]=%08X (raw RAM, no synthetic configuration)\n",le32(iop_ram+0x3c0));
 fprintf(f,"DVE experimental single-register bus: active=%u error=%u phase=%u commands=%llu reads=%llu writes=%llu\n",unsigned(dve.active),unsigned(dve.error),dve.phase,(unsigned long long)dve.commands,(unsigned long long)dve.reads,(unsigned long long)dve.writes);
 fprintf(f,"DVE_BUILD035_MODE42_UNSELECTED_COMPAT=%llu (experimental acknowledgement, no device data synthesized)\n",(unsigned long long)dve.compat_mode42_unselected);
 for(unsigned off=0;off<=18;off+=2)if(EeDve::valid(off))fprintf(f,"DVE_BUS[%02X]=%04X\n",off,dve.bus[off/2]);
 fprintf(f,"INTC register storage (no interrupt generation/delivery): STAT=%08X MASK=%08X\n",intc_stat,intc_mask);
 fprintf(f,"CP0 register storage (partial TLB; no timer/exception delivery):\n");
 for(unsigned i=0;i<32;i++)fprintf(f,"CP0[%02u]=%08X\n",i,cp0[i]);
 for(unsigned i=0;i<48;i++)if(tlb.entry[i].written){const EeTlb::Entry&e=tlb.entry[i];fprintf(f,"TLB[%02u] MASK=%08X HI=%08X LO0=%08X LO1=%08X\n",i,e.mask,e.hi,e.lo0,e.lo1);}
 fprintf(f,"Last %u instruction attempts, oldest first:\n",history_count);
 for(unsigned i=0;i<history_count;i++){Trace t;historyAt(i,t);fprintf(f,"%02u PC=%08X OP=%08X DELAY=%u FETCHED=%u\n",i,t.pc,t.opcode,unsigned(t.delay),unsigned(t.fetched));}
 int saved=ferror(f)?(errno?errno:EIO):0;const char*stage="write";
 if(fflush(f)&&!saved){saved=errno?errno:EIO;stage="flush";}
 if(fclose(f)&&!saved){saved=errno?errno:EIO;stage="close";}
 if(saved){remove(temp);return failed(stage,saved);}
 if(rename(temp,name)==0)return true;
 saved=errno;
 if(saved!=EEXIST&&saved!=ENOTEMPTY){remove(temp);return failed("rename",saved);}
 // Some host filesystems refuse replacement. Keep the previous report until
 // the completed temporary file is installed; never unlink the only copy.
 struct stat st;
 if(stat(name,&st)||!S_ISREG(st.st_mode)){remove(temp);return failed("destination",EINVAL);}
 if(stat(backup,&st)==0){remove(temp);return failed("backup exists",EEXIST);}
 if(errno!=ENOENT){saved=errno;remove(temp);return failed("backup check",saved);}
 if(rename(name,backup)){saved=errno;remove(temp);return failed("backup rename",saved);}
 if(rename(temp,name)){
  saved=errno;
  if(rename(backup,name)){remove(temp);return failed("restore; old trace in .previous",errno);}
  remove(temp);return failed("install; old trace restored",saved);
 }
 remove(backup);return true;
}
static uint64_t sar64(uint64_t v,unsigned sh){
 sh&=63;return sh&&(v>>63)?(v>>sh)|(~uint64_t(0)<<(64-sh)):v>>sh;
}
static uint64_t sar32(uint64_t v,unsigned sh){
 uint32_t w=uint32_t(v);sh&=31;return sx32(sh&&(w>>31)?(w>>sh)|(~uint32_t(0)<<(32-sh)):w>>sh);
}
static bool signedLess(uint64_t a,uint64_t b){return (a^0x8000000000000000ull)<(b^0x8000000000000000ull);}
static int64_t signedWord(uint64_t x){uint32_t v=uint32_t(x);return v&0x80000000u?int64_t(v)-0x100000000ll:int64_t(v);}
static bool cp0Readable(unsigned rd){return rd<=6||rd==8||rd==10||rd==11||rd==12||rd==14||rd==15||rd==16||rd==30;}
static bool cp0Writable(unsigned rd){return rd==0||rd==2||rd==3||rd==4||rd==5||rd==6||rd==9||rd==10||rd==11||rd==12||rd==14||rd==16||rd==30;}
bool Core::step(){
 if(stop!=NONE)return false;
 opcode=0;
 instruction_fetch=true;bool fetched=read32(pc,opcode);instruction_fetch=false;
 Trace &attempt=history[history_head];attempt.pc=pc;attempt.opcode=opcode;attempt.delay=delay;attempt.fetched=fetched;
 history_head=(history_head+1)%64;if(history_count<64)history_count++;
 if(!fetched)return memoryHalt(pc,4,false,true);
 uint32_t op=opcode>>26,rs=(opcode>>21)&31,rt=(opcode>>16)&31,rd=(opcode>>11)&31,sh=(opcode>>6)&31,fn=opcode&63;
 // Reject control transfer in a delay slot before any link or CP0 side effects.
 bool control=op==1||(op>=2&&op<=7)||(op>=20&&op<=23)||(op==0&&(fn==8||fn==9))||opcode==0x42000018;
 if(control&&delay)return halt(CONTROL,"Control transfer in branch delay slot");
 uint64_t a=reg[rs],b=reg[rt],result=0;
 uint32_t dest=0,target=next+4,addr=uint32_t(a+sx16(opcode));
 bool branch=false,write=false,write_upper=false,annul=false,direct=false;uint64_t upper_result=0;
 uint32_t branchTarget=pc+4+uint32_t(sx16(opcode)*4);
 if(op==0){
  dest=rd;write=true;
  switch(fn){
   case 0:result=sx32(uint32_t(b)<<sh);break;
   case 2:result=sx32(uint32_t(b)>>sh);break;
   case 3:result=sar32(b,sh);break;
   case 4:result=sx32(uint32_t(b)<<(a&31));break;
   case 6:result=sx32(uint32_t(b)>>(a&31));break;
   case 7:result=sar32(b,unsigned(a));break;
   case 8:branch=true;target=uint32_t(a);write=false;break;
   case 9:branch=true;target=uint32_t(a);result=sx32(pc+8);break;
   case 10:result=a;write=b==0;break; // MOVZ
   case 11:result=a;write=b!=0;break; // MOVN
   case 13:return halt(BREAKPOINT,"Guest BREAK instruction; debugger stop");
   case 15:write=false;break; // SYNC: interpreter has no asynchronous memory operations.
   case 16:result=hi;break;case 17:hi=a;write=false;break;
   case 18:result=lo;break;case 19:lo=a;write=false;break;
   case 20:result=b<<(a&63);break;
   case 22:result=b>>(a&63);break;
   case 23:result=sar64(b,unsigned(a));break;
   case 24:case 25:{
    uint64_t product=fn==24?uint64_t(signedWord(a)*signedWord(b)):uint64_t(uint32_t(a))*uint32_t(b);
    lo=sx32(uint32_t(product));hi=sx32(uint32_t(product>>32));result=lo;break;
   }
   case 26:case 27:{
    if(fn==26){int64_t num=signedWord(a),den=signedWord(b);
     // Widened operands also make INT32_MIN / -1 well-defined.
     lo=den?sx32(uint32_t(num/den)):(num<0?1:~uint64_t(0));
     hi=den?sx32(uint32_t(num%den)):sx32(uint32_t(a));
    }else{uint32_t num=uint32_t(a),den=uint32_t(b);
     lo=den?sx32(num/den):~uint64_t(0);hi=den?sx32(num%den):sx32(num);
    }
    write=false;break;
   }
   case 33:result=sx32(uint32_t(a+b));break;
   case 35:result=sx32(uint32_t(a-b));break;
   case 36:result=a&b;break;case 37:result=a|b;break;case 38:result=a^b;break;case 39:result=~(a|b);break;
   case 42:result=signedLess(a,b);break;
   case 43:result=a<b;break;case 45:result=a+b;break;case 47:result=a-b;break;
   case 56:result=b<<sh;break;case 58:result=b>>sh;break;case 59:result=sar64(b,sh);break;
   case 60:result=b<<(sh+32);break;case 62:result=b>>(sh+32);break;case 63:result=sar64(b,sh+32);break;
   default:return halt(UNSUPPORTED,"SPECIAL instruction not implemented");
  }
 }else if(op==1){
  if(rt>3)return halt(UNSUPPORTED,"REGIMM link/trap instruction not implemented");
  bool take=(bool(a>>63)==((rt&1)==0));branch=true;
  if(take)target=branchTarget;else annul=(rt&2)!=0;
 }else if(op==2||op==3){
  branch=true;target=((pc+4)&0xf0000000u)|((opcode&0x03ffffffu)<<2);
  if(op==3){write=true;dest=31;result=sx32(pc+8);}
 }else if((op>=4&&op<=7)||(op>=20&&op<=23)){
  unsigned kind=op&7;bool take=false;
  if(kind==4)take=a==b;else if(kind==5)take=a!=b;
  else if(kind==6)take=(a>>63)||a==0;else take=!(a>>63)&&a!=0;
  branch=true;if(take)target=branchTarget;else annul=op>=20;
 }else if(op==9){write=true;dest=rt;result=sx32(uint32_t(a+sx16(opcode)));}
 else if(op==25){write=true;dest=rt;result=a+sx16(opcode);}
 else if(op==10||op==11){write=true;dest=rt;uint64_t imm=sx16(opcode);result=op==10?signedLess(a,imm):a<imm;}
 else if(op>=12&&op<=15){write=true;dest=rt;uint64_t imm=opcode&65535;result=op==12?a&imm:op==13?a|imm:op==14?a^imm:sx32(uint32_t(imm)<<16);}
 else if(op==16){
  if(!(cp0[12]&6)&&(cp0[12]&24)&&!(cp0[12]&0x10000000u))return halt(UNSUPPORTED,"COP0 unusable; guest exceptions unimplemented");
  if((rs==0||rs==4)&&(opcode&0x7ff)==0){
   if(rs==0){
    if(!cp0Readable(rd))return halt(UNSUPPORTED,"CP0 register read requires missing timer/TLB/debug model");
    write=true;dest=rt;result=sx32(rd==12?cp0[rd]&0xf0c79c1fu:cp0[rd]);
   }else{
    if(!cp0Writable(rd))return halt(UNSUPPORTED,"CP0 register write not implemented");
    uint32_t v=uint32_t(b);
    if(rd==0)cp0[rd]=(cp0[rd]&0x80000000u)|(v&63);
    else if(rd==2)cp0[rd]=v&0x83ffffffu;
    else if(rd==3)cp0[rd]=v&0x03ffffffu;
    else if(rd==4)cp0[rd]=(cp0[rd]&0x007ffff0u)|(v&0xff800000u);
    else if(rd==5)cp0[rd]=v&0x01ffe000u;
    else if(rd==6){if((v&63)>=48)return halt(UNSUPPORTED,"Wired index outside 48-entry TLB");cp0[rd]=v&63;cp0[1]=47;}
    else if(rd==10)cp0[rd]=v&0xffffe0ffu;
    else cp0[rd]=rd==16?(v&~0xfc0u)|0x440u:v;
   }
  }else if(opcode==0x42000001||opcode==0x42000002||opcode==0x42000006||opcode==0x42000008){
   if(!(cp0[12]&6)&&(cp0[12]&24))return halt(UNSUPPORTED,"TLB instruction requires kernel mode");
   unsigned index=cp0[0]&63;
   if(opcode==0x42000008){int found=tlb.probe(cp0[10]);if(found==-2)return halt(UNSUPPORTED,"TLBP duplicate mappings");cp0[0]=found<0?0x80000000u:uint32_t(found);}
   else if(opcode==0x42000001){
    if(index>=48||!tlb.entry[index].written)return halt(UNSUPPORTED,"TLBR entry out of range or uninitialized");
    const EeTlb::Entry&e=tlb.entry[index];cp0[5]=e.mask;cp0[10]=e.hi&~(e.mask|0x1f00u);unsigned g=e.lo0&e.lo1&1;cp0[2]=(e.lo0&~1u)|g;cp0[3]=(e.lo1&~1u)|g;
   }else{if(opcode==0x42000006)index=cp0[1]&63;if(!tlb.put(index,cp0[5],cp0[10],cp0[2],cp0[3]))return halt(UNSUPPORTED,"TLB write index/page mask/scratch layout unsupported");}
  }else if(opcode==0x42000018){
   direct=true;
   if(cp0[12]&4){target=cp0[30];cp0[12]&=~4u;}
   else{target=cp0[14];cp0[12]&=~2u;}
  }else return halt(UNSUPPORTED,"CP0 operation requires missing TLB/interrupt model");
 }else if(op==17){
  if(!(cp0[12]&0x20000000u))return halt(UNSUPPORTED,"COP1 unusable; guest exceptions unimplemented");
  if((rs!=0&&rs!=4)||(opcode&0x7ff))return halt(UNSUPPORTED,"COP1 operation not implemented (MFC1/MTC1 only)");
  if(rs==0){dest=rt;result=sx32(fpr[rd]);write=true;}
  else fpr[rd]=uint32_t(b);
 }else if(op==49||op==57){
  if(!(cp0[12]&0x20000000u))return halt(UNSUPPORTED,"COP1 unusable; guest exceptions unimplemented");
  bool store=op==57;
  if(addr&3)return memoryHalt(addr,4,store,false);
  if(store){if(!write32(addr,fpr[rt]))return memoryHalt(addr,4,true,false);}
  else{uint32_t value;if(!read32(addr,value))return memoryHalt(addr,4,false,false);fpr[rt]=value;}
 }else if(op==47){
  if(!(cp0[12]&6)&&(cp0[12]&24))return halt(UNSUPPORTED,"CACHE requires kernel mode in this interpreter");
  if(rt!=7&&rt!=22)return halt(UNSUPPORTED,"CACHE operation not implemented (only IXIN/DXIN supported)");
  // IXIN/DXIN invalidate by cache index, not a translated data address.
  // This cacheless interpreter has no cached instructions or dirty data.
 }else if(op==28){
  // MMI2/MMI3 packed logical operations write all 128 GPR bits.
  unsigned fn=opcode&63,sub=(opcode>>6)&31;
  if((fn!=9&&fn!=41)||(sub!=18&&sub!=19))return halt(UNSUPPORTED,"MMI instruction not implemented");
  uint64_t ah=rs?reg_hi[rs]:0,bh=rt?reg_hi[rt]:0;
  if(fn==9){result=sub==18?(a&b):(a^b);upper_result=sub==18?(ah&bh):(ah^bh);}
  else{result=a|b;upper_result=ah|bh;if(sub==19){result=~result;upper_result=~upper_result;}}
  dest=rd;write=write_upper=true;
 }else if(op==30||op==31){
  // R5900 LQ/SQ ignore the low four effective-address bits.
  uint32_t aligned=addr&~15u;bool store=op==31;
  unsigned char*p=address(aligned,16,store);
  if(!p)return memoryHalt(aligned,16,store,false);
  if(store){uint64_t lower=rt?reg[rt]:0,upper=rt?reg_hi[rt]:0;
   for(unsigned i=0;i<8;i++){p[i]=(lower>>(8*i))&255;p[i+8]=(upper>>(8*i))&255;}
  }else{
   result=upper_result=0;for(unsigned i=0;i<8;i++){result|=uint64_t(p[i])<<(8*i);upper_result|=uint64_t(p[i+8])<<(8*i);}
   write=true;write_upper=true;dest=rt;
  }
 }else if(op==32||op==33||op==35||op==36||op==37||op==39||op==55){
  unsigned size=(op==32||op==36)?1:(op==33||op==37)?2:op==55?8:4;
  unsigned char*p=address(addr,size,false);
  if(addr&(size-1))return memoryHalt(addr,size,false,false);
  uint64_t v=0;
  if(p){for(unsigned i=0;i<size;i++)v|=uint64_t(p[i])<<(8*i);}
  else if(!mmioRead(addr,size,v))return memoryHalt(addr,size,false,false);
  result=op==32?(v&128?0xffffffffffffff00ull|v:v):op==33?sx16(uint32_t(v)):op==35?sx32(uint32_t(v)):v;write=true;dest=rt;
 }else if(op==40||op==41||op==43||op==63){
  unsigned size=op==40?1:op==41?2:op==63?8:4;unsigned char*p=address(addr,size,true);
  if(addr&(size-1))return memoryHalt(addr,size,true,false);
  if(p){for(unsigned i=0;i<size;i++)p[i]=(b>>(8*i))&255;}
  else if(!mmioWrite(addr,size,b))return memoryHalt(addr,size,true,false);
 }else return halt(UNSUPPORTED,"Primary instruction not implemented");
 if(write&&dest){reg[dest]=result;if(write_upper)reg_hi[dest]=upper_result;}
 reg[0]=reg_hi[0]=0;
 if(direct){pc=target;next=target+4;delay=false;}
 else if(annul){pc=next+4;next=pc+4;delay=false;}
 else{pc=next;next=target;delay=branch;}
 if(!(op==16&&rs==4&&rd==6))cp0[1]=(cp0[1]<=cp0[6]||cp0[1]>=48)?47:cp0[1]-1;
 instructions++;return true;
}
